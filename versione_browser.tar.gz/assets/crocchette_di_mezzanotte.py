#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CROCCHETTE DI MEZZANOTTE  -  un gioco per Ale ed Eli
=====================================================

Sono le 2 di notte. Tamiyo ha sparso le crocchette per casa e in giardino.
Tu (Ale) cammini in punta di piedi, le raccogli tutte e torni a letto prima
dell'alba. Ma Eli non sta mai ferma: va dal letto al bagno, dalla cucina al
letto... e se ti vede, ti sveglia del tutto. E ogni tanto Tamiyo ti ferma per
chiederti una crocchetta.

COMANDI
    Frecce (o W A S D)   cammina
    SPAZIO               dai una crocchetta a Tamiyo (quando ti blocca)
    INVIO                inizia / continua
    P                    pausa
    M                    musica e suoni on/off
    ESC                  esci

COME AVVIARLO
    python crocchette_di_mezzanotte.py        (vedi GUIDA.md per i dettagli)

LE IMMAGINI (nella cartella "immagini", accanto a questo file)
    personaggi\\ale_walk.png, eli_walk.png, gatto_walk.png   i personaggi che camminano
    io.png, elisa.png, gatto.png                            i ritratti nei fumetti
    kenney\\arredi.png                                       i mobili (Kenney, CC0)
Se un file manca, il gioco usa un disegno semplice al suo posto e non si blocca.
"""

import asyncio
import math
import os
import random
import sys
from array import array
from collections import deque
from pathlib import Path

import pygame

# =============================================================================
#  CONFIGURAZIONE  -  QUI PUOI CAMBIARE QUASI TUTTO
# =============================================================================

TITOLO_FINESTRA = "Non ero calcolato!.. Bei tempi!"
FPS = 60

# --- FINESTRA E ATMOSFERA ---------------------------------------------------
# ZOOM ingrandisce tutta la finestra (1.0 = normale, 1.25 o 1.5 = piu' grande).
# Se lo schermo e' piccolo prova 0.85. La finestra si puo' anche trascinare.
ZOOM = 1.0
OSCURITA = 125        # quanto e' buia la casa: 0 = luci accese, 200 = molto buio
RAGGIO_LUCE = 150     # quanto illumina la tua torcia (in pixel)
EFFETTO_CRT = False   # righe orizzontali stile vecchio monitor

# --- VELOCITA' (pixel al secondo; una stanza e' larga circa 150-200 pixel) ---
# Piu' alto = piu' veloce. Per rendere il gioco piu' facile abbassa la velocita'
# di Eli e del gatto, oppure alza quella di Ale.
VELOCITA_IO = 135                # Ale
VELOCITA_ELISA_GIRO = 120        # Eli quando va in giro per casa
VELOCITA_ELISA_SVEGLIA = 108     # Eli quando ti cerca
VELOCITA_GATTO = 95              # Tamiyo

# --- REGOLE -----------------------------------------------------------------
VITE_INIZIALI = 3                # le "ore di sonno" che puoi perdere
TASCA_INIZIALE = 2               # crocchette che hai in tasca all'inizio
TASCA_MASSIMA = 9

SCATOLETTA_SECONDI_EXTRA = 10    # secondi di notte guadagnati con la scatoletta
GATTO_CACCIA_CROCCHINO = 10      # dopo un crocchino Tamiyo va a caccia di insetti in giardino per...
GATTO_CACCIA_COCCOLE = 8         # ...dopo le coccole...
GATTO_CACCIA_SCATOLETTA = 30     # ...dopo la scatoletta ci sta molto di piu' (tempo guadagnato per te)

RICHIESTE_ATTIVE = True          # True = Eli e Tamiyo ti chiedono cose (attenzioni, aiuto, coccole, scatolette)
RICHIESTA_PRIMA_SECONDI = 14     # dopo quanti secondi arriva la prima richiesta
RICHIESTA_OGNI_SECONDI = (10, 17)  # ogni quanto ne arriva una nuova (minimo, massimo)
PAZIENZA_SECONDI = 28            # quanto aspettano prima di offendersi
TENUTA_SECONDI = 2.2             # quanto tieni premuto SPAZIO per coccole e attenzioni
PUNTI_RICHIESTA = 80             # punti per ogni richiesta esaudita
STRESS_ATTIVO = True             # True = l'AFFANNO sale quando hai troppe cose da fare
BISOGNO_ATTIVO = True            # True = ogni tanto Ale deve andare in bagno (pancia in subbuglio)
BISOGNO_SECONDI = (40, 70)       # dopo quanti secondi la pancia "chiama" (minimo, massimo)
SEDUTA_SECONDI = 3.2             # quanto dura la seduta in bagno (non ti alzi prima!)
PUNTI_SOLLIEVO = 50              # punti per il sollievo

GATTO_PAZIENZA = 2.0             # se non hai crocchette, dopo quanti secondi si stufa
GATTO_RIPOSO = 8.0               # dopo una crocchetta Tamiyo ti lascia in pace per...

ELISA_GIRO_SECONDI = (8, 14)     # per quanto tempo Eli gira per casa (min, max)
ELISA_SOSTA_SECONDI = (0.8, 1.8) # quanto si ferma a "fare le sue cose"
ELISA_VISTA_CELLE = 5.5          # da quanto lontano ti nota (in "caselle"); 0 = non ti nota mai
ELISA_SOSPETTO_SECONDI = 0.7     # per quanto resta col dubbio ("?") prima di inseguirti
ELISA_RICERCA_SECONDI = 7.0      # per quanto ti cerca, chiamandoti, quando ti ha perso
# (la durata della notte, quanto Eli ti cerca, quanto sbaglia strada e quanto il
#  gatto ti segue cambiano da livello a livello: vedi LIVELLI qui sotto)

# --- PUNTEGGI ---------------------------------------------------------------
PUNTI_CROCCHETTA = 10
PUNTI_SCATOLETTA = 50
PUNTI_CROCCHETTA_AL_GATTO = 20
PUNTI_PER_VITA_RIMASTA = 100     # bonus a fine livello
PUNTI_PER_SECONDO_RIMASTO = 2

# --- AUDIO ------------------------------------------------------------------
SUONI_ATTIVI = True

# --- FILE IMMAGINI (cartella "immagini"; puoi cambiare i nomi qui) -----------
FILE_ALE_CAMMINATA = "personaggi/ale_walk.png"
FILE_ELISA_CAMMINATA = "personaggi/eli_walk.png"
FILE_GATTO_CAMMINATA = "personaggi/gatto_walk.png"
FILE_ALE_SEDUTO_VESTITO = "personaggi/ale_sit_pantaloni.png"
FILE_ALE_SEDUTO_NUDO = "personaggi/ale_sit_nudo.png"
FILE_RITRATTO_ALE = "io.png"
FILE_RITRATTO_ELISA = "elisa.png"
FILE_RITRATTO_GATTO = "gatto.png"
FILE_ARREDI = "kenney/arredi.png"

# --- LIVELLI ----------------------------------------------------------------
# Ogni livello ha la sua casa (mappa) e la sua difficolta'. Per aggiungerne uno
# copia un blocco { ... } e cambialo. TUTTE le mappe devono avere la stessa
# grandezza (24 x 17 qui), cosi' la finestra non cambia.
#
# COME SI DISEGNA UNA MAPPA (una riga = una fila di caselle, tutte lunghe uguali)
#   Pareti e fuori:   #  muro     w  muro con finestra     q  muro con quadro
#                     H  siepe    Z  albero                x  aiuola (si cammina)
#   Pavimenti:        .  legno    :  piastrelle    _  cemento    ,  erba
#                     g  pietra   r  tappeto       d  porta (si cammina)
#   Mobili (si urtano):  T tavolo   A sedia   S divano   K mobile cucina
#                     N lavello   V fornelli   F frigo   P pianta   B libreria
#                     W armadio   Y water   X lavandino   U vasca   D scrivania
#                     M mobile TV   I letto singolo   p pilastro
#   Speciali:         L  il tuo letto (qui parte Ale e qui devi tornare)
#                     E  qui parte Eli      G  qui parte Tamiyo
# Le crocchette e le scatolette NON si scrivono nella mappa: il gioco sparge
# le crocchette da solo ("crocchette" = quante) e le scatolette stanno nelle
# caselle (colonna, riga) elencate in "scatolette".
#
# PARAMETRI DI DIFFICOLTA' (piu' alto = piu' difficile, tranne "errore"):
#   elisa_giro / elisa_sveglia   moltiplicano la velocita' di Eli
#   sveglia_secondi              quanto a lungo Eli ti cerca davvero
#   errore                       quanto spesso Eli sbaglia strada (0 = mai)
#   curiosita                    quanto Tamiyo ti segue (0 = vaga a caso)
#   notte_secondi                tempo a disposizione (02:00 -> 06:00)
#   tappe                        posti dove Eli va "a fare le sue cose" (colonna, riga)
LIVELLI = (
    {
        "nome": "Via Castelfidardo",
        "intro": ("Sono le 2:00. Tamiyo ha sparso le crocchette!",
                  "Raccoglile tutte e torna a letto prima dell'alba."),
        "fine": ("Sei tornato a letto. Che notte!",
                 "Ma Tamiyo ha gia' un altro piano..."),
        "elisa_giro": 1.0, "elisa_sveglia": 1.0, "sveglia_secondi": 6,
        "errore": 0.12, "curiosita": 0.35, "notte_secondi": 240,
        "crocchette": 44, "seme": 11,
        "scatolette": ((2, 2), (21, 2), (2, 15), (21, 15)),
        "muri": "intonaco", "colore_muro": (222, 204, 172), "divano": (150, 78, 66),
        "mappa": (
            "HHHHHHHHHHHHHHHHHHHHHHHH",
            "HZ,,,x,,,,,,,,,,,x,,,,ZH",
            "H,,###d#####d########,,H",
            "H,,#w#dwq#w#dw#qw##w#,,H",
            "H,,#FK:NV#.L..W#YX:U#,,H",
            "H,,#:G:TT#.rrr.#:::U#,,H",
            "H,,#:::AA#Prrr.#:::U#,,H",
            "H,,###d#####d####d###,,H",
            "H,,#B.......rrrrr..P#,,H",
            "H,,#........rrrrr...#,,H",
            "H,,#.rrr.###d####d###,,H",
            "H,,#.SSS.#B...B#P...#,,H",
            "H,,d..T..#...AD#...I#,,H",
            "H,,#.MMM.#P...D#..EI#,,H",
            "H,,###w###w###w###w##,,H",
            "HZ,,,x,,,,,,,,,,,,x,,,ZH",
            "HHHHHHHHHHHHHHHHHHHHHHHH",
        ),
        "tappe": ((17, 5), (18, 13), (6, 5), (12, 5), (6, 9), (12, 12), (14, 8), (12, 1)),
    },
    {
        "nome": "Casa all'Isolotto",
        "intro": ("Livello 2: l'Isolotto, davanti alle Cascine.",
                  "Stavolta Eli e Tamiyo dormono da te!"),
        "fine": ("Ce l'hai fatta anche a casa tua!",
                 "Ora Ale sogna la Manifattura..."),
        "elisa_giro": 1.08, "elisa_sveglia": 1.05, "sveglia_secondi": 7,
        "errore": 0.08, "curiosita": 0.45, "notte_secondi": 225,
        "crocchette": 46, "seme": 23,
        "scatolette": ((2, 2), (21, 2), (2, 15), (21, 15)),
        "muri": "intonaco", "colore_muro": (206, 214, 188), "divano": (70, 108, 128),
        "mappa": (
            "HHHHHHHHHHHHHHHHHHHHHHHH",
            "HZ,,x,,,,,,,,,,,,,,x,,ZH",
            "H,,########dd########,,H",
            "H,,#w##wq#wddw#qw##w#,,H",
            "H,,#.L..PW#..#BBDD.P#,,H",
            "H,,#..rrr.d..d...A..#,,H",
            "H,,#..rrr.#.P#P.....#,,H",
            "H,,########..########,,H",
            "H,,#UU:Y:X#rr#B....P#,,H",
            "H,,#::::::drr#......#,,H",
            "H,,########..d.rrrr.d,,H",
            "H,,#::TT::#.P#.SSS..#,,H",
            "H,,d:GAA::d..#..T.E.#,,H",
            "H,,#FKNKVK#..#.MMM..#,,H",
            "H,,###w###wdd#w###w##,,H",
            "HZ,,,,x,,,,,,,,,,x,,,,ZH",
            "HHHHHHHHHHHHHHHHHHHHHHHH",
        ),
        "tappe": ((6, 5), (16, 5), (7, 9), (17, 10), (8, 12), (18, 12), (11, 8), (12, 15)),
    },
    {
        "nome": "Manifattura (nel sogno)",
        "intro": ("Livello 3: sogni la Manifattura!",
                  "Crocchette ovunque. Eli corre, Tamiyo ti segue."),
        "fine": ("Buongiorno, Manifattura!",
                 "Ale si sveglia sorridendo."),
        "elisa_giro": 1.17, "elisa_sveglia": 1.12, "sveglia_secondi": 8,
        "errore": 0.04, "curiosita": 0.55, "notte_secondi": 220,
        "crocchette": 50, "seme": 37,
        "scatolette": ((2, 2), (21, 2), (2, 15), (21, 15)),
        "muri": "mattoni", "colore_muro": (176, 98, 76), "divano": (110, 90, 70),
        "mappa": (
            "HHHHHHHHHHHHHHHHHHHHHHHH",
            "HZggggggggggggggggggggZH",
            "Hgg########dd########ggH",
            "Hgg#w##wq#wddw#qw##w#ggH",
            "Hgg#L__B#KK__KK#KKKK#ggH",
            "Hgg#____d______d_A_A#ggH",
            "Hgg#P___#_p__p_#___P#ggH",
            "Hgg######______######ggH",
            "Hgg#_TT_#_ATTA_#____#ggH",
            "Hggd_AA_d______d_TT_dggH",
            "Hgg#___P#______#_AA_#ggH",
            "Hgg######_p__p_######ggH",
            "Hgg#KKK_d___G__d_BBB#ggH",
            "Hgg#Y___#_P__P_#__E_#ggH",
            "Hgg###w###wdd#w###w##ggH",
            "HgggggPggggggggggPgggggH",
            "HHHHHHHHHHHHHHHHHHHHHHHH",
        ),
        "tappe": ((5, 5), (18, 5), (4, 9), (16, 10), (7, 12), (12, 12), (12, 6), (18, 13)),
    },
)

# --- FRASI ------------------------------------------------------------------
# Cambiale quando ti vengono in mente quelle vere di Eli! Ogni voce e' una
# coppia di righe (riga 1, riga 2).
FRASI_ELISA = (
    ("Ale... dormi?", "Eli ti ha svegliato!"),
    ("Torno subito, tu dormi!", "Ma ormai sei sveglio."),
    ("Scusa, ti ho svegliato?", "Un po'..."),
    ("Amore, che ore sono?", "Troppo presto per essere sveglio."),
)
FRASI_ELISA_SOSPETTA = ("Eli si e' fermata...", "Ha sentito qualcosa?")
FRASI_ELISA_TI_VEDE = ("Eli ti ha visto!", "Sta arrivando: vuole qualcosa da te.")
# Quando Eli non ti trova ti cerca chiamandoti. Ogni voce: (parola nel fumetto, due righe del messaggio)
FRASI_ELISA_CERCA = (
    ("Ale?", ("Ale? Dove sei?", "Eli ti sta cercando...")),
    ("Ale...?", ("Ale... dove ti sei nascosto?", "Resta fermo e in silenzio.")),
    ("Dove sei?", ("Amore, sei qui?", "Eli guarda dietro i mobili.")),
    ("Aleee?", ("Aleee? Rispondimi!", "Non fare rumore...")),
)
FRASI_PANCIA_PRIMA = ("Strizzone di pancia!", "Meglio trovare un bagno...")
FRASI_PANCIA = (
    ("Uhhh... un altro strizzone!", "Il bagno, presto!"),
    ("La pancia brontola...", "Cerca il water!"),
    ("Ngh... non resisto molto!", "Dov'e' il bagno?"),
)
FRASI_BAGNO_INIZIO = ("Ale si siede sulla tazza...", "Non ti alzi finche' non hai finito!")
FRASI_BAGNO_FINE = ("Ahhh... che sollievo!", "Come nuovo.")
FRASI_ELISA_BAGNO = ("Eli ti ha beccato sulla tazza!", "Che imbarazzo...")
FRASI_PRIMA_IL_BAGNO = ("Prima il bagno!", "Cosi' non riesci proprio a dormire.")
FRASI_RICHIESTA_ESAUDITA_ELI = (
    ("Grazie amore!", "Sei sempre il mio aiuto."),
    ("Che bello avere te!", "Ti amo. Tutto qua."),
    ("Mi hai salvata!", "Che farei senza di te?"),
)
FRASI_RICHIESTA_ESAUDITA_GATTO = (
    ("Tamiyo fa le fusa...", "Sei il suo preferito."),
    ("Tamiyo e' felice!", "Prrr prrr prrr..."),
)
FRASI_ELISA_DELUSA = ("Uffa, Ale! Non mi ascolti mai!", "Eli e' delusa... (perdi un'ora di sonno)")
FRASI_GATTO_OFFESO = ("Tamiyo ti ignora, offesa.", "Se ne va con la coda alta.")
FRASI_STRESS_AL_LIMITE = ("Troppe cose da fare!", "Ale e' esausto... (perdi un'ora di sonno)")
FRASI_MANI_OCCUPATE = ("Hai le mani occupate!", "Consegna prima quello che porti.")
FRASI_GATTO_BLOCCA = (
    "Tamiyo vuole una crocchetta!",
    "Premi SPAZIO per dargliela.",
)
FRASI_GATTO_SENZA = (
    "Tamiyo ti fissa... e non hai crocchette!",
    "Aspetta che si stufi.",
)
FRASI_GATTO_CONTENTO = (
    "Tamiyo mangia felice.",
    "Poi va a caccia di insetti in giardino.",
)
FRASI_SCATOLETTA = (
    "Tamiyo adora la scatoletta!",
    "Va a caccia di insetti in giardino per un bel po'.",
)
FRASI_TUTTE_RACCOLTE = (
    "Crocchette finite!",
    "Torna a letto, presto!",
)
TITOLO_SCHERMATA_VITTORIA = "BUONANOTTE!"
FRASI_VITTORIA = (
    "Ti amo. Tutto qua.",
    "Non ti scordare che ti amo. - Non me lo scordo.",
)
TITOLO_SCHERMATA_VITE = "NOTTE INSONNE"
FRASI_VITE_FINITE = (
    "Eli: \"Sai che ti amo vero?\"",
    "Ale: \"No, non lo so.\"",
)
TITOLO_SCHERMATA_SOLE = "E' SORTO IL SOLE"
FRASI_SOLE = (
    "Sono le 6:00 e hai ancora crocchette da raccogliere.",
    "Tamiyo vuole la colazione!",
)


# -----------------------------------------------------------------------------
#  Musica (generata dal codice: niente file audio)
# -----------------------------------------------------------------------------
# Ogni brano ha una melodia e un basso, scritti come note ("A4", "G#5") o "."
# per una pausa. Ogni battuta ha 8 note (crome). Puoi cambiare note e velocita'
# (bpm) per comporre la tua musica.
VOLUME_MUSICA = 0.5

_ACCORDI_NOTTE = (("A2", "E3"), ("A2", "E3"), ("F2", "C3"), ("F2", "C3"),
                  ("G2", "D3"), ("G2", "D3"), ("E2", "B2"), ("E2", "B2"))
_ACCORDI_TITOLO = (("C3", "G3"), ("A2", "E3"), ("F2", "C3"), ("G2", "D3")) * 2

_MELODIA_NOTTE = (
    "E5 . C5 . A4 . C5 .  E5 . A5 . G5 . E5 .  "
    "F5 . C5 . A4 . C5 .  F5 . A5 . G5 . F5 .  "
    "D5 . B4 . G4 . B4 .  D5 . G5 . F5 . D5 .  "
    "E5 . G5 . B5 . G5 .  E5 G#5 B5 G#5 E5 . . ."
)
_MELODIA_TITOLO = (
    "C5 E5 G5 E5 C5 E5 G5 .  A4 C5 E5 C5 A4 C5 E5 .  "
    "F4 A4 C5 A4 F4 A4 C5 .  G4 B4 D5 B4 G4 B4 D5 .  "
    "E5 G5 C6 G5 E5 G5 C6 .  C5 E5 A5 E5 C5 E5 A5 .  "
    "A4 C5 F5 C5 A4 C5 F5 .  G4 B4 D5 G5 D5 B4 G4 ."
)


def _basso(accordi, figura):
    """figura: 8 simboli, 'r' = nota base, 'q' = quinta, '.' = pausa."""
    note = []
    for radice, quinta in accordi:
        note.extend({"r": radice, "q": quinta}.get(s, ".") for s in figura)
    return note


MUSICHE = {
    "titolo": {"bpm": 126, "melodia": _MELODIA_TITOLO.split(), "duty": 0.5,
               "basso": _basso(_ACCORDI_TITOLO, "r.q.r.q.")},
    "notte": {"bpm": 132, "melodia": _MELODIA_NOTTE.split(), "duty": 0.25,
              "basso": _basso(_ACCORDI_NOTTE, "r.r.q.r.")},
    "sveglia": {"bpm": 170, "melodia": _MELODIA_NOTTE.split(), "duty": 0.125,
                "basso": _basso(_ACCORDI_NOTTE, "rrrrqqrr")},
}

_SEMITONI = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def frequenza_nota(nome):
    """'A4' -> 440 Hz. Una pausa ('.') vale 0."""
    if not nome or nome == ".":
        return 0.0
    resto = nome[1:]
    alterazione = 0
    if resto.startswith("#"):
        alterazione, resto = 1, resto[1:]
    elif resto.startswith("b"):
        alterazione, resto = -1, resto[1:]
    try:
        semitoni = _SEMITONI[nome[0]] + alterazione + (int(resto) - 4) * 12 - 9
    except (KeyError, ValueError):
        raise ValueError(f"Nota musicale non valida: '{nome}'. Usa per esempio A4, C#5, G3 oppure '.' per una pausa.")
    return 440.0 * 2 ** (semitoni / 12)


# -----------------------------------------------------------------------------
#  Suoni (onde quadre, stile 8 bit: nessun file da installare)
# -----------------------------------------------------------------------------
class Suoni:
    FREQUENZA = 22050

    NOTE = {
        "croc_a": [(660, 35)],
        "croc_b": [(880, 35)],
        "dai": [(600, 50), (900, 80)],
        "scatoletta": [(523, 60), (784, 60), (1047, 110)],
        "gatto": [(900, 70), (700, 70), (900, 70), (0, 30), (1100, 90)],
        "sveglia": [(600, 90), (450, 90), (300, 200)],
        "allerta": [(1200, 60), (0, 40), (1200, 60)],
        "tutte": [(784, 80), (988, 80), (1175, 160)],
        "vittoria": [(523, 110), (659, 110), (784, 110), (1047, 300)],
        "sole": [(500, 200), (400, 200), (300, 200), (200, 400)],
    }

    def __init__(self, attivi):
        self.suoni = {}
        self.tracce = {}
        self.canale = None
        self.musica_voluta = None
        self.attivo = False
        self._alterna = False
        if not attivi:
            return
        try:
            pygame.mixer.quit()
            pygame.mixer.init(self.FREQUENZA, -16, 1, 512, allowedchanges=0)
            if pygame.mixer.get_init() != (self.FREQUENZA, -16, 1):
                return
            for nome, note in self.NOTE.items():
                self.suoni[nome] = self._crea(note)
            pygame.mixer.set_reserved(2)
            self.canale = pygame.mixer.Channel(0)
            for nome, brano in MUSICHE.items():
                self.tracce[nome] = self._crea_brano(brano)
            self.attivo = True
        except (pygame.error, TypeError, ValueError) as errore:
            print(f"[Audio disattivato: {errore}]")

    def _voce(self, note, passo, duty, ampiezza, triangolare=False):
        """Trasforma una lista di note in campioni audio (onda a impulsi o triangolare)."""
        rate = self.FREQUENZA
        n_suona = int(passo * 0.7)
        campioni = []
        for nota in note:
            f = frequenza_nota(nota)
            if f <= 0:
                campioni.extend([0] * passo)
                continue
            if triangolare:
                blocco = [int((4 * abs((i * f % rate) / rate - 0.5) - 1) * ampiezza) for i in range(n_suona)]
            else:
                soglia = duty * rate
                blocco = [ampiezza if (i * f) % rate < soglia else -ampiezza for i in range(n_suona)]
            campioni.extend(blocco)
            campioni.extend([0] * (passo - n_suona))
        return campioni

    def _crea_brano(self, brano):
        passo = int(self.FREQUENZA * 60 / brano["bpm"] / 2)
        melodia = self._voce(brano["melodia"], passo, brano["duty"], int(32767 * 0.10))
        basso = self._voce(brano["basso"], passo, 0.5, int(32767 * 0.12), triangolare=True)
        mix = array("h", [a + b for a, b in zip(melodia, basso)])
        suono = pygame.mixer.Sound(buffer=mix.tobytes())
        suono.set_volume(VOLUME_MUSICA)
        return suono

    def imposta_musica(self, nome):
        """Fa partire (in loop) il brano 'nome'; None = silenzio."""
        if nome == self.musica_voluta:
            return
        self.musica_voluta = nome
        self._applica_musica()

    def _applica_musica(self):
        if self.canale is None:
            return
        self.canale.stop()
        if self.attivo and self.musica_voluta in self.tracce:
            self.canale.play(self.tracce[self.musica_voluta], loops=-1)

    def pausa_musica(self, in_pausa):
        if self.canale is None:
            return
        if in_pausa:
            self.canale.pause()
        else:
            self.canale.unpause()

    def _crea(self, note, volume=0.18):
        ampiezza = int(32767 * volume)
        campioni = array("h")
        for freq, ms in note:
            n = int(self.FREQUENZA * ms / 1000)
            for i in range(n):
                if freq == 0:
                    campioni.append(0)
                else:
                    campioni.append(ampiezza if (i * freq * 2 // self.FREQUENZA) % 2 == 0 else -ampiezza)
        return pygame.mixer.Sound(buffer=campioni.tobytes())

    def gioca(self, nome):
        if self.attivo and nome in self.suoni:
            self.suoni[nome].play()

    def crocchetta(self):
        self._alterna = not self._alterna
        self.gioca("croc_a" if self._alterna else "croc_b")

    def on_off(self):
        if self.suoni:
            self.attivo = not self.attivo
            self._applica_musica()
        return self.attivo





# =============================================================================
#  MOTORE DEL GIOCO (non serve toccare)
# =============================================================================
WEB = sys.platform == "emscripten"            # True quando gira dentro un browser
IMPACCHETTATO = bool(getattr(sys, "frozen", False))   # True quando e' l'.exe


def _cartella_risorse():
    """Cartella con immagini, suoni e font: quella del file, o quella temporanea dell'.exe."""
    if IMPACCHETTATO:
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent


CARTELLA = _cartella_risorse()
CARTELLA_SALVATAGGIO = Path(sys.executable).resolve().parent if IMPACCHETTATO else CARTELLA
CARTELLE_IMMAGINI = (CARTELLA / "immagini", CARTELLA)
CARTELLA_SUONI = CARTELLA / "suoni"
CARTELLA_FONT = CARTELLA / "font"
FILE_RECORD = CARTELLA_SALVATAGGIO / "record.txt"

T = 32                          # lato di una casella in pixel (i disegni sono fatti per 32)
ALTEZZA_BARRA_ALTA = 78
ALTEZZA_BARRA_BASSA = 66

NERO = (0, 0, 0)
BIANCO = (245, 245, 245)
GIALLO = (255, 221, 0)
ROSA = (255, 105, 180)
ARANCIO = (255, 150, 40)
AZZURRO = (110, 200, 240)
MARRONE = (190, 120, 50)
VERDE = (90, 200, 120)
ROSSO = (235, 70, 70)

SU, GIU, SINISTRA, DESTRA = (0, -1), (0, 1), (-1, 0), (1, 0)
DIREZIONI = (SU, GIU, SINISTRA, DESTRA)
RIGA_SPRITE = {SU: 0, SINISTRA: 1, GIU: 2, DESTRA: 3}

LUNA = (
    "..XXX..",
    ".XX....",
    "XX.....",
    "XX.....",
    "XX.....",
    ".XX....",
    "..XXX..",
)

SOLIDI = frozenset("#wqHZTASKNVFPBWYUXDMIp")
MURI = frozenset("#wq")
BASE_PAVIMENTO = {".": "legno", ":": "piastrelle", "_": "cemento", ",": "erba", "g": "pietra",
                  "x": "erba", "d": "legno", "L": "legno", "r": "legno", "E": None, "G": None}
SIMBOLI_VALIDI = SOLIDI | frozenset(BASE_PAVIMENTO)


def somma(a, b):
    return (a[0] + b[0], a[1] + b[1])


def opposto(d):
    return (-d[0], -d[1])


def distanza(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def scura(colore, f):
    return tuple(max(0, min(255, int(v * f))) for v in colore[:3])


def trova_file(nome):
    for cartella in CARTELLE_IMMAGINI:
        percorso = cartella / nome
        if percorso.is_file():
            return percorso
    return None


_AVVISATI = set()


def carica_immagine(nome):
    """Carica un PNG dalla cartella immagini. Se manca o e' rovinato ritorna None."""
    percorso = trova_file(nome)
    if percorso is None:
        if nome not in _AVVISATI:
            _AVVISATI.add(nome)
            print(f"[File {nome} non trovato nella cartella immagini: uso un disegno semplice]")
        return None
    try:
        return pygame.image.load(str(percorso)).convert_alpha()
    except (pygame.error, OSError) as errore:
        print(f"[Immagine {nome} non leggibile ({errore}): uso un disegno semplice]")
        return None


# -----------------------------------------------------------------------------
#  Il mondo: la mappa di un livello
# -----------------------------------------------------------------------------
class Mondo:
    """Legge la mappa e risponde a domande tipo 'questa casella e' libera?'."""

    def __init__(self, livello):
        righe = livello["mappa"]
        if not righe or not righe[0]:
            raise ValueError("La mappa e' vuota.")
        for n, riga in enumerate(righe, start=1):
            if len(riga) != len(righe[0]):
                raise ValueError(f"Tutte le righe della mappa devono essere lunghe uguali "
                                 f"(la riga {n} e' diversa dalla prima).")
        self.righe = tuple(righe)
        self.colonne = len(righe[0])
        self.righe_n = len(righe)
        self.start = {}
        self._leggi()
        for simbolo, nome in (("L", "il letto"), ("E", "Eli"), ("G", "Tamiyo")):
            if simbolo not in self.start:
                raise ValueError(f"Nella mappa manca il simbolo '{simbolo}' ({nome}).")
        self.bloccate = frozenset((c, r) for r, riga in enumerate(self.righe)
                                  for c, ch in enumerate(riga) if ch in SOLIDI)
        self._cache = {}
        self._pav = {}
        self.raggiungibili = self._raggiungibili_da(self.start["L"])
        for simbolo, nome in (("E", "Eli"), ("G", "Tamiyo")):
            if self.start[simbolo] not in self.raggiungibili:
                raise ValueError(f"{nome} e' chiusa tra i muri o non comunica con il letto.")
        self.gabinetti = tuple((c, r) for r, riga in enumerate(self.righe) for c, ch in enumerate(riga)
                               if ch == "Y" and any(n in self.raggiungibili for _, n in self.vicini((c, r))))
        self.scatolette = self._celle_valide(livello["scatolette"], "scatolette")
        self.crocchette = self._sparpaglia(livello["crocchette"], livello.get("seme", 1))
        if not self.crocchette:
            raise ValueError("Nella mappa non c'e' posto per nessuna crocchetta.")

    def _leggi(self):
        for r, riga in enumerate(self.righe):
            for c, ch in enumerate(riga):
                if ch not in SIMBOLI_VALIDI:
                    raise ValueError(f"Simbolo '{ch}' non valido nella mappa (riga {r + 1}, colonna {c + 1}).")
                if ch in "LEG":
                    if ch in self.start:
                        raise ValueError(f"Nella mappa il simbolo '{ch}' compare due volte: ne serve uno solo.")
                    self.start[ch] = (c, r)

    def carattere(self, cella):
        c, r = cella
        if 0 <= c < self.colonne and 0 <= r < self.righe_n:
            return self.righe[r][c]
        return "#"

    def libera(self, cella):
        c, r = cella
        return 0 <= c < self.colonne and 0 <= r < self.righe_n and cella not in self.bloccate

    def vicini(self, cella):
        """Lista di (direzione, casella) raggiungibili da questa casella."""
        trovati = []
        for d in DIREZIONI:
            n = somma(cella, d)
            if self.libera(n):
                trovati.append((d, n))
        return trovati

    def celle_libere(self):
        return [(c, r) for r in range(self.righe_n) for c in range(self.colonne)
                if (c, r) not in self.bloccate]

    def _raggiungibili_da(self, cella):
        visti = {cella}
        coda = deque([cella])
        while coda:
            cur = coda.popleft()
            for _, n in self.vicini(cur):
                if n not in visti:
                    visti.add(n)
                    coda.append(n)
        return visti

    def distanze(self, meta):
        """Passi da ogni casella fino a 'meta'. Serve a Eli per inseguire."""
        if meta in self._cache:
            return self._cache[meta]
        dist = {meta: 0}
        coda = deque([meta])
        while coda:
            cur = coda.popleft()
            for _, n in self.vicini(cur):
                if n not in dist:
                    dist[n] = dist[cur] + 1
                    coda.append(n)
        self._cache[meta] = dist
        return dist

    def _celle_valide(self, celle, nome):
        validi = []
        for cella in celle:
            if cella not in self.raggiungibili or self.carattere(cella) in "dLEG":
                raise ValueError(f"In '{nome}' la casella {tuple(cella)} non e' un pavimento raggiungibile.")
            validi.append(tuple(cella))
        return tuple(validi)

    def _sparpaglia(self, quante, seme):
        """Sparge le crocchette il piu' possibile uniformi su tutto il livello."""
        lontane = (self.start["E"], self.start["G"])
        candidate = [c for c in sorted(self.raggiungibili)
                     if self.carattere(c) not in "dLEG" and c not in self.scatolette
                     and all(abs(c[0] - e[0]) + abs(c[1] - e[1]) >= 3 for e in lontane)
                     and abs(c[0] - self.start["L"][0]) + abs(c[1] - self.start["L"][1]) >= 2]
        if not candidate:
            return frozenset()
        rng = random.Random(seme)
        scelte = [rng.choice(candidate)]
        dmin = {c: (c[0] - scelte[0][0]) ** 2 + (c[1] - scelte[0][1]) ** 2 for c in candidate}
        while len(scelte) < min(quante, len(candidate)):
            massimo = max(dmin.values())
            migliori = [c for c, d in dmin.items() if d >= massimo * 0.8 and d > 0]
            if not migliori:
                break
            nuova = rng.choice(sorted(migliori))
            scelte.append(nuova)
            for c in candidate:
                d = (c[0] - nuova[0]) ** 2 + (c[1] - nuova[1]) ** 2
                if d < dmin[c]:
                    dmin[c] = d
        return frozenset(scelte)

    def tipo_pavimento(self, cella):
        """Che pavimento c'e' (anche sotto i mobili): legno, piastrelle, cemento, erba, pietra."""
        if cella in self._pav:
            return self._pav[cella]
        trovato = "legno"
        visti = {cella}
        coda = deque([(cella, 0)])
        while coda:
            cur, d = coda.popleft()
            tipo = BASE_PAVIMENTO.get(self.carattere(cur))
            if tipo:
                trovato = tipo
                break
            if d >= 4:
                continue
            for dd in DIREZIONI:
                n = somma(cur, dd)
                if n not in visti:
                    visti.add(n)
                    coda.append((n, d + 1))
        self._pav[cella] = trovato
        return trovato

    def linea_libera(self, a, b):
        """True se tra le caselle a e b non ci sono muri o mobili in mezzo (vista di Eli)."""
        (ax, ay), (bx, by) = a, b
        passi = max(2, int(math.hypot(bx - ax, by - ay) * 4))
        for i in range(1, passi):
            t = i / passi
            cella = (int(math.floor(ax + (bx - ax) * t + 0.5)), int(math.floor(ay + (by - ay) * t + 0.5)))
            if cella != a and cella != b and cella in self.bloccate:
                return False
        return True


# -----------------------------------------------------------------------------
#  Disegno del mondo: pavimenti, pareti e mobili (in stile pixel art 3/4)
# -----------------------------------------------------------------------------
def _rng(c, r, k=0):
    return random.Random(c * 7919 + r * 104729 + k * 1299709)


def _sup(w=T, h=T, alpha=False):
    return pygame.Surface((w, h), pygame.SRCALPHA) if alpha else pygame.Surface((w, h))


def pav_legno(c, r):
    s = _sup()
    rng = _rng(c, r, 1)
    tinte = ((188, 130, 78), (178, 120, 70), (196, 140, 88))
    for i in range(4):
        y = i * 8
        pygame.draw.rect(s, tinte[(c + r * 2 + i) % 3], (0, y, T, 8))
        pygame.draw.line(s, (122, 78, 44), (0, y + 7), (T, y + 7))
        sx = rng.randint(4, 27)
        pygame.draw.line(s, (122, 78, 44), (sx, y), (sx, y + 6))
        for _ in range(3):
            s.set_at((rng.randint(0, 31), y + rng.randint(1, 5)), (162, 106, 60))
    return s


def pav_piastrelle(c, r):
    s = _sup()
    for bx in (0, 1):
        for by in (0, 1):
            col = (232, 234, 238) if (bx + by + c + r) % 2 == 0 else (212, 220, 228)
            pygame.draw.rect(s, col, (bx * 16, by * 16, 16, 16))
    for v in (0, 16):
        pygame.draw.line(s, (170, 180, 192), (v, 0), (v, T))
        pygame.draw.line(s, (170, 180, 192), (0, v), (T, v))
    return s


def pav_cemento(c, r):
    s = _sup()
    s.fill((142, 144, 152))
    rng = _rng(c, r, 3)
    for _ in range(26):
        x, y = rng.randint(0, 31), rng.randint(0, 31)
        s.set_at((x, y), rng.choice(((120, 122, 130), (158, 160, 168), (132, 134, 142))))
    pygame.draw.line(s, (104, 106, 114), (T - 1, 0), (T - 1, T))
    pygame.draw.line(s, (104, 106, 114), (0, T - 1), (T, T - 1))
    return s


def pav_erba(c, r):
    s = _sup()
    s.fill((84, 150, 72))
    rng = _rng(c, r, 4)
    for _ in range(9):
        x, y = rng.randint(1, 29), rng.randint(2, 29)
        pygame.draw.line(s, (58, 114, 52), (x, y), (x, y - 2))
        pygame.draw.line(s, (58, 114, 52), (x + 2, y), (x + 2, y - 1))
    for _ in range(6):
        s.set_at((rng.randint(0, 31), rng.randint(0, 31)), (116, 178, 94))
    return s


def pav_pietra(c, r):
    s = _sup()
    s.fill((112, 108, 102))
    rng = _rng(c, r, 5)
    for riga in range(4):
        y = riga * 8
        x = -(riga % 2) * 6
        while x < T:
            w = rng.randint(9, 13)
            tono = rng.choice(((158, 152, 142), (150, 146, 136), (164, 158, 148)))
            pygame.draw.rect(s, tono, (x + 1, y + 1, w - 2, 6), border_radius=2)
            x += w
    return s


def pav_erba_fiori(c, r):
    s = pav_erba(c, r)
    rng = _rng(c, r, 6)
    for _ in range(5):
        x, y = rng.randint(3, 27), rng.randint(5, 27)
        col = rng.choice(((250, 220, 90), (250, 250, 250), (240, 120, 160), (170, 140, 240)))
        s.set_at((x, y), col)
        s.set_at((x - 1, y), col)
        s.set_at((x + 1, y), col)
        s.set_at((x, y - 1), col)
        s.set_at((x, y + 1), col)
        s.set_at((x, y), (250, 200, 60))
    return s


def disegna_tappeto(s, n, e, so, w):
    """Tappeto rosso con bordo crema; i lati che continuano su un altro tappeto non hanno bordo."""
    rosso, scuro, crema = (150, 48, 56), (120, 34, 44), (238, 222, 182)
    x0, y0 = (0 if w else 3), (0 if n else 3)
    x1, y1 = (T if e else T - 3), (T if so else T - 3)
    pygame.draw.rect(s, scuro, (x0, y0, x1 - x0, y1 - y0))
    pygame.draw.rect(s, rosso, (x0 + (0 if w else 1), y0 + (0 if n else 1),
                                (x1 - x0) - (0 if w else 1) - (0 if e else 1),
                                (y1 - y0) - (0 if n else 1) - (0 if so else 1)))
    for i in range(0, T, 8):
        pygame.draw.line(s, scuro, (x0, y0 + i + 4), (x1 - 1, y0 + i + 4))
    if not n:
        pygame.draw.line(s, crema, (x0 + 2, y0 + 3), (x1 - 3, y0 + 3))
    if not so:
        pygame.draw.line(s, crema, (x0 + 2, y1 - 4), (x1 - 3, y1 - 4))
    if not w:
        pygame.draw.line(s, crema, (x0 + 3, y0 + 2), (x0 + 3, y1 - 3))
    if not e:
        pygame.draw.line(s, crema, (x1 - 4, y0 + 2), (x1 - 4, y1 - 3))


def disegna_porta(s, orizzontale):
    """Soglia con stipiti di legno (il pavimento e' gia' disegnato sotto)."""
    legno, chiaro = (98, 62, 36), (150, 104, 64)
    if orizzontale:
        pygame.draw.rect(s, legno, (0, 0, 5, T))
        pygame.draw.rect(s, legno, (T - 5, 0, 5, T))
        pygame.draw.line(s, chiaro, (1, 0), (1, T))
        pygame.draw.line(s, chiaro, (T - 4, 0), (T - 4, T))
        pygame.draw.rect(s, (0, 0, 0, 38), (5, 0, T - 10, T))
    else:
        pygame.draw.rect(s, legno, (0, 0, T, 5))
        pygame.draw.rect(s, legno, (0, T - 5, T, 5))
        pygame.draw.line(s, chiaro, (0, 1), (T, 1))
        pygame.draw.line(s, chiaro, (0, T - 4), (T, T - 4))
        pygame.draw.rect(s, (0, 0, 0, 38), (0, 5, T, T - 10))


def disegna_muro_alto(s, c, r):
    s.fill((72, 60, 82))
    rng = _rng(c, r, 7)
    for _ in range(10):
        s.set_at((rng.randint(0, 31), rng.randint(2, 31)), (84, 72, 96))
    pygame.draw.line(s, (112, 100, 124), (0, 0), (T, 0))
    pygame.draw.line(s, (52, 42, 62), (0, T - 1), (T, T - 1))


def disegna_muro_faccia(s, c, r, stile, colore):
    """Faccia visibile di una parete: bordo scuro in alto, parete, zoccolino."""
    if stile == "mattoni":
        s.fill(colore)
        malta = scura(colore, 1.35)
        for riga in range(0, 24, 6):
            pygame.draw.line(s, malta, (0, 6 + riga), (T, 6 + riga))
            off = 8 if (riga // 6) % 2 else 0
            for x in range(off, T, 16):
                pygame.draw.line(s, malta, (x, 6 + riga), (x, 11 + riga))
        rng = _rng(c, r, 8)
        for _ in range(14):
            s.set_at((rng.randint(0, 31), rng.randint(6, 25)), scura(colore, 0.82))
        pygame.draw.rect(s, (96, 94, 102), (0, 25, T, 7))
        pygame.draw.line(s, (130, 128, 136), (0, 25), (T, 25))
    else:
        s.fill(colore)
        for x in range(0, T, 8):
            pygame.draw.line(s, scura(colore, 0.96), (x, 6), (x, 24))
        pygame.draw.rect(s, (150, 104, 70), (0, 25, T, 7))
        pygame.draw.line(s, (186, 134, 92), (0, 25), (T, 25))
        pygame.draw.line(s, (104, 70, 46), (0, 31), (T, 31))
    pygame.draw.rect(s, (74, 62, 84), (0, 0, T, 6))
    pygame.draw.line(s, (116, 104, 128), (0, 5), (T, 5))
    pygame.draw.line(s, (46, 38, 56), (0, 6), (T, 6))


def disegna_finestra(s, c, r):
    """Finestra di notte: vetro blu scuro con stelle e luna."""
    legno = (112, 74, 44)
    pygame.draw.rect(s, legno, (6, 7, 20, 17))
    pygame.draw.rect(s, (24, 36, 84), (8, 9, 16, 12))
    rng = _rng(c, r, 9)
    for _ in range(3):
        s.set_at((rng.randint(9, 22), rng.randint(10, 19)), (220, 230, 255))
    pygame.draw.circle(s, (240, 240, 210), (19, 13), 3)
    pygame.draw.circle(s, (24, 36, 84), (20, 12), 2)
    pygame.draw.line(s, legno, (16, 9), (16, 20))
    pygame.draw.line(s, legno, (8, 15), (23, 15))
    pygame.draw.rect(s, (160, 116, 76), (4, 23, 24, 3))
    pygame.draw.line(s, (96, 62, 38), (4, 25), (27, 25))


def disegna_siepe(s, c, r):
    s.fill((38, 92, 48))
    rng = _rng(c, r, 10)
    for _ in range(14):
        x, y = rng.randint(1, 28), rng.randint(1, 28)
        pygame.draw.circle(s, rng.choice(((52, 118, 62), (66, 140, 76), (30, 78, 40))), (x, y), rng.randint(3, 5))
    for _ in range(5):
        s.set_at((rng.randint(0, 31), rng.randint(0, 31)), (150, 210, 130))
    pygame.draw.rect(s, (24, 60, 32), (0, T - 3, T, 3))


# ----- mobili disegnati a mano ------------------------------------------------
def disegna_divano(w_vic, e_vic, colore):
    s = _sup(alpha=True)
    scuro, chiaro = scura(colore, 0.72), tuple(min(255, int(v * 1.22)) for v in colore)
    x0, x1 = (0 if w_vic else 4), (T if e_vic else T - 4)
    pygame.draw.rect(s, (0, 0, 0, 60), (x0, 26, x1 - x0, 5))
    pygame.draw.rect(s, scuro, (x0, 3, x1 - x0, 13), border_radius=3)
    pygame.draw.rect(s, colore, (x0, 14, x1 - x0, 12), border_radius=2)
    pygame.draw.rect(s, chiaro, (x0 + 2, 15, x1 - x0 - 4, 3))
    pygame.draw.line(s, scuro, (T // 2, 16), (T // 2, 25))
    if not w_vic:
        pygame.draw.rect(s, scuro, (0, 8, 6, 20), border_radius=3)
        pygame.draw.rect(s, colore, (1, 9, 3, 17))
    if not e_vic:
        pygame.draw.rect(s, scuro, (T - 6, 8, 6, 20), border_radius=3)
        pygame.draw.rect(s, colore, (T - 4, 9, 3, 17))
    return s


def disegna_armadio():
    s = _sup(T, 46, alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 60), (1, 42, 30, 4))
    pygame.draw.rect(s, (84, 52, 30), (1, 1, 30, 43))
    pygame.draw.rect(s, (150, 98, 58), (2, 2, 28, 41))
    pygame.draw.rect(s, (176, 120, 72), (0, 0, 32, 5))
    pygame.draw.line(s, (84, 52, 30), (16, 6), (16, 42))
    for x in (4, 18):
        pygame.draw.rect(s, (128, 82, 48), (x, 8, 10, 32))
        pygame.draw.rect(s, (160, 108, 64), (x + 1, 9, 8, 30))
    pygame.draw.rect(s, (236, 220, 170), (13, 22, 2, 5))
    pygame.draw.rect(s, (236, 220, 170), (17, 22, 2, 5))
    return s


def disegna_water():
    s = _sup(alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 55), (6, 27, 20, 4))
    pygame.draw.rect(s, (234, 238, 244), (8, 4, 16, 9), border_radius=2)
    pygame.draw.rect(s, (160, 170, 186), (8, 4, 16, 9), width=1, border_radius=2)
    pygame.draw.rect(s, (216, 220, 228), (21, 6, 3, 2))
    pygame.draw.ellipse(s, (240, 244, 248), (7, 12, 18, 15))
    pygame.draw.ellipse(s, (160, 170, 186), (7, 12, 18, 15), 1)
    pygame.draw.ellipse(s, (200, 210, 224), (10, 14, 12, 9))
    return s


def disegna_lavandino():
    s = _sup(alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 55), (6, 28, 20, 3))
    pygame.draw.rect(s, (226, 230, 238), (12, 17, 8, 11))
    pygame.draw.ellipse(s, (240, 244, 248), (4, 8, 24, 13))
    pygame.draw.ellipse(s, (160, 170, 186), (4, 8, 24, 13), 1)
    pygame.draw.ellipse(s, (170, 196, 224), (8, 10, 16, 8))
    pygame.draw.rect(s, (190, 196, 206), (15, 4, 3, 6))
    pygame.draw.rect(s, (190, 196, 206), (12, 4, 9, 2))
    return s


def disegna_vasca(n, e, so, w):
    s = _sup(alpha=True)
    x0, x1 = (0 if w else 2), (T if e else T - 2)
    y0, y1 = (0 if n else 3), (T if so else T - 2)
    pygame.draw.rect(s, (0, 0, 0, 50), (x0, y1 - 1, x1 - x0, 3))
    pygame.draw.rect(s, (236, 240, 246), (x0, y0, x1 - x0, y1 - y0), border_radius=5)
    pygame.draw.rect(s, (160, 170, 186), (x0, y0, x1 - x0, y1 - y0), width=1, border_radius=5)
    pygame.draw.rect(s, (150, 196, 226), (x0 + (0 if w else 4), y0 + (0 if n else 4),
                                          (x1 - x0) - (0 if w else 4) - (0 if e else 4),
                                          (y1 - y0) - (0 if n else 4) - (0 if so else 4)), border_radius=3)
    return s


def disegna_mobile_tv(con_tv, colore_lampada):
    s = _sup(T, 40, alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 60), (0, 36, T, 4))
    pygame.draw.rect(s, (112, 72, 42), (0, 22, T, 16), border_radius=2)
    pygame.draw.rect(s, (150, 100, 60), (1, 23, T - 2, 4))
    pygame.draw.line(s, (84, 52, 30), (16, 28), (16, 37))
    pygame.draw.rect(s, (230, 210, 150), (7, 31, 3, 2))
    pygame.draw.rect(s, (230, 210, 150), (22, 31, 3, 2))
    if con_tv:
        pygame.draw.rect(s, (22, 24, 30), (3, 3, 26, 19), border_radius=2)
        pygame.draw.rect(s, (78, 118, 170), (5, 5, 22, 14))
        pygame.draw.rect(s, (140, 180, 220), (6, 6, 8, 3))
        pygame.draw.rect(s, (22, 24, 30), (12, 21, 8, 2))
    else:
        pygame.draw.rect(s, (96, 64, 36), (13, 20, 6, 3))
        pygame.draw.polygon(s, colore_lampada, [(9, 20), (23, 20), (19, 8), (13, 8)])
        pygame.draw.line(s, scura(colore_lampada, 0.7), (16, 8), (16, 20))
    return s


def disegna_albero():
    s = _sup(64, 84, alpha=True)
    pygame.draw.ellipse(s, (0, 0, 0, 60), (14, 74, 36, 9))
    pygame.draw.rect(s, (94, 64, 38), (28, 52, 8, 28))
    pygame.draw.rect(s, (124, 86, 52), (28, 52, 3, 28))
    for (x, y, r, col) in ((32, 22, 22, (36, 92, 52)), (18, 34, 15, (44, 106, 60)), (46, 34, 15, (44, 106, 60)),
                           (32, 36, 17, (52, 122, 66)), (26, 18, 11, (76, 150, 84)), (40, 24, 9, (76, 150, 84))):
        pygame.draw.circle(s, col, (x, y), r)
    return s


def disegna_pilastro():
    s = _sup(T, 52, alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 55), (3, 47, 26, 5))
    pygame.draw.rect(s, (160, 160, 170), (8, 6, 16, 42))
    pygame.draw.rect(s, (196, 196, 206), (8, 6, 4, 42))
    pygame.draw.rect(s, (128, 128, 140), (20, 6, 4, 42))
    pygame.draw.rect(s, (176, 176, 186), (4, 2, 24, 6))
    pygame.draw.rect(s, (176, 176, 186), (5, 44, 22, 6))
    pygame.draw.line(s, (112, 112, 124), (4, 8), (27, 8))
    return s


def disegna_pianta_riserva(c, r):
    s = _sup(alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 50), (8, 27, 16, 4))
    pygame.draw.polygon(s, (60, 150, 140), [(9, 19), (23, 19), (21, 29), (11, 29)])
    for (x, y) in ((16, 6), (9, 11), (23, 11), (13, 14), (19, 14)):
        pygame.draw.ellipse(s, (70, 150, 60), (x - 4, y - 5, 8, 12))
    return s


def disegna_crocchetta():
    s = _sup(14, 11, alpha=True)
    for (x, y) in ((4, 6), (9, 5), (6, 3)):
        pygame.draw.circle(s, (96, 56, 24), (x, y), 3)
        pygame.draw.circle(s, (178, 110, 50), (x, y), 2)
        s.set_at((x - 1, y - 1), (232, 170, 100))
    return s


def disegna_scatoletta():
    s = _sup(18, 18, alpha=True)
    pygame.draw.ellipse(s, (0, 0, 0, 70), (2, 14, 14, 4))
    pygame.draw.rect(s, (176, 188, 202), (3, 5, 12, 10), border_radius=2)
    pygame.draw.rect(s, (236, 90, 120), (3, 8, 12, 4))
    pygame.draw.rect(s, (255, 230, 120), (6, 9, 6, 2))
    pygame.draw.ellipse(s, (214, 224, 236), (3, 3, 12, 5))
    pygame.draw.ellipse(s, (120, 132, 148), (3, 3, 12, 5), 1)
    pygame.draw.line(s, (255, 255, 255), (5, 6), (8, 5))
    return s


class Arte:
    """Costruisce lo sfondo di un livello (pavimenti, pareti, tappeti) e l'elenco dei mobili."""

    # tessere del foglio di Kenney: (colonna, riga)
    FRIGO, LAVELLO, FORNELLI = (14, 12), (8, 12), (14, 14)
    PIANTE = ((16, 0), (17, 0))
    LIBRERIE = ((20, 17), (21, 17), (19, 17))
    PENSILI = ((0, 12), (1, 12), (2, 12))
    QUADRI = ((19, 12), (20, 12), (19, 13), (16, 12), (21, 12), (17, 12), (19, 14), (18, 12), (20, 14))
    LETTO, LETTINO, SCRIVANIA = (9, 6), (9, 7), (5, 5)

    def __init__(self):
        sheet = None
        percorso = trova_file(FILE_ARREDI)
        if percorso is None:
            print(f"[File {FILE_ARREDI} non trovato: uso mobili disegnati a mano]")
        else:
            try:
                sheet = pygame.image.load(str(percorso)).convert_alpha()
            except (pygame.error, OSError) as errore:
                print(f"[Arredi non leggibili ({errore}): uso mobili disegnati a mano]")
        self.sheet = sheet
        self._cache = {}

    def k(self, colonna, riga):
        """Tessera 16x16 del foglio di Kenney, ingrandita a 32x32 (None se manca il foglio)."""
        chiave = (colonna, riga)
        if chiave not in self._cache:
            img = None
            if self.sheet is not None:
                try:
                    pezzo = self.sheet.subsurface((colonna * 17, riga * 17, 16, 16)).copy()
                    img = pygame.transform.scale(pezzo, (T, T))
                except (ValueError, pygame.error):
                    img = None
            self._cache[chiave] = img
        return self._cache[chiave]

    def k_o_riserva(self, colonna, riga, colore):
        img = self.k(colonna, riga)
        if img is not None:
            return img
        s = _sup(alpha=True)
        pygame.draw.rect(s, colore, (3, 6, 26, 22), border_radius=4)
        pygame.draw.rect(s, scura(colore, 0.6), (3, 6, 26, 22), width=2, border_radius=4)
        return s

    # ---------------------------------------------------------------- costruzione
    def costruisci(self, mondo, livello):
        """Ritorna (sfondo, oggetti, luci). 'oggetti' = [(linea_dei_piedi, immagine, x, y)] da ordinare."""
        sfondo = _sup(mondo.colonne * T, mondo.righe_n * T)
        oggetti, luci = [], []
        luna = _sup(mondo.colonne * T, mondo.righe_n * T, alpha=True)
        for r in range(mondo.righe_n):
            for c in range(mondo.colonne):
                self._casella(sfondo, luna, oggetti, luci, mondo, livello, c, r)
        sfondo.blit(luna, (0, 0))
        oggetti.sort(key=lambda o: o[0])
        return sfondo, oggetti, luci

    def _stesso(self, mondo, c, r, dc, dr, insieme):
        return mondo.carattere((c + dc, r + dr)) in insieme

    def _pavimento(self, mondo, c, r):
        tipo = mondo.tipo_pavimento((c, r))
        if tipo == "piastrelle":
            return pav_piastrelle(c, r)
        if tipo == "cemento":
            return pav_cemento(c, r)
        if tipo == "erba":
            return pav_erba_fiori(c, r) if mondo.carattere((c, r)) == "x" else pav_erba(c, r)
        if tipo == "pietra":
            return pav_pietra(c, r)
        return pav_legno(c, r)

    def _casella(self, sfondo, luna, oggetti, luci, mondo, livello, c, r):
        ch = mondo.carattere((c, r))
        x, y = c * T, r * T
        if ch in MURI:
            self._muro(sfondo, luna, mondo, livello, c, r, ch)
            return
        if ch == "H":
            tile = _sup()
            disegna_siepe(tile, c, r)
            sfondo.blit(tile, (x, y))
            return
        sfondo.blit(self._pavimento(mondo, c, r), (x, y))
        if ch == "r":
            tile = _sup(alpha=True)
            same = lambda dc, dr: self._stesso(mondo, c, r, dc, dr, "r")
            disegna_tappeto(tile, same(0, -1), same(1, 0), same(0, 1), same(-1, 0))
            sfondo.blit(tile, (x, y))
        elif ch == "d":
            tile = _sup(alpha=True)
            orizzontale = mondo.carattere((c - 1, r)) in MURI and mondo.carattere((c + 1, r)) in MURI
            disegna_porta(tile, orizzontale)
            sfondo.blit(tile, (x, y))
        elif ch == "L":
            self._ombra(sfondo, x, y)
            sfondo.blit(self.k_o_riserva(*self.LETTO, (200, 90, 50)), (x, y))
        elif ch == "I":
            self._ombra(sfondo, x, y)
            sfondo.blit(self.k_o_riserva(*self.LETTINO, (80, 160, 100)), (x, y))
        elif ch in SOLIDI:
            self._mobile(sfondo, oggetti, luci, mondo, livello, c, r, ch)

    def _ombra(self, sfondo, x, y, w=T, h=6):
        ombra = _sup(w, h, alpha=True)
        ombra.fill((0, 0, 0, 55))
        sfondo.blit(ombra, (x, y + T - h + 2))

    def _muro(self, sfondo, luna, mondo, livello, c, r, ch):
        sud = mondo.carattere((c, r + 1))
        faccia = sud not in MURI and sud != "H" and (r + 1) < mondo.righe_n
        tile = _sup()
        if not faccia:
            disegna_muro_alto(tile, c, r)
            sfondo.blit(tile, (c * T, r * T))
            return
        disegna_muro_faccia(tile, c, r, livello.get("muri", "intonaco"), livello.get("colore_muro", (222, 204, 172)))
        if ch == "w":
            disegna_finestra(tile, c, r)
            self._raggio_di_luna(luna, c, r)
        elif ch == "q":
            quadro = self.k(*self.QUADRI[(c * 5 + r * 3) % len(self.QUADRI)])
            if quadro is not None:
                tile.blit(quadro, (0, 2))
        sfondo.blit(tile, (c * T, r * T))

    def _raggio_di_luna(self, luna, c, r):
        """Chiazza di luce azzurra sul pavimento sotto una finestra."""
        pts = [(c * T + 6, (r + 1) * T), (c * T + 26, (r + 1) * T), (c * T + 38, (r + 3) * T), (c * T + 2, (r + 3) * T)]
        pygame.draw.polygon(luna, (170, 200, 255, 34), pts)

    def _mobile(self, sfondo, oggetti, luci, mondo, livello, c, r, ch):
        x, y = c * T, r * T
        S = lambda dc, dr, ins: self._stesso(mondo, c, r, dc, dr, ins)
        img = None
        if ch == "T":
            cx = 1 if (S(-1, 0, "T") and S(1, 0, "T")) else (2 if S(-1, 0, "T") else (0 if S(1, 0, "T") else -1))
            cy = 1 if S(0, -1, "T") else 0
            img = self.k_o_riserva(4, 2, (190, 140, 90)) if cx < 0 else self.k_o_riserva(cx, cy, (190, 140, 90))
        elif ch == "D":
            img = self.k_o_riserva(*self.SCRIVANIA, (176, 120, 72))
        elif ch == "A":
            if S(0, -1, "TD"):
                img = self.k_o_riserva(1, 2, (170, 120, 76))
            elif S(1, 0, "TD"):
                img = self.k_o_riserva(2, 2, (170, 120, 76))
            elif S(-1, 0, "TD"):
                img = self.k_o_riserva(3, 2, (170, 120, 76))
            else:
                img = self.k_o_riserva(0, 2, (170, 120, 76))
        elif ch == "K":
            img = self.k_o_riserva(*self.PENSILI[c % 3], (176, 130, 84))
        elif ch == "N":
            img = self.k_o_riserva(*self.LAVELLO, (180, 190, 200))
        elif ch == "V":
            img = self.k_o_riserva(*self.FORNELLI, (70, 70, 76))
        elif ch == "F":
            img = self.k_o_riserva(*self.FRIGO, (200, 210, 214))
        elif ch == "P":
            img = self.k(*self.PIANTE[(c + r) % 2]) or disegna_pianta_riserva(c, r)
        elif ch == "B":
            img = self.k_o_riserva(*self.LIBRERIE[(c + r) % 3], (150, 100, 60))
        elif ch == "S":
            img = disegna_divano(S(-1, 0, "S"), S(1, 0, "S"), livello.get("divano", (150, 78, 66)))
        elif ch == "W":
            img = disegna_armadio()
        elif ch == "Y":
            img = disegna_water()
        elif ch == "X":
            img = disegna_lavandino()
        elif ch == "U":
            img = disegna_vasca(S(0, -1, "U"), S(1, 0, "U"), S(0, 1, "U"), S(-1, 0, "U"))
        elif ch == "M":
            centro = (S(-1, 0, "M") and S(1, 0, "M")) or not (S(-1, 0, "M") or S(1, 0, "M"))
            img = disegna_mobile_tv(centro, (236, 200, 110))
            if centro:
                luci.append((x + 16, y + 6, 70))
        elif ch == "Z":
            img = disegna_albero()
            oggetti.append(((r + 1) * T, img, x + 16 - 32, (r + 1) * T - 84))
            return
        elif ch == "p":
            img = disegna_pilastro()
        if img is None:
            return
        if ch not in "ZY X":
            self._ombra(sfondo, x, y, T, 5)
        oggetti.append(((r + 1) * T, img, x, (r + 1) * T - img.get_height()))


# -----------------------------------------------------------------------------
#  Personaggi che camminano (fogli di fotogrammi)
# -----------------------------------------------------------------------------
class FoglioPersonaggio:
    """Fotogrammi di camminata per le 4 direzioni (righe: su, sinistra, giu, destra)."""

    def __init__(self, frames, passo_px, ciclo_da):
        self.frames = frames
        self.passo_px = passo_px
        self.ciclo_da = ciclo_da
        self.n = len(frames[0])
        self.piede = max(f.get_bounding_rect().bottom for riga in frames for f in riga)
        self.largo = frames[0][0].get_width()

    def fotogramma(self, faccia, fermo, distanza_percorsa):
        riga = self.frames[RIGA_SPRITE.get(faccia, 2)]
        if fermo:
            return riga[0]
        passi = self.n - self.ciclo_da
        return riga[self.ciclo_da + int(distanza_percorsa / self.passo_px) % passi]


def _taglia(img, w, h, colonne, righe):
    return [[img.subsurface((i * w, r * h, w, h)).copy() for i in range(colonne)] for r in range(righe)]


def carica_foglio_lpc(nome, colore):
    img = carica_immagine(nome)
    if img is not None and img.get_width() >= 576 and img.get_height() >= 256:
        return FoglioPersonaggio(_taglia(img, 64, 64, 9, 4), 6.0, 1)
    return foglio_riserva_persona(colore)


def carica_foglio_gatto(nome):
    img = carica_immagine(nome)
    if img is not None and img.get_width() >= 160 and img.get_height() >= 128:
        return FoglioPersonaggio(_taglia(img, 40, 32, 4, 4), 6.0, 0)
    return foglio_riserva_gatto()


def foglio_riserva_persona(colore):
    """Omino semplice (testa, corpo, due gambe) usato se manca il PNG dei personaggi."""
    frames = []
    for _ in range(4):
        riga = []
        for i in range(9):
            s = pygame.Surface((64, 64), pygame.SRCALPHA)
            passo = 0 if i == 0 else int(math.sin(i / 8 * 2 * math.pi) * 5)
            pygame.draw.rect(s, scura(colore, 0.5), (24 + passo // 2, 44, 6, 12))
            pygame.draw.rect(s, scura(colore, 0.5), (34 - passo // 2, 44, 6, 12))
            pygame.draw.rect(s, colore, (22, 24, 20, 22), border_radius=4)
            pygame.draw.circle(s, (240, 200, 160), (32, 18), 9)
            riga.append(s)
        frames.append(riga)
    return FoglioPersonaggio(frames, 6.0, 1)


def foglio_riserva_gatto():
    frames = []
    for _ in range(4):
        riga = []
        for i in range(4):
            s = pygame.Surface((40, 32), pygame.SRCALPHA)
            passo = (-3, 0, 3, 0)[i]
            pygame.draw.ellipse(s, (140, 146, 158), (6, 8, 28, 14))
            pygame.draw.circle(s, (140, 146, 158), (32, 10), 7)
            for x in (10, 14, 24, 28):
                pygame.draw.rect(s, (110, 116, 128), (x + passo, 20, 3, 9))
            riga.append(s)
        frames.append(riga)
    return FoglioPersonaggio(frames, 6.0, 0)


# -----------------------------------------------------------------------------
#  Suoni veri (cartella "suoni") sopra a quelli generati dal gioco
# -----------------------------------------------------------------------------
class SuoniReali(Suoni):
    """Aggiunge passi, porte, miagolii e la risata di Tamiyo; se un file manca usa i suoni generati."""

    NOTE = dict(Suoni.NOTE, sospetta=[(700, 60), (950, 90)], glup=[(260, 70), (170, 120)],
                pop=[(900, 25), (1300, 35)],
                chiama=[(494, 110), (587, 90), (659, 190)],
                gorgoglio=[(80, 80), (110, 60), (70, 100), (95, 70), (60, 140)],
                sforzo=[(160, 90), (130, 120), (110, 150)],
                sciacquone=[(300, 300), (260, 300), (220, 400), (200, 500)])
    CAMPIONI = {
        "passo_legno": (("passo_legno_1.ogg", "passo_legno_2.ogg", "passo_legno_3.ogg", "passo_legno_4.ogg"), 0.35),
        "passo_erba": (("passo_erba_1.ogg", "passo_erba_2.ogg"), 0.30),
        "porta": (("porta.ogg",), 0.45),
        "colpo": (("colpo.ogg",), 0.6),
        "oggetto": (("oggetto.ogg",), 0.5),
        "risata": (("risata_gatto.ogg",), 0.9),
        "miagolio": (("miagolio.ogg",), 0.8),
        "gattino": (("gattino.ogg",), 0.7),
        "interruttore": (("interruttore.ogg",), 0.5),
        "acqua": (("acqua.ogg",), 0.5),
    }
    ALIAS = {"gatto": "miagolio"}

    def __init__(self, attivi):
        super().__init__(attivi)
        self.campioni = {}
        self.ambiente = None
        self.ambiente_voluto = False
        if self.canale is None:
            return
        for nome, (files, volume) in self.CAMPIONI.items():
            lista = []
            for f in files:
                percorso = CARTELLA_SUONI / f
                if not percorso.is_file():
                    continue
                try:
                    suono = pygame.mixer.Sound(str(percorso))
                    suono.set_volume(volume)
                    lista.append(suono)
                except pygame.error as errore:
                    print(f"[Suono {f} non leggibile: {errore}]")
            if lista:
                self.campioni[nome] = lista
        percorso = CARTELLA_SUONI / "ambiente_notte.ogg"
        if percorso.is_file():
            try:
                self.ambiente = pygame.mixer.Sound(str(percorso))
                self.ambiente.set_volume(0.22)
            except pygame.error as errore:
                print(f"[Suono ambiente non leggibile: {errore}]")

    def gioca(self, nome):
        if not self.attivo:
            return
        if nome == "sciacquone" and "acqua" in self.campioni:
            self.campioni["acqua"][0].play(maxtime=2300, fade_ms=120)
            return
        nome = self.ALIAS.get(nome, nome)
        if nome in self.campioni:
            random.choice(self.campioni[nome]).play()
        else:
            super().gioca(nome)

    def durata(self, nome, predefinita=1.6):
        if nome in self.campioni:
            return self.campioni[nome][0].get_length()
        return predefinita

    def imposta_ambiente(self, acceso):
        if acceso == self.ambiente_voluto:
            return
        self.ambiente_voluto = acceso
        self._applica_ambiente()

    def _applica_ambiente(self):
        if self.ambiente is None or pygame.mixer.get_init() is None:
            return
        canale = pygame.mixer.Channel(1)
        canale.stop()
        if self.attivo and self.ambiente_voluto:
            canale.play(self.ambiente, loops=-1)

    def on_off(self):
        stato = super().on_off()
        self._applica_ambiente()
        return stato

    def pausa_musica(self, in_pausa):
        super().pausa_musica(in_pausa)
        if self.ambiente is not None and pygame.mixer.get_init() is not None:
            canale = pygame.mixer.Channel(1)
            if in_pausa:
                canale.pause()
            else:
                canale.unpause()


# -----------------------------------------------------------------------------
#  Personaggi
# -----------------------------------------------------------------------------
class Ale:
    """Ale cammina liberamente (non a caselle) ed e' fermato da muri e mobili."""

    def __init__(self, x, y):
        self.partenza = (x, y)
        self.reset()

    def reset(self):
        self.x, self.y = self.partenza
        self.faccia = GIU
        self.fermo = True
        self.distanza = 0.0

    @property
    def cella(self):
        return (int(self.x // T), int((self.y - 6) // T))

    def _libero(self, mondo, x, y):
        for px, py in ((x - 7, y - 8), (x + 7, y - 8), (x - 7, y - 1), (x + 7, y - 1)):
            if not mondo.libera((int(px // T), int(py // T))):
                return False
        return True

    def muovi(self, dt, vx, vy, mondo, velocita):
        """Ritorna i pixel percorsi in questo istante."""
        self.fermo = not (vx or vy)
        if self.fermo:
            return 0.0
        if vx and vy:
            vx, vy = vx * 0.7071, vy * 0.7071
        px, py = self.x, self.y
        nx = self.x + vx * velocita * dt
        if self._libero(mondo, nx, self.y):
            self.x = nx
        ny = self.y + vy * velocita * dt
        if self._libero(mondo, self.x, ny):
            self.y = ny
        fatto = distanza((px, py), (self.x, self.y))
        if vx:
            self.faccia = DESTRA if vx > 0 else SINISTRA
        elif vy:
            self.faccia = GIU if vy > 0 else SU
        self.fermo = fatto < 0.01
        self.distanza += fatto
        return fatto


class Personaggio:
    """Eli e Tamiyo: si muovono di casella in casella in modo fluido."""

    def __init__(self, cella, velocita_px):
        self.partenza = cella
        self.velocita = velocita_px / T
        self.reset()

    def reset(self):
        self.cella = self.partenza
        self.verso = None
        self.progresso = 0.0
        self.dir = (0, 0)
        self.faccia = GIU
        self.distanza = 0.0
        self.fermo = True

    def imposta_velocita_px(self, velocita_px):
        self.velocita = velocita_px / T

    def piedi(self):
        x, y = self.cella
        if self.verso is not None:
            x += (self.verso[0] - self.cella[0]) * self.progresso
            y += (self.verso[1] - self.cella[1]) * self.progresso
        return ((x + 0.5) * T, (y + 0.5) * T + 11)

    def cella_attuale(self):
        if self.verso is not None and self.progresso >= 0.5:
            return self.verso
        return self.cella

    def scegli(self, mondo):
        raise NotImplementedError

    def muovi(self, dt, mondo):
        restante = self.velocita * dt
        mosso = False
        while restante > 1e-9:
            if self.verso is None:
                d = self.scegli(mondo)
                if d is None or not mondo.libera(somma(self.cella, d)):
                    break
                self.dir = d
                self.verso = somma(self.cella, d)
                self.progresso = 0.0
            passo = min(restante, 1.0 - self.progresso)
            self.progresso += passo
            restante -= passo
            mosso = True
            self.distanza += passo * T
            if self.progresso >= 1.0 - 1e-9:
                self.cella = self.verso
                self.verso = None
                self.progresso = 0.0
        self.fermo = not mosso
        if mosso and self.dir != (0, 0):
            self.faccia = self.dir

    def opzioni(self, mondo):
        opz = mondo.vicini(self.cella)
        if len(opz) > 1 and self.dir != (0, 0):
            senza_indietro = [o for o in opz if o[0] != opposto(self.dir)]
            opz = senza_indietro or opz
        return opz

    def verso_la_meta(self, mondo, opz, meta):
        dist = mondo.distanze(meta)
        migliore = min(dist.get(c, 10 ** 6) for _, c in opz)
        return random.choice([d for d, c in opz if dist.get(c, 10 ** 6) == migliore])


class Elisa(Personaggio):
    def __init__(self, cella):
        self.meta = cella
        self.errore = 0.0
        self.sosta = 0.0
        super().__init__(cella, VELOCITA_ELISA_GIRO)

    def reset(self):
        super().reset()
        self.sosta = 0.0
        self.meta = self.partenza

    def scegli(self, mondo):
        opz = self.opzioni(mondo)
        if not opz:
            return None
        if random.random() < self.errore:
            return random.choice(opz)[0]
        return self.verso_la_meta(mondo, opz, self.meta)


class Gatto(Personaggio):
    def __init__(self, cella):
        self.bersaglio = cella
        self.curiosita = 0.35
        super().__init__(cella, VELOCITA_GATTO)

    def scegli(self, mondo):
        opz = self.opzioni(mondo)
        if not opz:
            return None
        if random.random() < self.curiosita:
            return self.verso_la_meta(mondo, opz, self.bersaglio)
        return random.choice(opz)[0]


# -----------------------------------------------------------------------------
#  Effetti (particelle, testi che volano)
# -----------------------------------------------------------------------------
def disegna_cuore(colore, scala=1):
    s = pygame.Surface((9 * scala, 8 * scala), pygame.SRCALPHA)
    for (x, y) in ((2, 2), (6, 2)):
        pygame.draw.circle(s, colore, (x * scala, y * scala + scala), 2 * scala)
    pygame.draw.polygon(s, colore, [(0, 3 * scala), (9 * scala, 3 * scala), (4 * scala + scala // 2, 8 * scala)])
    return s


class Effetti:
    def __init__(self):
        self.lista = []
        self.cuore_rosa = disegna_cuore((255, 110, 170))
        self.goccia_img = pygame.Surface((9, 12), pygame.SRCALPHA)
        disegna_goccia(self.goccia_img, 4.5, 4, 1.2)

    def testo(self, x, y, img, vita=0.9):
        self.lista.append({"k": "img", "x": x, "y": y, "vx": 0, "vy": -34, "t": 0.0, "d": vita, "img": img})

    def scintille(self, x, y, colore, n=7):
        for _ in range(n):
            a = random.uniform(0, 2 * math.pi)
            v = random.uniform(30, 80)
            self.lista.append({"k": "punto", "x": x, "y": y, "vx": math.cos(a) * v, "vy": math.sin(a) * v - 20,
                               "t": 0.0, "d": random.uniform(0.3, 0.55), "col": colore})

    def cuori(self, x, y, n=8):
        for _ in range(n):
            self.lista.append({"k": "img", "x": x + random.uniform(-10, 10), "y": y + random.uniform(-6, 6),
                               "vx": random.uniform(-30, 30), "vy": random.uniform(-80, -40), "t": 0.0,
                               "d": random.uniform(0.7, 1.2), "img": self.cuore_rosa})

    def sudore(self, x, y):
        self.lista.append({"k": "img", "x": x, "y": y, "vx": random.uniform(-8, 8), "vy": 22, "t": 0.0,
                           "d": 0.8, "img": self.goccia_img})

    def polvere(self, x, y):
        self.lista.append({"k": "polvere", "x": x + random.uniform(-3, 3), "y": y, "vx": random.uniform(-6, 6),
                           "vy": -8, "t": 0.0, "d": 0.35, "col": (206, 190, 160)})

    def aggiorna(self, dt):
        vive = []
        for p in self.lista:
            p["t"] += dt
            if p["t"] < p["d"]:
                p["x"] += p["vx"] * dt
                p["y"] += p["vy"] * dt
                if p["k"] == "punto":
                    p["vy"] += 160 * dt
                vive.append(p)
        self.lista = vive

    def disegna(self, s):
        for p in self.lista:
            alfa = max(0.0, 1.0 - p["t"] / p["d"])
            if p["k"] == "img":
                img = p["img"]
                img.set_alpha(int(255 * min(1.0, alfa * 1.6)))
                s.blit(img, img.get_rect(center=(int(p["x"]), int(p["y"]))))
                img.set_alpha(255)
            elif p["k"] == "punto":
                pygame.draw.rect(s, p["col"], (int(p["x"]), int(p["y"]), 2, 2))
            elif p["k"] == "polvere":
                r = 2 + int((1 - alfa) * 4)
                macchia = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
                pygame.draw.circle(macchia, p["col"] + (int(110 * alfa),), (r, r), r)
                s.blit(macchia, (int(p["x"]) - r, int(p["y"]) - r))


# -----------------------------------------------------------------------------
#  Scena iniziale: Ale preoccupato, Tamiyo che ride, Eli che sorride
# -----------------------------------------------------------------------------
def disegna_goccia(s, x, y, scala):
    """Goccia di sudore azzurra (punta in alto)."""
    pygame.draw.circle(s, (150, 210, 255), (int(x), int(y + 2.5 * scala)), int(2.6 * scala))
    pygame.draw.polygon(s, (150, 210, 255), [(x - 2.4 * scala, y + 2 * scala), (x + 2.4 * scala, y + 2 * scala),
                                              (x, y - 3 * scala)])
    pygame.draw.circle(s, (235, 248, 255), (int(x - 0.9 * scala), int(y + 2 * scala)), max(1, int(0.8 * scala)))


def disegna_zampina(scala):
    """Zampina di gatto vista da davanti (la usa Tamiyo per coprirsi la bocca mentre ride)."""
    w, h = 24, 28
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    pelo, chiaro, scuro, cuscinetto = (152, 156, 168), (190, 194, 204), (36, 38, 50), (226, 150, 158)
    pygame.draw.ellipse(s, scuro, (3, 12, 18, 18))
    pygame.draw.ellipse(s, pelo, (4, 13, 16, 17))
    for (x, y) in ((6, 9), (12, 7), (18, 9)):
        pygame.draw.circle(s, scuro, (x, y), 4)
        pygame.draw.circle(s, pelo, (x, y), 3)
        pygame.draw.circle(s, chiaro, (x - 1, y - 1), 1)
    pygame.draw.ellipse(s, cuscinetto, (8, 15, 9, 7))
    for (x, y) in ((8, 11), (12, 9), (16, 11)):
        s.set_at((x, y + 1), cuscinetto)
    return pygame.transform.scale(s, (int(w * scala), int(h * scala)))


class Intro:
    """Animazione della schermata iniziale. Dopo la risata di Tamiyo si ripete ogni tanto."""

    PERIODO = 11.0
    INIZIO_RISATA = 1.7

    def __init__(self, suoni, f_titolo, f_testo, f_piccolo, f_bubble):
        self.suoni = suoni
        self.f_titolo, self.f_testo, self.f_piccolo, self.f_bubble = f_titolo, f_testo, f_piccolo, f_bubble
        self.lato = {"ale": 288, "eli": 216, "tamiyo": 216}
        self.img = {}
        for nome, lato in self.lato.items():
            img = carica_immagine(f"intro/{nome}.png")
            if img is not None and img.get_size() != (lato, lato):
                img = pygame.transform.smoothscale(img, (lato, lato))
            self.img[nome] = img
        self.durata_risata = suoni.durata("risata", 1.6)
        self.zampa = {}
        self.t = 0.0
        self.ciclo = -1
        self.glup_fatto = self.risata_fatta = False
        self.stelle = [(random.Random(i).randint(8, 760), random.Random(i * 7).randint(6, 330), i * 0.7) for i in range(46)]
        self.sfondo = None

    def riavvia(self):
        self.t = 0.0
        self.ciclo = -1

    def aggiorna(self, dt):
        self.t += dt
        ciclo = int(self.t // self.PERIODO)
        if ciclo != self.ciclo:
            self.ciclo = ciclo
            self.glup_fatto = self.risata_fatta = False
        fase = self.t % self.PERIODO
        if not self.glup_fatto and fase >= 0.9:
            self.glup_fatto = True
            self.suoni.gioca("glup")
        if not self.risata_fatta and fase >= self.INIZIO_RISATA:
            self.risata_fatta = True
            self.suoni.gioca("risata")

    # ------------------------------------------------------------------ disegno
    def _sfondo(self, w, h):
        if self.sfondo is None or self.sfondo.get_size() != (w, h):
            s = pygame.Surface((w, h))
            for y in range(h):
                f = y / h
                pygame.draw.line(s, (int(14 + 26 * f), int(16 + 28 * f), int(44 + 52 * f)), (0, y), (w, y))
            pygame.draw.rect(s, (46, 34, 56), (0, h - 70, w, 70))
            pygame.draw.rect(s, (30, 22, 40), (0, h - 70, w, 5))
            self.sfondo = s
        return self.sfondo

    def _bubble(self, s, testo, centro, pop=1.0, inclina=0):
        img = self.f_bubble.render(testo, True, (20, 20, 30))
        w, h = img.get_width() + 22, img.get_height() + 14
        fondo = pygame.Surface((w, h + 12), pygame.SRCALPHA)
        pygame.draw.rect(fondo, (250, 250, 252), (0, 0, w, h), border_radius=10)
        pygame.draw.rect(fondo, (20, 20, 30), (0, 0, w, h), width=3, border_radius=10)
        pygame.draw.polygon(fondo, (250, 250, 252), [(w // 2 - 7 + inclina, h - 2), (w // 2 + 7 + inclina, h - 2),
                                                      (w // 2 + inclina, h + 11)])
        pygame.draw.lines(fondo, (20, 20, 30), False, [(w // 2 - 7 + inclina, h - 2), (w // 2 + inclina, h + 11),
                                                       (w // 2 + 7 + inclina, h - 2)], 3)
        fondo.blit(img, (11, 7))
        if pop < 1.0:
            nuova = (max(1, int(fondo.get_width() * pop)), max(1, int(fondo.get_height() * pop)))
            fondo = pygame.transform.scale(fondo, nuova)
        s.blit(fondo, fondo.get_rect(midbottom=(centro[0], centro[1])))

    def _ritratto(self, nome, colore, pos, offset=(0, 0), angolo=0, extra=None):
        img = self.img[nome]
        if img is None:
            lato = self.lato[nome]
            img = pygame.Surface((lato, lato), pygame.SRCALPHA)
            pygame.draw.rect(img, colore, img.get_rect(), border_radius=20)
        s = img.copy()
        sc = s.get_width() / 72.0
        if extra is not None:
            extra(s, sc)
        pygame.draw.rect(s, colore, s.get_rect(), width=max(3, int(sc * 2.6)), border_radius=int(s.get_width() * 0.09))
        if angolo:
            s = pygame.transform.rotate(s, angolo)
        return s, (pos[0] + offset[0], pos[1] + offset[1])

    def disegna(self, s, record, lampeggia):
        W, H = s.get_size()
        t = self.t
        fase = t % self.PERIODO
        s.blit(self._sfondo(W, H), (0, 0))
        self._cielo(s, W, t)
        self._eli(s, W, H, t, fase)
        self._tamiyo(s, W, H, t, fase)
        self._ale(s, W, H, t, fase)
        self._testi(s, W, H, t, record, lampeggia)
        if t < 0.9:
            velo = pygame.Surface((W, H))
            velo.set_alpha(int(255 * (1 - t / 0.9)))
            s.blit(velo, (0, 0))

    def _cielo(self, s, W, t):
        for (x, y, ph) in self.stelle:
            if math.sin(t * 2.2 + ph) > -0.2:
                s.set_at((x, y), (230, 235, 255))
                if math.sin(t * 2.2 + ph) > 0.8:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        s.set_at((x + dx, y + dy), (150, 160, 200))
        pygame.draw.circle(s, (250, 246, 214), (W - 84, 76), 26)
        pygame.draw.circle(s, (30, 38, 84), (W - 72, 68), 22)

    def _eli(self, s, W, H, t, fase):
        pos = (W - 252, 150)
        dy = math.sin(t * 2.1) * 2.5
        img, p = self._ritratto("eli", ROSA, pos, (0, dy), math.sin(t * 1.3) * 1.2)
        s.blit(img, img.get_rect(center=(p[0] + 108, p[1] + 108)))
        # cuoricini che salgono ogni tanto
        for k in range(3):
            ft = (t * 0.55 + k / 3.0) % 1.0
            if t > 0.8:
                cuore = disegna_cuore((255, 110, 170), 2)
                cuore.set_alpha(int(255 * (1 - ft)))
                s.blit(cuore, (p[0] + 20 + k * 70 + math.sin(ft * 6 + k) * 8, p[1] + 30 - ft * 70))

    def _tamiyo(self, s, W, H, t, fase):
        pos = (W // 2 - 108 + 14, 170)
        lt = fase - self.INIZIO_RISATA
        ride = 0 <= lt <= self.durata_risata
        sale = 0 <= lt <= self.durata_risata + 0.35
        dy = -abs(math.sin(lt * 17)) * 7 if ride else math.sin(t * 1.7) * 1.5
        ang = math.sin(lt * 13) * 3.5 if ride else 0

        def extra(sup, sc):
            if ride:
                for (ex, ey) in ((24.5, 39.5), (46.8, 40)):
                    pygame.draw.ellipse(sup, (122, 126, 138), (int((ex - 7.5) * sc), int((ey - 4) * sc), int(15 * sc), int(8 * sc)))
                    punti = [((ex - 6) * sc, (ey + 2) * sc), ((ex - 3) * sc, (ey - 1) * sc), (ex * sc, (ey - 2.2) * sc),
                             ((ex + 3) * sc, (ey - 1) * sc), ((ex + 6) * sc, (ey + 2) * sc)]
                    pygame.draw.lines(sup, (30, 32, 44), False, punti, max(2, int(2 * sc)))
                    gocciolina = (lt * 2.4 + ex) % 1.0
                    pygame.draw.circle(sup, (170, 220, 255), (int((ex + (4 if ex > 30 else -4)) * sc), int((ey + 3 + gocciolina * 8) * sc)), max(1, int(sc)))
            if sale:
                salita = 1.0 - min(1.0, max(0.0, lt / 0.18)) if lt < 0.18 else (min(1.0, (lt - self.durata_risata) / 0.3) if lt > self.durata_risata else 0.0)
                tremolio = math.sin(lt * 40) * (1.2 if ride else 0)
                if sc not in self.zampa:
                    self.zampa[sc] = disegna_zampina(sc)
                z = self.zampa[sc]
                sup.blit(z, (int(36.7 * sc - z.get_width() / 2 + tremolio * sc), int((45 + salita * 24) * sc)))

        img, p = self._ritratto("tamiyo", ARANCIO, pos, (0, dy), ang, extra)
        s.blit(img, img.get_rect(center=(p[0] + 108, p[1] + 108)))
        if ride and lt > 0.2:
            pop = min(1.0, (lt - 0.2) / 0.18)
            ritmo = "hi hi hi hi!" if int(lt * 6) % 2 == 0 else "hi hi hi!"
            self._bubble(s, ritmo, (p[0] + 150, p[1] + 20 - abs(math.sin(lt * 12)) * 4), pop, 20)

    def _ale(self, s, W, H, t, fase):
        pos = (10, H - 300)
        agita = 1.0 + (0.6 if 0.9 <= fase <= 2.6 else 0.0)
        dx, dy = math.sin(t * 47) * 1.7 * agita, math.sin(t * 31 + 1) * 1.3 * agita
        respiro = math.sin(t * 5) * 3

        def extra(sup, sc):
            for k in range(3):
                ft = (t * 0.7 + k / 3.0) % 1.0
                x = (24 + k * 12 + math.sin(ft * 7 + k) * 2) * sc
                disegna_goccia(sup, x, (11 + ft * 36) * sc, sc * 0.9)
            ft = (t * 0.5) % 1.0
            disegna_goccia(sup, 56 * sc, (30 + ft * 26) * sc, sc * 0.8)

        img, p = self._ritratto("ale", GIALLO, pos, (dx, dy + respiro * 0.3), 0, extra)
        s.blit(img, img.get_rect(center=(p[0] + 144, p[1] + 144)))
        if 0.9 <= fase <= 2.7:
            pop = min(1.0, (fase - 0.9) / 0.2)
            self._bubble(s, "glup...", (p[0] + 190, p[1] + 14), pop, -14)

    def _testi(self, s, W, H, t, record, lampeggia):
        desl = min(1.0, t / 0.7)
        y = int(-60 + 96 * (1 - (1 - desl) ** 3))
        for riga, colore, dy in (("Non ero calcolato!..", GIALLO, 0), ("Bei tempi!", ROSA, 44)):
            img = self.f_titolo.render(riga, True, colore)
            ombra = self.f_titolo.render(riga, True, (0, 0, 0))
            r = img.get_rect(center=(W // 2, y + dy))
            s.blit(ombra, r.move(3, 3))
            s.blit(img, r)
        istruzioni = ("Frecce / WASD  cammina", "SPAZIO  dai una crocchetta a Tamiyo",
                      "P pausa     M suoni     ESC esci")
        for i, riga in enumerate(istruzioni):
            img = self.f_piccolo.render(riga, True, BIANCO)
            s.blit(img, (W - img.get_width() - 24, H - 140 + i * 22))
        if t > 2.6 and lampeggia:
            img = self.f_testo.render(getattr(self, "invito", "PREMI INVIO"), True, GIALLO)
            s.blit(img, img.get_rect(center=(W - 160, H - 34)))
        rec = self.f_piccolo.render(f"RECORD {record:06d}", True, ROSA)
        s.blit(rec, rec.get_rect(midleft=(312, H - 34)))


# -----------------------------------------------------------------------------
#  Il gioco vero e proprio
# -----------------------------------------------------------------------------
TIPI_RICHIESTA = {
    "gatto_crocchini": {"chi": "gatto", "bolla": "Miao!", "colore": GIALLO, "scheda": "TAMIYO: CROCCHINI",
                        "inizio": ("Tamiyo vuole i crocchini!", "Premi SPAZIO per dargliene uno.")},
    "gatto_coccole": {"chi": "gatto", "bolla": "Prrr?", "colore": ROSA, "scheda": "TAMIYO: COCCOLE",
                      "inizio": ("Tamiyo vuole le coccole!", "Stalle vicino e tieni premuto SPAZIO.")},
    "gatto_scatoletta": {"chi": "gatto", "bolla": "MIAAO!", "colore": AZZURRO, "scheda": "TAMIYO: SCATOLETTA",
                         "inizio": ("Tamiyo vuole una scatoletta!", "Ce ne sono in giardino: portagliela.")},
    "eli_attenzioni": {"chi": "eli", "bolla": "Ale?", "colore": ROSA, "scheda": "ELI: ATTENZIONI",
                       "inizio": ("Eli vuole un po' di attenzioni!", "Sta venendo da te: restale vicino.")},
    "eli_aiuto": {"chi": "eli", "bolla": "Aiuto?", "colore": (170, 230, 255), "scheda": "ELI: AIUTO",
                  "inizio": ("Eli ha bisogno di una mano!", "Sta venendo da te...")},
}
OGGETTI_AIUTO = (("il caricatore", (230, 230, 240), "CARICATORE"), ("un asciugamano", (120, 200, 230), "ASCIUGAMANO"),
                 ("il telecomando", (70, 70, 84), "TELECOMANDO"), ("un bicchiere d'acqua", (150, 210, 255), "ACQUA"),
                 ("il plaid", (210, 100, 100), "PLAID"), ("le chiavi", (240, 200, 70), "CHIAVI"),
                 ("gli occhiali", (160, 110, 70), "OCCHIALI"), ("il telefono", (100, 100, 130), "TELEFONO"))


def disegna_oggetto_aiuto(colore):
    """Un pacchettino colorato: l'oggetto che Eli ti chiede di portarle."""
    s = pygame.Surface((18, 18), pygame.SRCALPHA)
    pygame.draw.ellipse(s, (0, 0, 0, 70), (2, 14, 14, 4))
    pygame.draw.rect(s, scura(colore, 0.55), (2, 4, 14, 11), border_radius=2)
    pygame.draw.rect(s, colore, (3, 5, 12, 9), border_radius=2)
    pygame.draw.rect(s, (255, 255, 255), (8, 4, 2, 11))
    pygame.draw.rect(s, (255, 255, 255), (3, 8, 12, 2))
    return s


class Richiesta:
    """Qualcosa che Eli o Tamiyo vogliono da Ale, con la loro pazienza che scende."""

    def __init__(self, tipo, pazienza):
        info = TIPI_RICHIESTA[tipo]
        self.tipo = tipo
        self.chi = info["chi"]
        self.pazienza = self.totale = pazienza
        self.attiva = self.chi == "gatto"      # Eli diventa 'attiva' quando ti raggiunge
        self.progresso = 0.0
        self.oggetto = None
        self.breve = ""
        self.cella = None
        self.colore_oggetto = BIANCO

    @property
    def scheda(self):
        if self.oggetto:
            return f"ELI: PORTA {self.breve}"
        return TIPI_RICHIESTA[self.tipo]["scheda"]

    @property
    def bolla(self):
        return TIPI_RICHIESTA[self.tipo]["bolla"]

    @property
    def colore(self):
        return TIPI_RICHIESTA[self.tipo]["colore"]


class Gioco:
    def __init__(self, finestra, mondi):
        self.finestra = finestra
        self.mondi = mondi
        self.larghezza = mondi[0].colonne * T
        self.altezza_mondo = mondi[0].righe_n * T
        self.dimensione = (self.larghezza, ALTEZZA_BARRA_ALTA + self.altezza_mondo + ALTEZZA_BARRA_BASSA)
        self.canvas = pygame.Surface(self.dimensione, 0, 32)
        self.vista = pygame.Surface((self.larghezza, self.altezza_mondo), 0, 32)
        self.clock = pygame.time.Clock()
        self.suoni = SuoniReali(SUONI_ATTIVI)
        self._prepara_font()
        self._prepara_immagini()
        self.arte = Arte()
        self.record = self._leggi_record()
        self.effetti = Effetti()
        self.intro = Intro(self.suoni, self.f_titolo, self.f_grande, self.f_msg, self.f_bubble)
        self.ultimo_tasto = None
        self.stato = "titolo"
        self.stato_prima_pausa = "gioco"
        self.esito = None
        self.tempo_totale = 0.0
        self.punti = 0
        self.punti_inizio_livello = 0
        self.scossa = 0.0
        self.lampo = 0.0
        self.pausa_colpo = 0.0
        self.testi_cache = {}
        self.luci_cache = {}
        self.arte_livelli = {}
        self.attesa_fine = 0.0
        self.mostra_controlli = False
        self.tocchi = {}
        self._scala_vista = 1.0
        self._off_vista = (0, 0)
        self._controlli_img = None
        self.consigli = set()
        self.senza_raccolta = 0.0
        self._buio = self._crt_cache = self._velo_pannello = None
        self._imposta_livello(0)
        self._avvia_livello(avvia=False)

    # ------------------------------------------------------------ preparazione
    @staticmethod
    def _font(dimensione):
        """Un font tipo macchina da scrivere (incluso nel gioco); se manca ne cerca uno di sistema."""
        ttf = CARTELLA_FONT / "Cousine-Bold.ttf"
        try:
            if ttf.is_file():
                return pygame.font.Font(str(ttf), dimensione)
        except (pygame.error, OSError):
            pass
        try:
            return pygame.font.SysFont("couriernew,consolas,lucidaconsole,monospace", dimensione, bold=True)
        except (pygame.error, OSError):
            return pygame.font.Font(None, dimensione + 6)

    def _prepara_font(self):
        self.f_titolo = self._font(40)
        self.f_grande = self._font(24)
        self.f_hud = self._font(19)
        self.f_msg = self._font(16)
        self.f_bubble = self._font(22)
        self.f_piccolo = self._font(13)

    def _prepara_immagini(self):
        self.foglio_ale = carica_foglio_lpc(FILE_ALE_CAMMINATA, (240, 240, 240))
        self.foglio_eli = carica_foglio_lpc(FILE_ELISA_CAMMINATA, (80, 160, 90))
        self.foglio_gatto = carica_foglio_gatto(FILE_GATTO_CAMMINATA)
        self.ale_seduto = {chiave: self._carica_seduto(nome) for chiave, nome in
                           (("vestito", FILE_ALE_SEDUTO_VESTITO), ("nudo", FILE_ALE_SEDUTO_NUDO))}
        self._seduto_cache = {}
        self.ritratti = {}
        for chi, nome in (("ale", FILE_RITRATTO_ALE), ("eli", FILE_RITRATTO_ELISA), ("gatto", FILE_RITRATTO_GATTO)):
            img = carica_immagine(nome)
            if img is not None:
                img = pygame.transform.smoothscale(img, (48, 48))
            self.ritratti[chi] = img
        self.img_croc = disegna_crocchetta()
        self.img_scat = disegna_scatoletta()
        self.img_croc_hud = pygame.transform.scale(self.img_croc, (21, 17))
        self.img_luna = self._bitmap(LUNA, AZZURRO, 3)

    @staticmethod
    def _carica_seduto(nome):
        """La posa 'seduto su una sedia' (terzo fotogramma della riga 'giu') del foglio sit."""
        img = carica_immagine(nome)
        if img is None or img.get_width() < 192 or img.get_height() < 192:
            return None
        return img.subsurface((128, 128, 64, 64)).copy()

    def _ale_seduto(self, fase):
        """Ale sul water. fase 0 = pantaloni su, 1 = ai ginocchi, 2 = alle caviglie."""
        if fase in self._seduto_cache:
            return self._seduto_cache[fase]
        vestito, nudo = self.ale_seduto["vestito"], self.ale_seduto["nudo"]
        if vestito is None or nudo is None:
            img = self.foglio_ale.fotogramma(GIU, True, 0)
        elif fase == 0:
            img = vestito
        else:
            img = nudo.copy()
            r = nudo.get_bounding_rect()
            jeans, scuro = (58, 86, 172), (30, 50, 116)
            if fase == 1:
                y = r.top + int(r.height * 0.62)
                pygame.draw.rect(img, jeans, (r.centerx - 11, y, 22, 7), border_radius=2)
                pygame.draw.rect(img, scuro, (r.centerx - 11, y, 22, 7), width=1, border_radius=2)
            else:
                y = r.bottom - 9
                for dx in (-8, 8):
                    pygame.draw.ellipse(img, jeans, (r.centerx + dx - 6, y, 12, 7))
                    pygame.draw.ellipse(img, scuro, (r.centerx + dx - 6, y, 12, 7), 1)
        self._seduto_cache[fase] = img
        return img

    @staticmethod
    def _bitmap(righe, colore, scala):
        s = pygame.Surface((len(righe[0]) * scala, len(righe) * scala), pygame.SRCALPHA)
        for y, riga in enumerate(righe):
            for x, ch in enumerate(riga):
                if ch == "X":
                    pygame.draw.rect(s, colore, (x * scala, y * scala, scala, scala))
        return s

    def _leggi_record(self):
        try:
            if WEB:
                import platform
                return int(platform.window.localStorage.getItem("crocchette_record") or 0)
            return int(FILE_RECORD.read_text().strip())
        except (OSError, ValueError, AttributeError, TypeError, ImportError):
            return 0

    def _salva_record(self):
        try:
            if WEB:
                import platform
                platform.window.localStorage.setItem("crocchette_record", str(self.record))
            else:
                FILE_RECORD.write_text(str(self.record))
        except (OSError, AttributeError, TypeError, ImportError) as errore:
            print(f"[Non riesco a salvare il record: {errore}]")

    def _luce(self, raggio):
        """Cerchio di luce con bordo morbido (usato per la torcia di Ale e per la TV)."""
        if raggio not in self.luci_cache:
            s = pygame.Surface((raggio * 2, raggio * 2), pygame.SRCALPHA)
            s.fill((255, 255, 255, 255))
            for rad in range(raggio, 0, -2):
                alfa = int(255 * (rad / raggio) ** 1.6)
                pygame.draw.circle(s, (255, 255, 255, alfa), (raggio, raggio), rad)
            self.luci_cache[raggio] = s
        return self.luci_cache[raggio]

    def _testo_img(self, testo, colore, font=None):
        chiave = (testo, colore, id(font or self.f_hud))
        if chiave not in self.testi_cache:
            f = font or self.f_hud
            base = f.render(testo, True, colore)
            ombra = f.render(testo, True, (0, 0, 0))
            s = pygame.Surface((base.get_width() + 2, base.get_height() + 2), pygame.SRCALPHA)
            s.blit(ombra, (2, 2))
            s.blit(base, (0, 0))
            self.testi_cache[chiave] = s
        return self.testi_cache[chiave]

    # ----------------------------------------------------------------- livelli
    def _imposta_livello(self, indice):
        """Carica casa, personaggi e difficolta' del livello 'indice' (0 = primo)."""
        self.indice_livello = indice
        self.liv = LIVELLI[indice]
        self.mondo = self.mondi[indice]
        if indice not in self.arte_livelli:
            self.arte_livelli[indice] = self.arte.costruisci(self.mondo, self.liv)
        self.sfondo, self.oggetti, self.luci = self.arte_livelli[indice]
        self.ale = Ale(*self._partenza_ale())
        self.elisa = Elisa(self.mondo.start["E"])
        self.gatto = Gatto(self.mondo.start["G"])
        self.gatto.curiosita = self.liv["curiosita"]
        self.tappe = [t for t in self.liv["tappe"] if t in self.mondo.raggiungibili]
        self.notte_totale = float(self.liv["notte_secondi"])
        self.celle_giardino = [c for c in sorted(self.mondo.raggiungibili)
                               if self.mondo.tipo_pavimento(c) in ("erba", "pietra") and self.mondo.carattere(c) not in "dLEG"]

    def _partenza_ale(self):
        letto = self.mondo.start["L"]
        for d in (DESTRA, SINISTRA, GIU, SU):
            n = somma(letto, d)
            if self.mondo.libera(n):
                return ((n[0] + 0.5) * T, (n[1] + 0.5) * T + 10)
        return ((letto[0] + 0.5) * T, (letto[1] + 0.5) * T + 10)

    def _avvia_livello(self, avvia=True):
        self.vite = VITE_INIZIALI
        self.tasca = TASCA_INIZIALE
        self.tempo_notte = self.notte_totale
        self.crocchette = set(self.mondo.crocchette)
        self.scatolette = set(self.mondo.scatolette)
        self.letto_attivo = False
        self.esito = None
        self.reset_posizioni()
        self._reset_pancia()
        self._reset_richieste()
        self.dici(self.liv["intro"], 6.0, "ale")
        self.timer_stato = 2.0
        self.effetti.lista.clear()
        if avvia:
            self.stato = "pronti"

    def nuova_partita(self, avvia=True):
        """Ricomincia da capo: primo livello e zero punti."""
        self.punti = 0
        self.punti_inizio_livello = 0
        self._imposta_livello(0)
        self._avvia_livello(avvia)

    def prossimo_livello(self):
        self.punti_inizio_livello = self.punti
        self._imposta_livello(self.indice_livello + 1)
        self._avvia_livello()

    def riprova_livello(self):
        """Dopo una sconfitta si riprova lo stesso livello, con i punti che avevi all'inizio."""
        self.punti = self.punti_inizio_livello
        self._imposta_livello(self.indice_livello)
        self._avvia_livello()

    @property
    def ultimo_livello(self):
        return self.indice_livello >= len(LIVELLI) - 1

    def reset_posizioni(self):
        self.ale.reset()
        self.elisa.reset()
        self.gatto.reset()
        self.bloccato = False
        self.blocco_timer = 0.0
        self.gatto_riposo = 2.0
        self.gatto_sazio = 0.0
        self.elisa_modo = "giro"
        self.elisa_timer = random.uniform(*ELISA_GIRO_SECONDI)
        self.elisa.meta = self._nuova_tappa()
        self._velocita_elisa("giro")
        self.dist_passo = 0.0
        self.ultimo_carattere = ""
        self.ultima_vista = None
        self.chiamata_timer = 0.0
        self.chiamata_visibile = 0.0
        self.chiamata_bolla = "Ale?"
        self.seduta = None
        self.crampo_blocco = 0.0
        self._azzera_richieste()

    def _velocita_elisa(self, modo):
        if modo == "sveglia":
            self.elisa.imposta_velocita_px(VELOCITA_ELISA_SVEGLIA * self.liv["elisa_sveglia"])
        else:
            self.elisa.imposta_velocita_px(VELOCITA_ELISA_GIRO * self.liv["elisa_giro"])

    def _nuova_tappa(self):
        scelte = [t for t in self.tappe if t != self.elisa.cella] or self.tappe
        return random.choice(scelte)

    def dici(self, righe, secondi=3.0, chi=None):
        self.messaggio = (righe, secondi, chi)

    # ------------------------------------------------------------------- input
    def tasto(self, tasto):
        if tasto in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self._conferma()
        elif tasto == pygame.K_SPACE:
            if self.stato == "gioco" and self.bloccato:
                r = self._richiesta_di("gatto")
                if r is None or r.tipo == "gatto_crocchini":
                    self.dai_crocchetta()
            elif self.stato in ("titolo", "guida", "fine"):
                self._conferma()
        elif tasto == pygame.K_p:
            self._pausa()
        elif tasto == pygame.K_m:
            self.suoni.on_off()
            if self.stato == "pausa":
                self.suoni.pausa_musica(True)

    def _conferma(self):
        """INVIO / SPAZIO nelle schermate di titolo e di fine livello."""
        if self.stato == "titolo":
            self.stato = "guida"
            self.suoni.gioca("interruttore")
        elif self.stato == "guida":
            self.nuova_partita()
        elif self.stato == "fine":
            if self.attesa_fine > 0:
                return
            if self.esito == "livello":
                self.prossimo_livello()
            elif self.esito == "vittoria":
                self.nuova_partita()
            else:
                self.riprova_livello()

    def _pausa(self):
        if self.stato == "pausa":
            self.stato = self.stato_prima_pausa
            self.suoni.pausa_musica(False)
        elif self.stato in ("gioco", "pronti"):
            self.stato_prima_pausa = self.stato
            self.stato = "pausa"
            self.suoni.pausa_musica(True)

    def dai_crocchetta(self):
        if self.tasca <= 0:
            return
        self.tasca -= 1
        self.punti += PUNTI_CROCCHETTA_AL_GATTO
        self.bloccato = False
        self.gatto_riposo = GATTO_RIPOSO
        self._manda_a_caccia(GATTO_CACCIA_CROCCHINO)
        self.suoni.gioca("dai")
        self.suoni.gioca("gattino")
        px, py = self.gatto.piedi()
        self.effetti.cuori(px, py - 22, 5)
        self.effetti.testo(self.ale.x, self.ale.y - 50, self._testo_img(f"+{PUNTI_CROCCHETTA_AL_GATTO}", ROSA))
        self.dici(FRASI_GATTO_CONTENTO, 2.5, "gatto")
        r = self._richiesta_di("gatto")
        if r is not None and r.tipo == "gatto_crocchini":
            self._completa_richiesta(r)

    # ----------------------------------------------------------- aggiornamento
    def _musica_voluta(self):
        if self.stato in ("titolo", "guida"):
            return "titolo"
        if self.stato == "gioco" and self.elisa_modo == "sveglia":
            return "sveglia"
        if self.stato in ("pronti", "gioco"):
            return "notte"
        return None

    def aggiorna(self, dt):
        self.tempo_totale += dt
        if self.stato != "pausa":
            self.suoni.imposta_musica(self._musica_voluta())
            self.suoni.imposta_ambiente(self.stato in ("pronti", "gioco", "morte"))
        self.effetti.aggiorna(dt)
        self.scossa = max(0.0, self.scossa - dt)
        self.lampo = max(0.0, self.lampo - dt)
        testo, resta, chi = self.messaggio
        if resta < 90:
            self.messaggio = (testo, max(0.0, resta - dt), chi)
        if self.pausa_colpo > 0:
            self.pausa_colpo -= dt
            return
        if self.stato == "titolo":
            self.intro.aggiorna(dt)
        elif self.stato == "fine":
            self.attesa_fine = max(0.0, self.attesa_fine - dt)
        elif self.stato == "pronti":
            self.timer_stato -= dt
            if self.timer_stato <= 0:
                self.stato = "gioco"
                self.suoni.gioca("interruttore")
                if "inizio" not in self.consigli:
                    self.consigli.add("inizio")
                    self.dici(("Cammina con le frecce (o W A S D).",
                               "Raccogli le crocchette che trovi per terra!"), 8.0, "ale")
        elif self.stato == "morte":
            self.timer_stato -= dt
            if self.timer_stato <= 0:
                self.reset_posizioni()
                self.timer_stato = 1.2
                self.stato = "pronti"
        elif self.stato == "gioco":
            self._aggiorna_gioco(dt)

    def _direzione_tasti(self):
        k = pygame.key.get_pressed()
        vx = (1 if (k[pygame.K_RIGHT] or k[pygame.K_d]) else 0) - (1 if (k[pygame.K_LEFT] or k[pygame.K_a]) else 0)
        vy = (1 if (k[pygame.K_DOWN] or k[pygame.K_s]) else 0) - (1 if (k[pygame.K_UP] or k[pygame.K_w]) else 0)
        if self.tocchi:
            tx, ty = self._direzione_tocco()
            vx, vy = vx or tx, vy or ty
        return vx, vy

    def _aggiorna_gioco(self, dt, direzione=None):
        self.tempo_notte -= dt
        self.senza_raccolta += dt
        if self.tempo_notte <= 0:
            self.tempo_notte = 0
            self._finisci("sole")
            return
        vx, vy = direzione if direzione is not None else self._direzione_tasti()
        self.avviso_bagno = max(0.0, self.avviso_bagno - dt)
        self.mani_occupate = max(0.0, self.mani_occupate - dt)
        self._aggiorna_pancia(dt)
        self._aggiorna_richieste(dt)
        if self.stato != "gioco":
            return
        if self.seduta is not None:
            self._aggiorna_seduta(dt)
        if self.bloccato or self.seduta is not None or self.crampo_blocco > 0:
            self.crampo_blocco = max(0.0, self.crampo_blocco - dt)
            self.ale.fermo = True
        else:
            rallenta = 1.0 - 0.12 * max(0.0, (self.stress - 0.5) / 0.5)
            fatto = self.ale.muovi(dt, vx, vy, self.mondo, VELOCITA_IO * rallenta)
            self._passi(fatto)
        self._aggiorna_elisa(dt)
        self._aggiorna_gatto(dt)
        self._raccogli()
        self._controlla_contatti()
        if self.stato != "gioco":
            return
        self._controlla_vittoria()

    # ------------------------------------------------------------ pancia e bagno
    def _bagno_attivo(self):
        return BISOGNO_ATTIVO and bool(self.mondo.gabinetti)

    def _reset_pancia(self):
        self.pancia = random.uniform(0.0, 0.25)
        self.pancia_vel = 1.0 / random.uniform(*BISOGNO_SECONDI) if BISOGNO_SECONDI[1] > 0 else 0.0
        self.crampo_timer = 3.0
        self.crampi = 0
        self.avviso_bagno = 0.0

    def _aggiorna_pancia(self, dt):
        if not self._bagno_attivo() or self.seduta is not None:
            return
        self.pancia = min(1.0, self.pancia + self.pancia_vel * dt)
        if self.pancia < 0.5:
            return
        for wc in self.mondo.gabinetti:
            if distanza((self.ale.x, self.ale.y - 8), ((wc[0] + 0.5) * T, (wc[1] + 0.5) * T + 8)) < 36:
                self._inizia_seduta(wc)
                return
        self.crampo_timer -= dt
        if self.crampo_timer <= 0 and self.elisa_modo != "sveglia" and not self.bloccato and self.crampo_blocco <= 0:
            self._crampo()

    def _crampo(self):
        """Uno strizzone di pancia: Ale si piega in due per un attimo."""
        self.crampo_timer = random.uniform(3.0, 5.0) if self.pancia < 1.0 else random.uniform(1.6, 2.6)
        self.crampo_blocco = 0.7
        self.scossa = max(self.scossa, 0.22)
        self.suoni.gioca("gorgoglio")
        self.effetti.scintille(self.ale.x, self.ale.y - 34, (150, 210, 255), 4)
        self.dici(FRASI_PANCIA_PRIMA if self.crampi == 0 else random.choice(FRASI_PANCIA), 3.0, "ale")
        self.crampi += 1

    def _uscita_water(self, wc):
        for d in (GIU, DESTRA, SINISTRA, SU):
            n = somma(wc, d)
            if self.mondo.libera(n):
                return ((n[0] + 0.5) * T, (n[1] + 0.5) * T + 10)
        return ((wc[0] + 0.5) * T, (wc[1] + 0.5) * T + 10)

    def _inizia_seduta(self, wc):
        self.seduta = {"t": 0.0, "wc": wc, "fatti": set()}
        self.crampo_blocco = 0.0
        self.bloccato = False
        self.ale.x, self.ale.y = (wc[0] + 0.5) * T, (wc[1] + 0.5) * T + 18
        self.ale.faccia = GIU
        self.ale.fermo = True
        self.dici(FRASI_BAGNO_INIZIO, SEDUTA_SECONDI, "ale")

    def fase_pantaloni(self, t):
        fine = SEDUTA_SECONDI
        if t < 0.4:
            return 0
        if t < 0.9:
            return 1
        if t < fine - 0.9:
            return 2
        if t < fine - 0.45:
            return 1
        return 0

    def _aggiorna_seduta(self, dt):
        s = self.seduta
        s["t"] += dt
        t = s["t"]
        for chiave, quando, suono in (("a", 1.0, "sforzo"), ("b", 1.7, "sforzo"), ("c", SEDUTA_SECONDI - 0.6, "sciacquone")):
            if t >= quando and chiave not in s["fatti"]:
                s["fatti"].add(chiave)
                self.suoni.gioca(suono)
                if suono == "sforzo":
                    self.effetti.scintille(self.ale.x, self.ale.y - 34, (150, 210, 255), 5)
        if t >= SEDUTA_SECONDI:
            self._finisci_seduta()

    def _finisci_seduta(self):
        wc = self.seduta["wc"]
        self.seduta = None
        self.ale.x, self.ale.y = self._uscita_water(wc)
        self.pancia = 0.0
        self.pancia_vel = 1.0 / random.uniform(*BISOGNO_SECONDI)
        self.punti += PUNTI_SOLLIEVO
        self.suoni.gioca("oggetto")
        self.effetti.cuori(self.ale.x, self.ale.y - 30, 6)
        self.effetti.testo(self.ale.x, self.ale.y - 56, self._testo_img(f"+{PUNTI_SOLLIEVO}", AZZURRO, self.f_hud), 1.1)
        self.dici(FRASI_BAGNO_FINE, 3.0, "ale")

    def _passi(self, fatto):
        """Rumore dei passi (diverso su legno e su erba) e porte che si attraversano."""
        self.dist_passo += fatto
        if self.dist_passo >= 24:
            self.dist_passo = 0.0
            tipo = self.mondo.tipo_pavimento(self.ale.cella)
            self.suoni.gioca("passo_erba" if tipo in ("erba", "pietra", "cemento") else "passo_legno")
            if tipo in ("erba", "pietra"):
                self.effetti.polvere(self.ale.x, self.ale.y)
        ch = self.mondo.carattere(self.ale.cella)
        if ch == "d" and self.ultimo_carattere != "d":
            self.suoni.gioca("porta")
        self.ultimo_carattere = ch

    # -------------------------------------------------------------- Eli (guardia)
    def _cella_ale(self):
        c = self.ale.cella
        if self.mondo.libera(c):
            return c
        for d in DIREZIONI:
            n = somma(c, d)
            if self.mondo.libera(n):
                return n
        return self.mondo.start["L"]

    def _elisa_vede_ale(self):
        """Eli ti nota se sei abbastanza vicino, davanti a lei e senza mobili o muri in mezzo."""
        if ELISA_VISTA_CELLE <= 0:
            return False
        a, b = self.elisa.cella_attuale(), self._cella_ale()
        d = distanza(a, b)
        if d > ELISA_VISTA_CELLE:
            return False
        if d > 0.5:
            f = self.elisa.faccia
            if ((b[0] - a[0]) * f[0] + (b[1] - a[1]) * f[1]) / d < -0.25:
                return False
        visto = self.mondo.linea_libera(a, b)
        if visto:
            self.ultima_vista = b
        return visto

    def _elisa_sospetta(self):
        self.elisa_modo = "sospetta"
        self.elisa_timer = ELISA_SOSPETTO_SECONDI
        a, b = self.elisa.cella_attuale(), self._cella_ale()
        dx, dy = b[0] - a[0], b[1] - a[1]
        self.elisa.faccia = (DESTRA if dx > 0 else SINISTRA) if abs(dx) >= abs(dy) else (GIU if dy > 0 else SU)
        self.elisa.fermo = True
        self.suoni.gioca("sospetta")
        self.dici(FRASI_ELISA_SOSPETTA, 2.0, "eli")

    def _elisa_sveglia(self, da_vista):
        self.elisa_modo = "sveglia"
        self.elisa_timer = self.liv["sveglia_secondi"] * (0.85 if da_vista else 1.0)
        self._velocita_elisa("sveglia")
        self.elisa.sosta = 0.0
        self.suoni.gioca("allerta")
        if da_vista:
            self.dici(FRASI_ELISA_TI_VEDE, 2.5, "eli")
        elif "cerca" not in self.consigli:
            self.consigli.add("cerca")
            self.dici(("Eli ti sta cercando: vuole qualcosa!", "Raggiungila per non farla arrabbiare."), 4.0, "eli")

    def _elisa_cerca(self):
        """Eli ti ha perso: va dove ti ha visto l'ultima volta, si guarda intorno e ti chiama."""
        self.elisa_modo = "cerca"
        self.elisa_timer = ELISA_RICERCA_SECONDI
        self._velocita_elisa("giro")
        self.elisa.sosta = 0.0
        self.elisa.meta = self._centro_ricerca()
        self.chiamata_timer = 0.8
        self.chiamata_visibile = 0.0

    def _centro_ricerca(self):
        if self.ultima_vista in self.mondo.raggiungibili:
            return self.ultima_vista
        return self.elisa.cella_attuale()

    def _elisa_chiama(self):
        bolla, righe = random.choice(FRASI_ELISA_CERCA)
        self.chiamata_timer = random.uniform(2.2, 3.0)
        self.chiamata_visibile = 1.6
        self.chiamata_bolla = bolla
        self.suoni.gioca("chiama")
        self.dici(righe, 2.6, "eli")

    def _meta_di_ricerca(self):
        """Un posto vicino a dove ti ha visto l'ultima volta, dove andare a guardare."""
        dist = self.mondo.distanze(self._centro_ricerca())
        vicine = [c for c, d in dist.items() if 1 <= d <= 6 and c != self.elisa.cella]
        return random.choice(sorted(vicine)) if vicine else self._centro_ricerca()

    def _elisa_torna_al_giro(self):
        self.ultima_vista = None
        self.elisa_modo = "giro"
        self.elisa_timer = random.uniform(*ELISA_GIRO_SECONDI)
        self._velocita_elisa("giro")
        self.elisa.meta = self._nuova_tappa()

    def _aggiorna_elisa(self, dt):
        e = self.elisa
        self.elisa_timer -= dt
        self.chiamata_visibile = max(0.0, self.chiamata_visibile - dt)
        if self.elisa_modo == "chiede":
            e.fermo = True
            return
        if self.elisa_modo == "sospetta":
            e.fermo = True
            if self.elisa_timer <= 0:
                if self._elisa_vede_ale():
                    self._elisa_sveglia(da_vista=True)
                else:
                    self._elisa_cerca()
            return
        if self.elisa_modo == "giro":
            if self.elisa_timer <= 0:
                self._elisa_sveglia(da_vista=False)
            elif self._elisa_vede_ale():
                self._elisa_sospetta()
                return
        elif self.elisa_modo == "cerca":
            if self._elisa_vede_ale():
                self._elisa_sospetta()
                return
            if self.elisa_timer <= 0:
                self._elisa_torna_al_giro()
            else:
                self.chiamata_timer -= dt
                if self.chiamata_timer <= 0:
                    self._elisa_chiama()
        elif self.elisa_timer <= 0:
            self._elisa_cerca()
        if self.elisa_modo == "sveglia":
            self._elisa_vede_ale()
            e.meta = self._cella_ale()
            e.errore = self.liv["errore"]
        else:
            e.errore = 0.0
            if e.sosta > 0:
                e.sosta -= dt
                e.fermo = True
                return
            if e.verso is None and e.cella == e.meta:
                e.sosta = random.uniform(*ELISA_SOSTA_SECONDI)
                e.fermo = True
                if self.elisa_modo == "cerca":
                    e.faccia = random.choice(DIREZIONI)
                    e.meta = self._meta_di_ricerca()
                else:
                    e.meta = self._nuova_tappa()
                return
        e.muovi(dt, self.mondo)

    # ------------------------------------------------------------- Tamiyo (gatto)
    def _aggiorna_gatto(self, dt):
        g = self.gatto
        self.gatto_riposo = max(0.0, self.gatto_riposo - dt)
        if self.gatto_caccia > 0:
            self.gatto_caccia -= dt
            if self.gatto_caccia <= 0:
                self.gatto.curiosita = self.liv["curiosita"]
                self.gatto_riposo = 2.0
            elif g.verso is None and g.cella == g.bersaglio:
                self._nuova_meta_caccia()
        if self.gatto_sazio > 0:
            self.gatto_sazio -= dt
            g.fermo = True
        else:
            if self.gatto_caccia <= 0:
                g.bersaglio = self._cella_ale()
            g.muovi(dt, self.mondo)
        if self.bloccato:
            self.blocco_timer -= dt
            if self.blocco_timer <= 0:
                self.bloccato = False
                self.gatto_riposo = 4.0
        elif (self._vicini(g.piedi(), 22) and self.gatto_riposo <= 0 and self.gatto_sazio <= 0
              and self.gatto_caccia <= 0):
            self._gatto_blocca()

    def _gatto_blocca(self):
        r = self._richiesta_di("gatto")
        if r is None and RICHIESTE_ATTIVE:
            r = self._nuova_richiesta("gatto_crocchini")
        tipo = r.tipo if r is not None else "gatto_crocchini"
        if tipo == "gatto_scatoletta":
            self.gatto_riposo = 1.5
            self.suoni.gioca("gatto")
            if self.mano != "scatoletta":
                self.dici(("Tamiyo vuole una scatoletta!", "Ce ne sono in giardino."), 2.5, "gatto")
            return
        self.bloccato = True
        self.suoni.gioca("gatto")
        if tipo == "gatto_coccole":
            self.blocco_timer = float("inf")
            self.dici(("Tamiyo ti si struscia sulle gambe.", "Tieni premuto SPAZIO per le coccole."), 99.0, "gatto")
        elif self.tasca > 0:
            self.blocco_timer = float("inf")
            self.dici(FRASI_GATTO_BLOCCA, 99.0, "gatto")
        else:
            self.blocco_timer = GATTO_PAZIENZA
            self.dici(FRASI_GATTO_SENZA, GATTO_PAZIENZA, "gatto")

    def _vicini(self, punto, raggio):
        return distanza((self.ale.x, self.ale.y), punto) < raggio

    # ---------------------------------------------------------- oggetti e contatti
    def _centro_oggetto(self, cella):
        return ((cella[0] + 0.5) * T, (cella[1] + 0.5) * T + 4)

    def _raccogli(self):
        corpo = (self.ale.x, self.ale.y - 7)
        cc = self.ale.cella
        for dc in (-1, 0, 1):
            for dr in (-1, 0, 1):
                cella = (cc[0] + dc, cc[1] + dr)
                if cella in self.crocchette and distanza(corpo, self._centro_oggetto(cella)) < 16:
                    self._prendi_crocchetta(cella)
                elif cella in self.scatolette and distanza(corpo, self._centro_oggetto(cella)) < 18:
                    self._prendi_scatoletta(cella)

    def _prendi_crocchetta(self, cella):
        self.crocchette.discard(cella)
        self.punti += PUNTI_CROCCHETTA
        self.tasca = min(TASCA_MASSIMA, self.tasca + 1)
        x, y = self._centro_oggetto(cella)
        self.suoni.crocchetta()
        self.senza_raccolta = 0.0
        if "prima" not in self.consigli and self.crocchette:
            self.consigli.add("prima")
            self.dici((f"Bene! Ne servono {len(self.mondo.crocchette)}: guarda il contatore in alto.",
                       "Presto Eli e Tamiyo ti chiederanno delle cose..."), 6.0, "ale")
        self.effetti.scintille(x, y, (255, 214, 120), 6)
        self.effetti.testo(x, y - 14, self._testo_img(f"+{PUNTI_CROCCHETTA}", (255, 232, 140), self.f_msg), 0.8)
        if not self.crocchette:
            self.letto_attivo = True
            self.suoni.gioca("tutte")
            self.dici(FRASI_TUTTE_RACCOLTE, 4.0, "ale")

    def _prendi_scatoletta(self, cella):
        if self.mano is not None:
            if self.mani_occupate <= 0:
                self.mani_occupate = 3.0
                self.dici(FRASI_MANI_OCCUPATE, 2.5, "ale")
            return
        self.scatolette.discard(cella)
        self.mano = "scatoletta"
        self.mano_nome = "scatoletta"
        self.tempo_notte += SCATOLETTA_SECONDI_EXTRA
        x, y = self._centro_oggetto(cella)
        self.suoni.gioca("scatoletta")
        self.suoni.gioca("oggetto")
        self.effetti.scintille(x, y, (150, 220, 255), 10)
        self.dici(("Hai una scatoletta! (+10 secondi di notte)", "Portala a Tamiyo."), 3.5, "ale")

    def _consegna_scatoletta(self):
        self.mano = None
        self.punti += PUNTI_SCATOLETTA
        self._manda_a_caccia(GATTO_CACCIA_SCATOLETTA)
        gx, gy = self.gatto.piedi()
        self.suoni.gioca("scatoletta")
        self.suoni.gioca("gattino")
        self.effetti.cuori(gx, gy - 22, 9)
        self.effetti.testo(gx, gy - 46, self._testo_img(f"+{PUNTI_SCATOLETTA}", AZZURRO, self.f_hud), 1.1)
        r = self._richiesta_di("gatto")
        if r is not None:
            self._completa_richiesta(r)
        else:
            self.dici(FRASI_SCATOLETTA, 3.5, "gatto")

    # ------------------------------------------- richieste: troppe cose da fare!
    def _richiesta_di(self, chi):
        for r in self.richieste:
            if r.chi == chi:
                return r
        return None

    def _azzera_richieste(self):
        self.richieste = []
        self.mano = None
        self.mano_nome = ""
        self.elisa_cooldown = 4.0
        self.mani_occupate = 0.0
        self.gatto.curiosita = self.liv["curiosita"]
        self.gatto_caccia = 0.0
        self.stress = min(getattr(self, "stress", 0.1), 0.4)
        self.richiesta_timer = max(getattr(self, "richiesta_timer", 0.0), 8.0)

    def _reset_richieste(self):
        self._azzera_richieste()
        self.richiesta_timer = RICHIESTA_PRIMA_SECONDI
        self.stress = 0.1
        self.stress_sudore = 0.0
        self.elisa_cooldown = 0.0

    def _cella_lontana(self, da, minimo):
        """Una casella di pavimento raggiungibile, lontana da 'da' (dove mettere un oggetto)."""
        candidate = [c for c in sorted(self.mondo.raggiungibili)
                     if self.mondo.carattere(c) not in "dLEG" and c not in self.crocchette and c not in self.scatolette
                     and abs(c[0] - da[0]) + abs(c[1] - da[1]) >= minimo]
        return random.choice(candidate) if candidate else self._cella_ale()

    def _nuova_richiesta(self, tipo=None):
        occupati = {r.chi for r in self.richieste}
        if tipo is None:
            scelte = []
            if "gatto" not in occupati and self.gatto_caccia <= 0 and self.gatto_sazio <= 0:
                scelte += ["gatto_crocchini"] * 3 + ["gatto_coccole"] * 2 + ["gatto_scatoletta"] * 2
            if "eli" not in occupati and self.elisa_cooldown <= 0 and self.elisa_modo != "chiede":
                scelte += ["eli_attenzioni"] * 2 + ["eli_aiuto"] * 2
            if not scelte:
                return None
            tipo = random.choice(scelte)
        r = Richiesta(tipo, PAZIENZA_SECONDI)
        self.richieste.append(r)
        if r.chi == "gatto":
            self.gatto.curiosita = 1.0
            self.gatto_riposo = 0.0
            self.gatto_sazio = 0.0
            if tipo == "gatto_scatoletta" and not self.scatolette and self.mano != "scatoletta":
                self.scatolette.add(self._cella_lontana(self._cella_ale(), 8))
        elif self.elisa_modo != "chiede":
            self._elisa_sveglia(da_vista=False)
        self.suoni.gioca("pop")
        self.dici(TIPI_RICHIESTA[tipo]["inizio"], 4.5, "gatto" if r.chi == "gatto" else "eli")
        return r

    def _aggiorna_richieste(self, dt):
        if not RICHIESTE_ATTIVE:
            return
        self.richiesta_timer -= dt
        self.elisa_cooldown = max(0.0, self.elisa_cooldown - dt)
        if self.richiesta_timer <= 0:
            self.richiesta_timer = random.uniform(*RICHIESTA_OGNI_SECONDI)
            self._nuova_richiesta()
        for r in list(self.richieste):
            r.pazienza -= dt * (0.5 if (r.chi == "eli" and not r.attiva) else 1.0)
            if r.pazienza <= 0:
                self._richiesta_fallita(r)
                if self.stato != "gioco":
                    return
        self._aggiorna_tenute(dt)
        self._aggiorna_consegne()
        self._aggiorna_stress(dt)

    def _chiudi_richiesta(self, r):
        if r in self.richieste:
            self.richieste.remove(r)
        if r.chi == "gatto":
            self.bloccato = False
            self.gatto_riposo = GATTO_RIPOSO
            self.gatto.curiosita = self.liv["curiosita"]
        else:
            if self.mano == "aiuto":
                self.mano = None
            self._elisa_torna_al_giro()
            self.elisa_cooldown = 10.0

    def _manda_a_caccia(self, secondi):
        """Tamiyo ha mangiato: se ne va in giardino a caccia di insetti. Con la scatoletta ci sta di piu'."""
        self.bloccato = False
        self.gatto_riposo = 0.0
        if not self.celle_giardino:
            self.gatto_sazio = max(self.gatto_sazio, secondi)
            return
        self.gatto_caccia = max(self.gatto_caccia, secondi)
        self.gatto.curiosita = 1.0
        self._nuova_meta_caccia()

    def _nuova_meta_caccia(self):
        scelte = [c for c in self.celle_giardino if c != self.gatto.cella_attuale()]
        self.gatto.bersaglio = random.choice(scelte) if scelte else self.gatto.cella_attuale()

    def _completa_richiesta(self, r):
        self._chiudi_richiesta(r)
        if r.chi == "gatto":
            self._manda_a_caccia({"gatto_scatoletta": GATTO_CACCIA_SCATOLETTA,
                                  "gatto_coccole": GATTO_CACCIA_COCCOLE}.get(r.tipo, GATTO_CACCIA_CROCCHINO))
        self.punti += PUNTI_RICHIESTA
        self.stress = max(0.0, self.stress - 0.25)
        x, y = self.gatto.piedi() if r.chi == "gatto" else self.elisa.piedi()
        self.effetti.cuori(x, y - 24, 7)
        self.effetti.testo(x, y - 52, self._testo_img(f"+{PUNTI_RICHIESTA}", ROSA, self.f_hud), 1.1)
        self.suoni.gioca("oggetto")
        self.suoni.gioca("gattino" if r.chi == "gatto" else "tutte")
        frasi = FRASI_RICHIESTA_ESAUDITA_GATTO if r.chi == "gatto" else FRASI_RICHIESTA_ESAUDITA_ELI
        self.dici(random.choice(frasi), 3.0, "gatto" if r.chi == "gatto" else "eli")

    def _richiesta_fallita(self, r):
        self._chiudi_richiesta(r)
        self.stress = min(1.0, self.stress + 0.2)
        if r.chi == "eli":
            self._perdi_vita(FRASI_ELISA_DELUSA, "eli")
        else:
            self._manda_a_caccia(GATTO_CACCIA_COCCOLE)
            self.dici(FRASI_GATTO_OFFESO, 3.0, "gatto")

    def _azione_premuta(self):
        if pygame.key.get_pressed()[pygame.K_SPACE]:
            return True
        ax, ay, ar = self._zone_controlli()["azione"]
        return any(distanza(p, (ax, ay)) < ar + 18 for p in self.tocchi.values())

    def _aggiorna_tenute(self, dt):
        """Coccole a Tamiyo e attenzioni a Eli: si tiene premuto SPAZIO standole vicino."""
        premuto = self._azione_premuta()
        for r in list(self.richieste):
            if r.tipo not in ("gatto_coccole", "eli_attenzioni") or not r.attiva:
                continue
            bersaglio = self.gatto.piedi() if r.chi == "gatto" else self.elisa.piedi()
            vicino = distanza((self.ale.x, self.ale.y), bersaglio) < 46 and self.seduta is None
            if premuto and vicino:
                r.progresso = min(1.0, r.progresso + dt / TENUTA_SECONDI)
                if random.random() < dt * 5:
                    self.effetti.cuori(bersaglio[0], bersaglio[1] - 24, 1)
                if r.progresso >= 1.0:
                    self._completa_richiesta(r)
            else:
                r.progresso = max(0.0, r.progresso - dt * 0.7)

    def _aggiorna_consegne(self):
        """Scatolette a Tamiyo e oggetti a Eli: basta arrivare vicino mentre li porti."""
        if self.mano == "scatoletta" and distanza((self.ale.x, self.ale.y), self.gatto.piedi()) < 34:
            self._consegna_scatoletta()
            return
        r = self._richiesta_di("eli")
        if r is None or r.tipo != "eli_aiuto" or not r.attiva:
            return
        if self.mano == "aiuto" and distanza((self.ale.x, self.ale.y), self.elisa.piedi()) < 40:
            self.mano = None
            self._completa_richiesta(r)
        elif r.cella is not None and distanza((self.ale.x, self.ale.y - 7), self._centro_oggetto(r.cella)) < 20:
            if self.mano is None:
                self.mano = "aiuto"
                self.mano_nome = r.oggetto
                r.cella = None
                self.suoni.gioca("oggetto")
                self.dici((f"Hai preso {r.oggetto}.", "Portalo a Eli!"), 3.0, "ale")
            elif self.mani_occupate <= 0:
                self.mani_occupate = 3.0
                self.dici(FRASI_MANI_OCCUPATE, 2.5, "ale")

    def _aggiorna_stress(self, dt):
        """L'affanno di Ale sale con le cose da fare e si vede: sudore, tremiti, fiatone."""
        if not STRESS_ATTIVO:
            return
        n = len(self.richieste) + (1 if self._bagno_attivo() and self.pancia >= 0.85 else 0) + (1 if self.bloccato else 0)
        if n:
            self.stress = min(1.0, self.stress + dt * (0.008 + 0.011 * n))
        else:
            self.stress = max(0.0, self.stress - dt * 0.02)
        if self.stress > 0.25:
            self.stress_sudore -= dt
            if self.stress_sudore <= 0:
                self.stress_sudore = max(0.12, 1.1 - self.stress)
                self.effetti.sudore(self.ale.x + random.uniform(-7, 7), self.ale.y - 46)
        if self.stress >= 1.0:
            self.stress = 0.55
            self._perdi_vita(FRASI_STRESS_AL_LIMITE, "ale")

    def _controlla_contatti(self):
        if self._vicini(self.elisa.piedi(), 20):
            self._eli_incontra()

    def _perdi_vita(self, righe, chi):
        self.vite -= 1
        self.suoni.gioca("sveglia")
        self.suoni.gioca("colpo")
        self.scossa = 0.35
        self.lampo = 0.45
        self.pausa_colpo = 0.09
        if self.vite <= 0:
            self._finisci("vite")
            return
        self.dici(righe, 2.5, chi)
        self.seduta = None
        self.stato = "morte"
        self.timer_stato = 1.6

    def _eli_incontra(self):
        """Eli ti ha raggiunto: ti chiede qualcosa (o, con le richieste spente, ti sveglia)."""
        if not RICHIESTE_ATTIVE:
            self._perdi_vita(FRASI_ELISA_BAGNO if self.seduta is not None else random.choice(FRASI_ELISA), "eli")
            return
        r = self._richiesta_di("eli")
        if r is None:
            if self.elisa_cooldown > 0:
                return
            r = self._nuova_richiesta(random.choice(("eli_attenzioni", "eli_aiuto")))
            if r is None:
                return
        if not r.attiva:
            self._attiva_eli(r)

    def _attiva_eli(self, r):
        r.attiva = True
        r.pazienza = PAZIENZA_SECONDI
        self.elisa_modo = "chiede"
        self.elisa.fermo = True
        a, b = self.elisa.cella_attuale(), self._cella_ale()
        dx, dy = b[0] - a[0], b[1] - a[1]
        self.elisa.faccia = (DESTRA if dx > 0 else SINISTRA) if abs(dx) >= abs(dy) else (GIU if dy > 0 else SU)
        self.suoni.gioca("chiama")
        if self.seduta is not None:
            self.dici(FRASI_ELISA_BAGNO, 3.5, "eli")
        elif r.tipo == "eli_aiuto":
            r.oggetto, r.colore_oggetto, r.breve = random.choice(OGGETTI_AIUTO)
            r.cella = self._cella_lontana(self.elisa.cella_attuale(), 7)
            self.dici((f"Eli: \"Mi porti {r.oggetto}?\"", "Cercalo in giro per casa e portaglielo."), 5.0, "eli")
        else:
            self.dici(("Eli: \"Amore, un po' di attenzioni?\"", "Stalle vicino e tieni premuto SPAZIO."), 5.0, "eli")
        if r.tipo == "eli_aiuto" and r.oggetto is None:
            r.oggetto, r.colore_oggetto, r.breve = random.choice(OGGETTI_AIUTO)
            r.cella = self._cella_lontana(self.elisa.cella_attuale(), 7)

    def _controlla_vittoria(self):
        if not self.letto_attivo:
            return
        letto = self.mondo.start["L"]
        if distanza((self.ale.x, self.ale.y - 8), self._centro_oggetto(letto)) < 28:
            if self._bagno_attivo() and self.pancia >= 0.999:
                if self.avviso_bagno <= 0:
                    self.avviso_bagno = 3.5
                    self.dici(FRASI_PRIMA_IL_BAGNO, 3.0, "ale")
                return
            self.punti += self.vite * PUNTI_PER_VITA_RIMASTA
            self.punti += int(self.tempo_notte) * PUNTI_PER_SECONDO_RIMASTO
            self._finisci("vittoria" if self.ultimo_livello else "livello")

    def _finisci(self, esito):
        self.esito = esito
        self.stato = "fine"
        self.attesa_fine = 0.8
        self.messaggio = ((), 0.0, None)
        self.suoni.gioca("vittoria" if esito in ("vittoria", "livello") else "sole")
        if self.punti > self.record:
            self.record = self.punti
            self._salva_record()

    # ------------------------------------------------------------------ disegno
    def orologio(self):
        """Ora mostrata: da 02:00 (inizio) a 06:00 (alba)."""
        trascorso = (self.notte_totale - self.tempo_notte) / self.notte_totale
        minuti = int(max(0.0, min(1.0, trascorso)) * 240)
        return f"{2 + minuti // 60:02d}:{minuti % 60:02d}"

    def disegna(self):
        c = self.canvas
        c.fill((10, 12, 26))
        if self.stato == "titolo":
            self.intro.invito = self._tocca("PREMI INVIO")
            self.intro.disegna(c, self.record, int(self.tempo_totale * 2) % 2 == 0)
        elif self.stato == "guida":
            self._disegna_guida()
        else:
            self._disegna_mondo()
            sx = sy = 0
            if self.scossa > 0:
                forza = 5 * (self.scossa / 0.35)
                sx, sy = int(random.uniform(-forza, forza)), int(random.uniform(-forza, forza))
            c.blit(self.vista, (sx, ALTEZZA_BARRA_ALTA + sy))
            self._disegna_barre()
            self._disegna_schermate()
            self._disegna_controlli()
        if EFFETTO_CRT:
            self._crt()

    def _crt(self):
        if self._crt_cache is None:
            w, h = self.dimensione
            self._crt_cache = pygame.Surface((w, h), pygame.SRCALPHA)
            for y in range(0, h, 3):
                pygame.draw.line(self._crt_cache, (0, 0, 0, 50), (0, y), (w, y))
        self.canvas.blit(self._crt_cache, (0, 0))

    def _ombra_personaggio(self, s, x, y, larghezza):
        ombra = pygame.Surface((larghezza, 10), pygame.SRCALPHA)
        pygame.draw.ellipse(ombra, (0, 0, 0, 80), ombra.get_rect())
        s.blit(ombra, (int(x - larghezza / 2), int(y - 5)))

    def _disegna_mondo(self):
        s = self.vista
        s.blit(self.sfondo, (0, 0))
        self._disegna_letto_attivo(s)
        for cella in self.crocchette:
            x, y = self._centro_oggetto(cella)
            salto = math.sin(self.tempo_totale * 3 + cella[0] * 1.3 + cella[1]) * 1.5
            s.blit(self.img_croc, self.img_croc.get_rect(center=(int(x), int(y + salto))))
        for cella in self.scatolette:
            x, y = self._centro_oggetto(cella)
            salto = math.sin(self.tempo_totale * 4 + cella[0]) * 2.5
            s.blit(self.img_scat, self.img_scat.get_rect(center=(int(x), int(y - 3 + salto))))
        re = self._richiesta_di("eli")
        if re is not None and re.tipo == "eli_aiuto" and re.attiva and re.cella is not None:
            ox, oy = self._centro_oggetto(re.cella)
            pulsa = 0.5 + 0.5 * math.sin(self.tempo_totale * 6)
            alone = pygame.Surface((30, 30), pygame.SRCALPHA)
            pygame.draw.circle(alone, (255, 240, 140, int(50 + 70 * pulsa)), (15, 15), 14)
            s.blit(alone, (int(ox) - 15, int(oy) - 12))
            img = self._img_oggetto(re.colore_oggetto)
            s.blit(img, (int(ox) - 9, int(oy) - 12 + int(math.sin(self.tempo_totale * 5) * 2)))
        ale, eli, gatto = self.ale, self.elisa, self.gatto
        ex, ey = eli.piedi()
        gx, gy = gatto.piedi()
        self._ombra_personaggio(s, ale.x, ale.y, 22)
        self._ombra_personaggio(s, ex, ey, 22)
        self._ombra_personaggio(s, gx, gy, 24)
        elementi = [(o[0], 0, o) for o in self.oggetti]
        elementi.append((ale.y, 1, "ale"))
        elementi.append((ey, 1, "eli"))
        elementi.append((gy, 1, "gatto"))
        elementi.sort(key=lambda e: (e[0], e[1]))
        for _, tipo, dato in elementi:
            if tipo == 0:
                s.blit(dato[1], (dato[2], dato[3]))
            else:
                self._disegna_personaggio(s, dato)
        self._disegna_buio(s)
        self._disegna_fumetti(s)
        self._freccia_aiuto(s)
        self._freccia_bagno(s)
        self.effetti.disegna(s)
        if self.lampo > 0:
            velo = pygame.Surface(s.get_size(), pygame.SRCALPHA)
            velo.fill((255, 60, 60, int(110 * self.lampo / 0.45)))
            s.blit(velo, (0, 0))

    def _img_oggetto(self, colore):
        if not hasattr(self, "_oggetti_img"):
            self._oggetti_img = {}
        if colore not in self._oggetti_img:
            self._oggetti_img[colore] = disegna_oggetto_aiuto(colore)
        return self._oggetti_img[colore]

    def _anello(self, s, x, y, valore):
        """Cerchio che si riempie: quanto manca per finire le coccole o le attenzioni."""
        r = 11
        pygame.draw.circle(s, (20, 20, 40), (int(x), int(y)), r + 2)
        punti = [(x, y)]
        passi = max(2, int(36 * valore))
        for k in range(passi + 1):
            a = -math.pi / 2 + 2 * math.pi * valore * k / passi
            punti.append((x + r * math.cos(a), y + r * math.sin(a)))
        if valore > 0.01:
            pygame.draw.polygon(s, (255, 110, 170), punti)
        pygame.draw.circle(s, BIANCO, (int(x), int(y)), r + 2, 2)

    def _disegna_personaggio(self, s, chi):
        if chi == "ale":
            foglio, p, x, y = self.foglio_ale, self.ale, self.ale.x, self.ale.y
            img = foglio.fotogramma(p.faccia, p.fermo, p.distanza)
            if self.seduta is not None:
                img = self._ale_seduto(self.fase_pantaloni(self.seduta["t"]))
                if 1.0 <= self.seduta["t"] <= SEDUTA_SECONDI - 0.9:
                    x += math.sin(self.tempo_totale * 55) * 1.2
        elif chi == "eli":
            foglio, p = self.foglio_eli, self.elisa
            x, y = p.piedi()
            img = foglio.fotogramma(p.faccia, p.fermo, p.distanza)
        else:
            foglio, p = self.foglio_gatto, self.gatto
            x, y = p.piedi()
            img = foglio.fotogramma(p.faccia, p.fermo or self.gatto_sazio > 0, p.distanza)
            if self.gatto_riposo > 0 or self.gatto_sazio > 0:
                img = img.copy()
                img.set_alpha(185 if self.gatto_sazio <= 0 else 225)
        if chi == "ale" and self.seduta is not None:
            pygame.draw.ellipse(s, (240, 244, 248), (int(x) - 17, int(y) - 26, 34, 17))
            pygame.draw.ellipse(s, (150, 160, 178), (int(x) - 17, int(y) - 26, 34, 17), 1)
            pygame.draw.rect(s, (236, 240, 246), (int(x) - 9, int(y) - 40, 18, 9), border_radius=2)
            s.blit(img, (int(x - 32), int(y - img.get_bounding_rect().bottom)))
        else:
            if chi == "ale" and self.stress > 0.35:
                x += math.sin(self.tempo_totale * 45) * (self.stress - 0.35) * 2.6
            s.blit(img, (int(x - foglio.largo / 2), int(y - foglio.piede - 1)))

    def _disegna_letto_attivo(self, s):
        if not self.letto_attivo:
            return
        x, y = self.mondo.start["L"]
        pulsa = 0.5 + 0.5 * math.sin(self.tempo_totale * 6)
        alone = pygame.Surface((T + 8, T + 8), pygame.SRCALPHA)
        pygame.draw.rect(alone, (255, 230, 100, int(70 + 120 * pulsa)), alone.get_rect(), border_radius=8)
        s.blit(alone, (x * T - 4, y * T - 4))
        salto = int(abs(math.sin(self.tempo_totale * 5)) * 5)
        cx, cy = x * T + 16, y * T - 10 - salto
        pygame.draw.polygon(s, (255, 230, 100), [(cx - 8, cy - 8), (cx + 8, cy - 8), (cx, cy + 4)])
        pygame.draw.polygon(s, (120, 80, 20), [(cx - 8, cy - 8), (cx + 8, cy - 8), (cx, cy + 4)], 2)

    def _disegna_buio(self, s):
        if OSCURITA <= 0:
            return
        if self._buio is None or self._buio.get_size() != s.get_size():
            self._buio = pygame.Surface(s.get_size(), pygame.SRCALPHA)
        buio = self._buio
        buio.fill((6, 8, 28, int(min(255, OSCURITA))))
        r = int(RAGGIO_LUCE)
        buio.blit(self._luce(r), (int(self.ale.x - r), int(self.ale.y - 22 - r)), special_flags=pygame.BLEND_RGBA_MIN)
        for (x, y, raggio) in self.luci:
            buio.blit(self._luce(raggio), (x - raggio, y - raggio), special_flags=pygame.BLEND_RGBA_MIN)
        s.blit(buio, (0, 0))

    def _bolla(self, s, testo, x, y, colore):
        img = self._testo_img(testo, colore, self.f_hud)
        r = img.get_rect(midbottom=(int(x), int(y)))
        sfondo = pygame.Surface((r.width + 8, r.height + 2), pygame.SRCALPHA)
        pygame.draw.rect(sfondo, (0, 0, 0, 150), sfondo.get_rect(), border_radius=6)
        s.blit(sfondo, (r.x - 4, r.y - 1))
        s.blit(img, r)

    def _disegna_fumetti(self, s):
        ex, ey = self.elisa.piedi()
        testa = ey - self.foglio_eli.piede + 6
        re = self._richiesta_di("eli")
        if re is not None and re.attiva:
            self._bolla(s, re.bolla, ex, testa - 2 - abs(math.sin(self.tempo_totale * 6)) * 2, re.colore)
        elif self.elisa_modo == "sveglia":
            self._bolla(s, "!", ex, testa - 2 - abs(math.sin(self.tempo_totale * 12)) * 3, ROSSO)
        elif self.elisa_modo == "sospetta":
            self._bolla(s, "?", ex, testa - 2, GIALLO)
        elif self.elisa_modo == "cerca" and self.chiamata_visibile > 0:
            self._bolla(s, self.chiamata_bolla, ex, testa - 2, (170, 230, 255))
        elif self.elisa.sosta > 0:
            self._bolla(s, "...", ex, testa, BIANCO)
        gx, gy = self.gatto.piedi()
        rg = self._richiesta_di("gatto")
        if self.gatto_sazio > 0:
            self._bolla(s, "zZ", gx, gy - 34, AZZURRO)
        elif self.gatto_caccia > 0:
            self._bolla(s, "caccia!", gx, gy - 34 - abs(math.sin(self.tempo_totale * 9)) * 3, (150, 230, 150))
        elif rg is not None:
            self._bolla(s, rg.bolla, gx, gy - 34 - abs(math.sin(self.tempo_totale * 7)) * 2, rg.colore)
        for r in self.richieste:
            if r.progresso > 0.01 and r.attiva:
                bx, by = (gx, gy - 58) if r.chi == "gatto" else (ex, testa - 26)
                self._anello(s, bx, by, r.progresso)
        if self.mano is not None and self.seduta is None:
            self._bolla(s, self.mano_nome, self.ale.x, self.ale.y - 78, (200, 230, 255))
        if self.stress > 0.8 and int(self.tempo_totale) % 4 == 0 and not self.bloccato and self.crampo_blocco <= 0:
            self._bolla(s, "!?", self.ale.x, self.ale.y - 56, ROSSO)
        if self.bloccato:
            self._bolla(s, "SPAZIO!" if self.tasca > 0 else "?", self.ale.x, self.ale.y - 54, GIALLO)
        if self.seduta is not None:
            t = self.seduta["t"]
            testo = "..." if t < 1.0 else ("ngh..." if t < SEDUTA_SECONDI - 0.7 else "ahhh")
            self._bolla(s, testo, self.ale.x, self.ale.y - 56, (255, 220, 160))
        elif self.crampo_blocco > 0:
            self._bolla(s, "ngh!", self.ale.x, self.ale.y - 54, ROSSO)

    def _disegna_barre(self):
        c, w = self.canvas, self.larghezza
        pygame.draw.rect(c, (16, 18, 38), (0, 0, w, ALTEZZA_BARRA_ALTA))
        pygame.draw.line(c, (70, 80, 150), (0, ALTEZZA_BARRA_ALTA - 1), (w, ALTEZZA_BARRA_ALTA - 1), 2)
        c.blit(self._testo_img(f"PUNTI {self.punti:06d}", GIALLO), (10, 6))
        livello = f"LIVELLO {self.indice_livello + 1}/{len(LIVELLI)}: {self.liv['nome'].upper()}"
        img = self._testo_img(livello, AZZURRO, self.f_msg)
        c.blit(img, img.get_rect(midtop=(w // 2, 8)))
        urgente = self.tempo_notte < 30 and int(self.tempo_totale * 3) % 2 == 0
        ore = self._testo_img(f"ORE {self.orologio()}", ROSSO if urgente else AZZURRO)
        c.blit(ore, (w - ore.get_width() - 12, 6))
        c.blit(self._testo_img("SONNO", BIANCO), (10, 28))
        for i in range(self.vite):
            c.blit(self.img_luna, (84 + i * 26, 28))
        totale = len(self.mondo.crocchette)
        presi = totale - len(self.crocchette)
        colore = VERDE if not self.crocchette else GIALLO
        if self.crocchette:
            conta = self._testo_img(f"OBIETTIVO: crocchette {presi}/{totale}", colore, self.f_msg)
            c.blit(conta, conta.get_rect(midtop=(w // 2 + 12, 29)))
            c.blit(self.img_croc_hud, (w // 2 - conta.get_width() // 2 - 14, 30))
        elif int(self.tempo_totale * 3) % 2 == 0:
            conta = self._testo_img("OBIETTIVO: TORNA A LETTO!", colore, self.f_msg)
            c.blit(conta, conta.get_rect(midtop=(w // 2, 29)))
        tasca = self._testo_img(f"TASCA x{self.tasca}", MARRONE)
        c.blit(tasca, (w - tasca.get_width() - 12, 28))
        c.blit(self.img_croc_hud, (w - tasca.get_width() - 38, 29))
        self._disegna_riga_richieste(w)
        self._disegna_messaggio()

    def _barra(self, c, x, y, etichetta, valore):
        c.blit(self._testo_img(etichetta, BIANCO, self.f_piccolo), (x, y))
        bx = x + 62
        pygame.draw.rect(c, (40, 44, 80), (bx, y + 3, 72, 8), border_radius=4)
        riempi = int(72 * max(0.0, min(1.0, valore)))
        if riempi > 0:
            col = (90, 200, 120) if valore < 0.5 else ((240, 200, 60) if valore < 0.85 else ROSSO)
            if valore >= 0.85 and int(self.tempo_totale * 6) % 2 == 0:
                col = (255, 150, 150)
            pygame.draw.rect(c, col, (bx, y + 3, riempi, 8), border_radius=4)

    def _disegna_riga_richieste(self, w):
        """Terza riga: AFFANNO, PANCIA e le richieste in corso con la loro pazienza."""
        c = self.canvas
        pygame.draw.line(c, (40, 46, 100), (0, 52), (w, 52), 1)
        self._barra(c, 10, 56, "AFFANNO", self.stress)
        if self._bagno_attivo():
            self._barra(c, 156, 56, "PANCIA", self.pancia)
        x = 306
        for r in self.richieste:
            larghezza = 224
            pygame.draw.rect(c, (28, 32, 74), (x, 55, larghezza, 19), border_radius=6)
            pygame.draw.rect(c, r.colore, (x, 55, larghezza, 19), width=1, border_radius=6)
            c.blit(self._testo_img(r.scheda, r.colore, self.f_piccolo), (x + 6, 57))
            frazione = max(0.0, r.pazienza / r.totale)
            col = (90, 200, 120) if frazione > 0.5 else ((240, 200, 60) if frazione > 0.25 else ROSSO)
            pygame.draw.rect(c, (40, 44, 80), (x + larghezza - 54, 61, 48, 6), border_radius=3)
            pygame.draw.rect(c, col, (x + larghezza - 54, 61, int(48 * frazione), 6), border_radius=3)
            x += larghezza + 8

    def _disegna_messaggio(self):
        c = self.canvas
        y0 = ALTEZZA_BARRA_ALTA + self.altezza_mondo
        pygame.draw.rect(c, (16, 18, 38), (0, y0, self.larghezza, ALTEZZA_BARRA_BASSA))
        pygame.draw.line(c, (70, 80, 150), (0, y0), (self.larghezza, y0), 2)
        righe, resta, chi = self.messaggio
        if resta <= 0 or not righe:
            return
        x_testo = self.larghezza // 2
        ritratto = self.ritratti.get(chi) if chi else None
        if ritratto is not None:
            c.blit(ritratto, (12, y0 + 9))
            x_testo = 12 + 48 + 14
        for i, riga in enumerate(righe):
            img = self._testo_img(riga, BIANCO, self.f_msg)
            r = img.get_rect(midleft=(x_testo, y0 + 22 + i * 22)) if ritratto is not None \
                else img.get_rect(center=(x_testo, y0 + 22 + i * 22))
            c.blit(img, r)

    def _pannello(self, titolo, colore, righe, invito):
        c = self.canvas
        if self._velo_pannello is None:
            self._velo_pannello = pygame.Surface((self.larghezza, self.altezza_mondo), pygame.SRCALPHA)
            self._velo_pannello.fill((0, 0, 10, 195))
        c.blit(self._velo_pannello, (0, ALTEZZA_BARRA_ALTA))
        cx = self.larghezza // 2
        cy = ALTEZZA_BARRA_ALTA + self.altezza_mondo // 2
        t = self.f_titolo.render(titolo, True, colore)
        c.blit(self.f_titolo.render(titolo, True, (0, 0, 0)), t.get_rect(center=(cx + 3, cy - 77)))
        c.blit(t, t.get_rect(center=(cx, cy - 80)))
        for i, riga in enumerate(righe):
            img = self._testo_img(riga, BIANCO, self.f_msg)
            c.blit(img, img.get_rect(center=(cx, cy - 20 + i * 28)))
        if int(self.tempo_totale * 2) % 2 == 0:
            img = self._testo_img(self._tocca(invito), GIALLO, self.f_grande)
            c.blit(img, img.get_rect(center=(cx, cy + 110)))

    def _tasto_guida(self, s, x, y, testo=None, freccia=None, larghezza=34):
        r = pygame.Rect(x, y, larghezza, 34)
        pygame.draw.rect(s, (30, 34, 70), r.move(0, 3), border_radius=6)
        pygame.draw.rect(s, (236, 238, 250), r, border_radius=6)
        pygame.draw.rect(s, (90, 96, 150), r, width=2, border_radius=6)
        cx, cy = r.center
        if freccia is not None:
            dx, dy = freccia
            punta = (cx + dx * 9, cy + dy * 9)
            base = (cx - dx * 6, cy - dy * 6)
            lato = (-dy * 8, dx * 8)
            pygame.draw.polygon(s, (40, 44, 90), [punta, (base[0] + lato[0], base[1] + lato[1]),
                                                  (base[0] - lato[0], base[1] - lato[1])])
        if testo:
            img = self.f_msg.render(testo, True, (40, 44, 90))
            s.blit(img, img.get_rect(center=r.center))

    def _sprite_guida(self, s, foglio, x, piedi, faccia, cammina=True):
        img = foglio.fotogramma(faccia, not cammina, self.tempo_totale * 55)
        s.blit(img, (int(x - foglio.largo / 2), int(piedi - foglio.piede - 1)))

    def _disegna_guida(self):
        c = self.canvas
        W, H = self.dimensione
        c.blit(self.intro._sfondo(W, H), (0, 0))
        titolo = self.f_titolo.render("COME SI GIOCA", True, GIALLO)
        c.blit(self.f_titolo.render("COME SI GIOCA", True, (0, 0, 0)), titolo.get_rect(center=(W // 2 + 3, 28)))
        c.blit(titolo, titolo.get_rect(center=(W // 2, 25)))
        for k, riga in enumerate(("LO SCOPO: raccogli le crocchette, esaudisci le richieste",
                                  "e torna a letto prima dell'alba. Troppe cose da fare!")):
            img = self._testo_img(riga, ROSA, self.f_hud)
            c.blit(img, img.get_rect(center=(W // 2, 58 + k * 21)))
        righe = (
            ("Cammina con le frecce (o W A S D).", "Anche in diagonale: cerca le crocchette!"),
            ("Raccogli TUTTE le crocchette che trovi", "per terra, in casa e in giardino."),
            ("Tamiyo: crocchini (SPAZIO), scatoletta", "(portagliela) o coccole (tieni SPAZIO)."),
            ("Eli: attenzioni (tieni SPAZIO vicino a lei)", "o aiuto (portale cio' che ti chiede)."),
            ("Troppe cose? L'AFFANNO sale: al massimo", "perdi un'ora di sonno. Pancia: corri in bagno!"),
            ("Alla fine torna a letto prima delle 06:00.", "Il letto lampeggia quando hai finito."),
        )
        y0, passo = 100, 84
        for i, (r1, r2) in enumerate(righe):
            y = y0 + i * passo
            pygame.draw.rect(c, (24, 28, 62), (16, y, W - 32, passo - 8), border_radius=12)
            pygame.draw.rect(c, (70, 80, 150), (16, y, W - 32, passo - 8), width=2, border_radius=12)
            c.blit(self._testo_img(r1, BIANCO, self.f_msg), (260, y + 13))
            c.blit(self._testo_img(r2, (190, 200, 240), self.f_msg), (260, y + 39))
            self._icone_guida(c, i, y)
        if int(self.tempo_totale * 2) % 2 == 0:
            img = self._testo_img(self._tocca("INVIO: INIZIA"), GIALLO, self.f_grande)
            c.blit(img, img.get_rect(center=(W // 2, H - 22)))

    def _icone_guida(self, c, i, y):
        if i == 0:
            self._sprite_guida(c, self.foglio_ale, 54, y + 66, DESTRA if int(self.tempo_totale * 1.2) % 2 == 0 else SINISTRA)
            self._tasto_guida(c, 150, y + 3, freccia=(0, -1))
            for k, d in enumerate(((-1, 0), (0, 1), (1, 0))):
                self._tasto_guida(c, 112 + k * 38, y + 37, freccia=d)
        elif i == 1:
            for k in range(3):
                img = pygame.transform.scale(self.img_croc, (42, 33))
                c.blit(img, (40 + k * 56, y + 14 + (k % 2) * 12 + int(math.sin(self.tempo_totale * 3 + k) * 3)))
        elif i == 2:
            self._sprite_guida(c, self.foglio_gatto, 46, y + 64, DESTRA if int(self.tempo_totale) % 2 == 0 else SINISTRA)
            c.blit(pygame.transform.scale(self.img_croc, (28, 22)), (92, y + 26))
            c.blit(pygame.transform.scale(self.img_scat, (34, 34)), (132, y + 20))
            c.blit(self.effetti.cuore_rosa, (186, y + 26))
        elif i == 3:
            self._sprite_guida(c, self.foglio_eli, 56, y + 66, GIU, cammina=False)
            c.blit(self.effetti.cuore_rosa, (112, y + 26))
            c.blit(pygame.transform.scale(disegna_oggetto_aiuto((120, 200, 230)), (40, 40)), (156, y + 16))
        elif i == 4:
            wc = pygame.transform.scale(disegna_water(), (48, 48))
            c.blit(wc, (28, y + 8))
            valore = 0.5 + 0.5 * math.sin(self.tempo_totale * 1.5)
            self._barra(c, 96, y + 34, "AFFANNO", valore)
            for k in range(3):
                ft = (self.tempo_totale * 0.8 + k / 3.0) % 1.0
                c.blit(self.effetti.goccia_img, (120 + k * 24, y + 8 + int(ft * 18)))
        else:
            letto = self.arte.k(*Arte.LETTO)
            if letto is None:
                letto = pygame.Surface((T, T), pygame.SRCALPHA)
                pygame.draw.rect(letto, (200, 90, 50), (2, 4, 28, 24), border_radius=4)
            c.blit(pygame.transform.scale(letto, (52, 52)), (40, y + 12))
            c.blit(self._testo_img("06:00", AZZURRO, self.f_hud), (118, y + 22))
            pygame.draw.polygon(c, GIALLO, [(34, y + 4), (50, y + 4), (42, y + 15)])

    def _bolla_guida(self, c, testo, x, y, colore):
        img = self._testo_img(testo, colore, self.f_bubble)
        r = img.get_rect(center=(x, y))
        fondo = pygame.Surface((r.width + 14, r.height + 6), pygame.SRCALPHA)
        pygame.draw.rect(fondo, (0, 0, 0, 170), fondo.get_rect(), border_radius=8)
        c.blit(fondo, (r.x - 7, r.y - 3))
        c.blit(img, r)

    def _freccia_bagno(self, s):
        """Quando la pancia chiama: freccia azzurra verso il water piu' vicino."""
        if not self._bagno_attivo() or self.pancia < 0.5 or self.seduta is not None or self.stato != "gioco":
            return
        ale = (self.ale.x, self.ale.y - 10)
        wc = min(self.mondo.gabinetti, key=lambda w: distanza(ale, ((w[0] + 0.5) * T, (w[1] + 0.5) * T)))
        bx, by = (wc[0] + 0.5) * T, (wc[1] + 0.5) * T
        d = distanza(ale, (bx, by))
        if d < 44:
            return
        dx, dy = (bx - ale[0]) / d, (by - ale[1]) / d
        pulsa = 34 + math.sin(self.tempo_totale * 9) * 4
        px, py = ale[0] + dx * pulsa, ale[1] + dy * pulsa
        lato = (-dy * 7, dx * 7)
        punta = (px + dx * 9, py + dy * 9)
        base = (px - dx * 5, py - dy * 5)
        pts = [punta, (base[0] + lato[0], base[1] + lato[1]), (base[0] - lato[0], base[1] - lato[1])]
        pygame.draw.polygon(s, (150, 220, 255), pts)
        pygame.draw.polygon(s, (20, 70, 110), pts, 2)
        s.blit(self._testo_img("WC", (150, 220, 255), self.f_piccolo), (int(px - 9), int(py - 20)))

    def _freccia_aiuto(self, s):
        """Nei primi secondi del primo livello: freccia verso la crocchetta piu' vicina."""
        if self.indice_livello != 0 or self.senza_raccolta < 6 or not self.crocchette or self.stato != "gioco":
            return
        ale = (self.ale.x, self.ale.y - 10)
        vicina = min(self.crocchette, key=lambda cella: distanza(ale, self._centro_oggetto(cella)))
        bx, by = self._centro_oggetto(vicina)
        d = distanza(ale, (bx, by))
        if d < 40:
            return
        dx, dy = (bx - ale[0]) / d, (by - ale[1]) / d
        pulsa = 30 + math.sin(self.tempo_totale * 8) * 4
        px, py = ale[0] + dx * pulsa, ale[1] + dy * pulsa
        lato = (-dy * 7, dx * 7)
        punta = (px + dx * 9, py + dy * 9)
        base = (px - dx * 5, py - dy * 5)
        pts = [punta, (base[0] + lato[0], base[1] + lato[1]), (base[0] - lato[0], base[1] - lato[1])]
        pygame.draw.polygon(s, GIALLO, pts)
        pygame.draw.polygon(s, (90, 60, 10), pts, 2)

    def _disegna_schermate(self):
        if self.stato == "pronti":
            img = self.f_titolo.render("PRONTI?", True, GIALLO)
            self.canvas.blit(img, img.get_rect(center=(self.larghezza // 2, ALTEZZA_BARRA_ALTA + self.altezza_mondo // 2)))
        elif self.stato == "pausa":
            self._pannello("PAUSA", AZZURRO, ("Frecce / WASD: cammina      SPAZIO: azione",
                                              "Raccogli le crocchette e torna a letto prima dell'alba.",
                                              "Eli e Tamiyo ti chiedono cose: esaudiscile!",
                                              "Troppe richieste? L'AFFANNO sale. E il bagno chiama...", "",
                                              "M: suoni      ESC: esci"), "premi P per continuare")
        elif self.stato == "fine":
            self._schermata_fine()

    def _schermata_fine(self):
        n = self.indice_livello + 1
        if self.esito == "livello":
            titolo, colore, righe = f"LIVELLO {n} FINITO!", VERDE, self.liv["fine"]
            invito = f"INVIO: livello {n + 1}"
        elif self.esito == "vittoria":
            titolo, colore, righe = TITOLO_SCHERMATA_VITTORIA, GIALLO, FRASI_VITTORIA
            invito = "INVIO: ricomincia"
        elif self.esito == "vite":
            titolo, colore, righe = TITOLO_SCHERMATA_VITE, ROSSO, FRASI_VITE_FINITE
            invito = "INVIO: riprova il livello"
        else:
            titolo, colore, righe = TITOLO_SCHERMATA_SOLE, ARANCIO, FRASI_SOLE
            invito = "INVIO: riprova il livello"
        righe = tuple(righe) + ("", f"Punti: {self.punti}   Record: {self.record}")
        self._pannello(titolo, colore, righe, invito)

    # ------------------------------------------------------- ciclo principale
    def presenta(self):
        W, H = self.dimensione
        fw, fh = self.finestra.get_size()
        scala = min(fw / W, fh / H)
        nuova = (max(1, int(W * scala)), max(1, int(H * scala)))
        if nuova == (W, H):
            immagine = self.canvas
        elif abs(scala - round(scala)) < 0.01:
            immagine = pygame.transform.scale(self.canvas, nuova)
        else:
            immagine = pygame.transform.smoothscale(self.canvas, nuova)
        self.finestra.fill((0, 0, 0))
        self._scala_vista = scala
        self._off_vista = ((fw - nuova[0]) // 2, (fh - nuova[1]) // 2)
        self.finestra.blit(immagine, self._off_vista)
        pygame.display.flip()

    # ----------------------------------------------------- comandi a tocco (telefono)
    def _tocca(self, testo):
        """Sui telefoni 'INVIO' diventa 'TOCCA'."""
        return testo.replace("INVIO", "TOCCA").replace("PREMI TOCCA", "TOCCA PER INIZIARE") if self.mostra_controlli else testo

    def _zone_controlli(self):
        y = ALTEZZA_BARRA_ALTA + self.altezza_mondo - 84
        return {"croce": (84, y, 64), "azione": (self.larghezza - 84, y, 44),
                "pausa": (self.larghezza - 34, ALTEZZA_BARRA_ALTA + 34, 24)}

    def _punto_gioco(self, x, y):
        sc = self._scala_vista or 1.0
        return ((x - self._off_vista[0]) / sc, (y - self._off_vista[1]) / sc)

    def _tocco(self, evento):
        t = evento.type
        if t in (pygame.FINGERDOWN, pygame.FINGERMOTION, pygame.FINGERUP):
            fw, fh = self.finestra.get_size()
            punto = self._punto_gioco(evento.x * fw, evento.y * fh)
            ident = ("f", getattr(evento, "finger_id", 0))
            giu, nuovo = t != pygame.FINGERUP, t == pygame.FINGERDOWN
            self.mostra_controlli = True
        elif t in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
            if t == pygame.MOUSEMOTION and not evento.buttons[0]:
                return
            punto = self._punto_gioco(*evento.pos)
            ident = ("m", 0)
            giu, nuovo = t != pygame.MOUSEBUTTONUP, t == pygame.MOUSEBUTTONDOWN
            if getattr(evento, "touch", False):
                self.mostra_controlli = True
        else:
            return
        if giu:
            self.tocchi[ident] = punto
        else:
            self.tocchi.pop(ident, None)
        if not nuovo:
            return
        if self.stato in ("titolo", "guida", "fine"):
            self.tocchi.clear()
            self._conferma()
        elif self.stato == "pausa":
            self.tocchi.clear()
            self._pausa()
        elif self.mostra_controlli and self.stato == "gioco":
            zone = self._zone_controlli()
            ax, ay, ar = zone["azione"]
            px, py, pr = zone["pausa"]
            y_mondo = (punto[0], punto[1])
            if distanza(y_mondo, (ax, ay)) < ar + 18:
                self.tasto(pygame.K_SPACE)
            elif distanza(y_mondo, (px, py)) < pr + 12:
                self._pausa()

    def _direzione_tocco(self):
        cx, cy, raggio = self._zone_controlli()["croce"]
        vx = vy = 0
        for (x, y) in self.tocchi.values():
            dx, dy = x - cx, y - cy
            if math.hypot(dx, dy) < raggio * 1.7:
                if abs(dx) > raggio * 0.3:
                    vx = 1 if dx > 0 else -1
                if abs(dy) > raggio * 0.3:
                    vy = 1 if dy > 0 else -1
        return vx, vy

    def _disegna_controlli(self):
        if not self.mostra_controlli or self.stato not in ("gioco", "pronti", "pausa"):
            return
        if self._controlli_img is None:
            img = pygame.Surface(self.dimensione, pygame.SRCALPHA)
            zone = self._zone_controlli()
            cx, cy, r = zone["croce"]
            pygame.draw.circle(img, (255, 255, 255, 40), (cx, cy), r)
            pygame.draw.circle(img, (255, 255, 255, 110), (cx, cy), r, 3)
            for (dx, dy) in DIREZIONI:
                punta = (cx + dx * (r - 14), cy + dy * (r - 14))
                base = (cx + dx * (r - 34), cy + dy * (r - 34))
                lato = (-dy * 10, dx * 10)
                pygame.draw.polygon(img, (255, 255, 255, 150), [punta, (base[0] + lato[0], base[1] + lato[1]),
                                                                (base[0] - lato[0], base[1] - lato[1])])
            ax, ay, ar = zone["azione"]
            pygame.draw.circle(img, (255, 221, 0, 60), (ax, ay), ar)
            pygame.draw.circle(img, (255, 221, 0, 150), (ax, ay), ar, 3)
            testo = self.f_piccolo.render("SPAZIO", True, (255, 240, 160))
            img.blit(testo, testo.get_rect(center=(ax, ay)))
            px, py, pr = zone["pausa"]
            pygame.draw.circle(img, (255, 255, 255, 50), (px, py), pr)
            pygame.draw.rect(img, (255, 255, 255, 170), (px - 7, py - 8, 5, 16))
            pygame.draw.rect(img, (255, 255, 255, 170), (px + 2, py - 8, 5, 16))
            self._controlli_img = img
        self.canvas.blit(self._controlli_img, (0, 0))

    # ------------------------------------------------------- ciclo principale
    def _fotogramma(self):
        """Un fotogramma di gioco. Ritorna False quando si deve uscire."""
        dt = min(self.clock.tick(FPS) / 1000.0, 0.05)
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return False
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_ESCAPE and not WEB:
                    return False
                self.tasto(evento.key)
            else:
                self._tocco(evento)
        self.aggiorna(dt)
        self.disegna()
        self.presenta()
        return True

    def esegui(self):
        while self._fotogramma():
            pass

    async def esegui_async(self):
        """Stesso ciclo, ma cede il controllo al browser a ogni fotogramma."""
        while self._fotogramma():
            await asyncio.sleep(0)


CAMPI_LIVELLO = ("nome", "intro", "fine", "mappa", "tappe", "crocchette", "scatolette", "muri",
                 "elisa_giro", "elisa_sveglia", "sveglia_secondi", "errore", "curiosita", "notte_secondi")


def _numero(valore, nome, minimo=None, massimo=None, intero=False, dove=""):
    """Controlla che 'valore' sia un numero (intero se serve) nell'intervallo, con un errore in italiano."""
    tipi = (int,) if intero else (int, float)
    if isinstance(valore, bool) or not isinstance(valore, tipi):
        raise ValueError(f"{dove}'{nome}' deve essere un numero{' intero' if intero else ''} (senza virgolette"
                         f"{', senza virgola' if intero else ''}).")
    if (minimo is not None and valore < minimo) or (massimo is not None and valore > massimo):
        raise ValueError(f"{dove}'{nome}' deve essere tra {minimo} e {massimo}.")
    return valore


def _celle(valore, nome, dove):
    try:
        return tuple((int(c), int(r)) for c, r in valore)
    except (TypeError, ValueError):
        raise ValueError(f"{dove}'{nome}' deve essere un elenco di coppie (colonna, riga), "
                         f"per esempio ((2, 2), (5, 7)).")


def crea_mondi():
    """Controlla ogni livello e ne costruisce la casa, dicendo quale livello ha un problema."""
    if not LIVELLI:
        raise ValueError("LIVELLI e' vuoto: serve almeno un livello.")
    mondi = []
    for n, livello in enumerate(LIVELLI, start=1):
        dove = f"Livello {n} ({livello.get('nome', '?')}): "
        mancanti = [campo for campo in CAMPI_LIVELLO if campo not in livello]
        if mancanti:
            raise ValueError(f"Nel livello {n} mancano questi campi: {', '.join(mancanti)}.")
        _numero(livello["notte_secondi"], "notte_secondi", 1, 3600, dove=dove)
        _numero(livello["sveglia_secondi"], "sveglia_secondi", 0.5, 600, dove=dove)
        _numero(livello["elisa_giro"], "elisa_giro", 0.2, 3, dove=dove)
        _numero(livello["elisa_sveglia"], "elisa_sveglia", 0.2, 3, dove=dove)
        _numero(livello["errore"], "errore", 0, 1, dove=dove)
        _numero(livello["curiosita"], "curiosita", 0, 1, dove=dove)
        _numero(livello["crocchette"], "crocchette", 1, 2000, intero=True, dove=dove)
        livello["tappe"] = _celle(livello["tappe"], "tappe", dove)
        livello["scatolette"] = _celle(livello["scatolette"], "scatolette", dove)
        try:
            mondo = Mondo(livello)
        except ValueError as errore:
            raise ValueError(f"{dove}{errore}")
        if not any(t in mondo.raggiungibili for t in livello["tappe"]):
            raise ValueError(f"{dove}nessuna delle 'tappe' di Eli e' una casella di pavimento raggiungibile.")
        mondi.append(mondo)
    return mondi


def controlla_configurazione(mondi):
    """Ferma il gioco con un messaggio chiaro se una costante in cima al file non ha senso."""
    _numero(ZOOM, "ZOOM", 0.3, 4)
    _numero(OSCURITA, "OSCURITA", 0, 255)
    _numero(RAGGIO_LUCE, "RAGGIO_LUCE", 0, 600)
    _numero(ELISA_VISTA_CELLE, "ELISA_VISTA_CELLE", 0, 40)
    _numero(ELISA_SOSPETTO_SECONDI, "ELISA_SOSPETTO_SECONDI", 0, 20)
    _numero(ELISA_RICERCA_SECONDI, "ELISA_RICERCA_SECONDI", 0, 60)
    for nome, valore in (("VELOCITA_IO", VELOCITA_IO), ("VELOCITA_ELISA_GIRO", VELOCITA_ELISA_GIRO),
                         ("VELOCITA_ELISA_SVEGLIA", VELOCITA_ELISA_SVEGLIA), ("VELOCITA_GATTO", VELOCITA_GATTO)):
        _numero(valore, nome, 10, 600)
    _numero(VITE_INIZIALI, "VITE_INIZIALI", 1, 20, intero=True)
    _numero(SEDUTA_SECONDI, "SEDUTA_SECONDI", 1.5, 30)
    _numero(RICHIESTA_PRIMA_SECONDI, "RICHIESTA_PRIMA_SECONDI", 0, 600)
    _numero(PAZIENZA_SECONDI, "PAZIENZA_SECONDI", 3, 600)
    _numero(TENUTA_SECONDI, "TENUTA_SECONDI", 0.3, 20)
    for nome, valore in (("GATTO_CACCIA_CROCCHINO", GATTO_CACCIA_CROCCHINO),
                         ("GATTO_CACCIA_COCCOLE", GATTO_CACCIA_COCCOLE),
                         ("GATTO_CACCIA_SCATOLETTA", GATTO_CACCIA_SCATOLETTA)):
        _numero(valore, nome, 0, 600)
    _numero(PUNTI_RICHIESTA, "PUNTI_RICHIESTA", 0, 100000, intero=True)
    _numero(PUNTI_SOLLIEVO, "PUNTI_SOLLIEVO", 0, 100000, intero=True)
    _numero(TASCA_INIZIALE, "TASCA_INIZIALE", 0, 99, intero=True)
    _numero(TASCA_MASSIMA, "TASCA_MASSIMA", 1, 99, intero=True)
    for nome, valore in (("PUNTI_CROCCHETTA", PUNTI_CROCCHETTA), ("PUNTI_SCATOLETTA", PUNTI_SCATOLETTA),
                         ("PUNTI_CROCCHETTA_AL_GATTO", PUNTI_CROCCHETTA_AL_GATTO),
                         ("PUNTI_PER_VITA_RIMASTA", PUNTI_PER_VITA_RIMASTA),
                         ("PUNTI_PER_SECONDO_RIMASTO", PUNTI_PER_SECONDO_RIMASTO)):
        _numero(valore, nome, 0, 100000, intero=True)
    for nome, valore in (("ELISA_GIRO_SECONDI", ELISA_GIRO_SECONDI), ("ELISA_SOSTA_SECONDI", ELISA_SOSTA_SECONDI),
                         ("BISOGNO_SECONDI", BISOGNO_SECONDI), ("RICHIESTA_OGNI_SECONDI", RICHIESTA_OGNI_SECONDI)):
        try:
            minimo, massimo = valore
        except (TypeError, ValueError):
            raise ValueError(f"'{nome}' deve essere una coppia di numeri, per esempio (8, 14).")
        _numero(minimo, nome, 0, 600)
        _numero(massimo, nome, 0, 600)
        if minimo > massimo:
            raise ValueError(f"'{nome}' deve essere una coppia (minimo, massimo) con minimo <= massimo.")
    for nome in (FILE_ALE_CAMMINATA, FILE_ELISA_CAMMINATA, FILE_GATTO_CAMMINATA, FILE_RITRATTO_ALE,
                 FILE_RITRATTO_ELISA, FILE_RITRATTO_GATTO, FILE_ARREDI, FILE_ALE_SEDUTO_VESTITO, FILE_ALE_SEDUTO_NUDO):
        if not isinstance(nome, str) or not nome:
            raise ValueError("I nomi dei file immagine (FILE_...) devono essere testo, per esempio \"io.png\".")
        if "\\" in nome or "\x07" in nome:
            raise ValueError(f"Nel nome del file '{nome}' usa la barra normale '/' e non quella rovesciata.")
    for brano in MUSICHE.values():
        for nota in list(brano["melodia"]) + list(brano["basso"]):
            frequenza_nota(nota)
    prima = mondi[0]
    for n, mondo in enumerate(mondi, start=1):
        if (mondo.colonne, mondo.righe_n) != (prima.colonne, prima.righe_n):
            raise ValueError(f"La mappa del livello {n} ha una grandezza diversa dalla prima "
                             f"({mondo.colonne} x {mondo.righe_n} invece di {prima.colonne} x {prima.righe_n}).")
    if prima.colonne * T < 640 or prima.righe_n * T < 380:
        raise ValueError("La mappa e' troppo piccola per le schermate del gioco: servono almeno 20 colonne e 12 righe.")


def crea_finestra(dimensione):
    grandezza = (int(dimensione[0] * ZOOM), int(dimensione[1] * ZOOM))
    try:
        return pygame.display.set_mode(grandezza, pygame.RESIZABLE)
    except pygame.error:
        return pygame.display.set_mode(grandezza)


def _icona_finestra():
    """L'icona della finestra e' il muso di Tamiyo."""
    percorso = trova_file(FILE_RITRATTO_GATTO)
    if percorso is not None:
        try:
            pygame.display.set_icon(pygame.transform.smoothscale(pygame.image.load(str(percorso)), (32, 32)))
        except (pygame.error, OSError, ValueError):
            pass


def _mostra_caricamento(finestra):
    finestra.fill((10, 12, 26))
    try:
        font = pygame.font.Font(None, 44)
        img = font.render("CARICAMENTO...", True, (255, 221, 0))
        finestra.blit(img, img.get_rect(center=(finestra.get_width() // 2, finestra.get_height() // 2)))
    except (pygame.error, OSError):
        pass
    pygame.display.flip()


def _prepara():
    """Controlla la configurazione e apre la finestra. Ritorna (finestra, mondi) o None se c'e' un errore."""
    pygame.init()
    try:
        mondi = crea_mondi()
        controlla_configurazione(mondi)
    except (ValueError, TypeError, KeyError) as errore:
        print(f"Errore nella configurazione: {errore}")
        pygame.quit()
        try:
            input("Premi INVIO per chiudere...")
        except (EOFError, OSError, RuntimeError):
            pass
        return None
    prima = mondi[0]
    dimensione = (prima.colonne * T, prima.righe_n * T + ALTEZZA_BARRA_ALTA + ALTEZZA_BARRA_BASSA)
    _icona_finestra()
    finestra = crea_finestra(dimensione)
    pygame.display.set_caption(TITOLO_FINESTRA)
    _mostra_caricamento(finestra)
    return finestra, mondi


def main():
    preparato = _prepara()
    if preparato is None:
        sys.exit(1)
    gioco = Gioco(*preparato)
    prova = os.environ.get("CROCCHETTE_PROVA")
    if prova:                       # solo per i controlli automatici: gira per N fotogrammi ed esce
        for _ in range(int(prova)):
            if not gioco._fotogramma():
                break
        print("PROVA OK", gioco.stato, "| font incluso:", (CARTELLA_FONT / "Cousine-Bold.ttf").is_file(),
              "| suoni veri:", len(getattr(gioco.suoni, "campioni", {})), "| immagini:", gioco.foglio_ale.n)
        pygame.quit()
        return
    gioco.esegui()
    pygame.quit()


async def main_async():
    """Avvio per il browser (pygbag)."""
    preparato = _prepara()
    if preparato is None:
        return
    await asyncio.sleep(0.05)
    await Gioco(*preparato).esegui_async()


if __name__ == "__main__":
    main()
