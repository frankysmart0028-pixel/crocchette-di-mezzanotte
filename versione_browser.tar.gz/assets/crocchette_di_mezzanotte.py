#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CROCCHETTE DI MEZZANOTTE  -  un gioco per Ale ed Eli
=====================================================

Sono le 2 di notte. Tamiyo ha sparso le crocchette per casa e in giardino.
Tu (Ale) cammini in punta di piedi, le raccogli tutte e torni a letto prima
dell'alba. Ma Eli non sta mai ferma: va dal letto al bagno, dalla cucina al
letto... e se ti vede, ti sveglia del tutto. E ogni tanto Tamiyo ti ferma per
chiederti una crocchetta.

COMANDI
    Frecce (o W A S D)   cammina
    SPAZIO               dai una crocchetta a Tamiyo (quando ti blocca)
    INVIO                inizia / continua
    P                    pausa
    M                    musica e suoni on/off
    ESC                  esci

COME AVVIARLO
    python crocchette_di_mezzanotte.py        (vedi GUIDA.md per i dettagli)

LE IMMAGINI (nella cartella "immagini", accanto a questo file)
    personaggi\\ale_walk.png, eli_walk.png, gatto_walk.png   i personaggi che camminano
    io.png, elisa.png, gatto.png                            i ritratti nei fumetti
    kenney\\arredi.png                                       i mobili (Kenney, CC0)
Se un file manca, il gioco usa un disegno semplice al suo posto e non si blocca.
"""

import asyncio
import math
import os
import random
import sys
from array import array
from collections import deque
from pathlib import Path

import pygame

# =============================================================================
#  CONFIGURAZIONE  -  QUI PUOI CAMBIARE QUASI TUTTO
# =============================================================================

TITOLO_FINESTRA = "Non ero calcolato!.. Bei tempi!"
FPS = 60

# --- FINESTRA E ATMOSFERA ---------------------------------------------------
# ZOOM ingrandisce tutta la finestra (1.0 = normale, 1.25 o 1.5 = piu' grande).
# Se lo schermo e' piccolo prova 0.85. La finestra si puo' anche trascinare.
ZOOM = 1.0
PAUSA_TRA_MESSAGGI = 1.2         # secondi di respiro tra un messaggio e il successivo
PAUSA_CODA_MAX = 2            # quanti messaggi al massimo aspettano il loro turno
ZOOM_TELEFONO = 1.65          # sul telefono la mappa si ingrandisce intorno ad Ale (1.0 = tutta la mappa)
JOY_MORTA = 20                # (unita' della tela) sotto questa distanza il joystick sta fermo
JOY_MAX = 80                  # oltre questa distanza la base del joystick segue il dito
OSCURITA = 125        # quanto e' buia la casa: 0 = luci accese, 200 = molto buio
RAGGIO_LUCE = 150     # quanto illumina la tua torcia (in pixel)
EFFETTO_CRT = False   # righe orizzontali stile vecchio monitor

# --- VELOCITA' (pixel al secondo; una stanza e' larga circa 150-200 pixel) ---
# Piu' alto = piu' veloce. Per rendere il gioco piu' facile abbassa la velocita'
# di Eli e del gatto, oppure alza quella di Ale.
VELOCITA_IO = 135                # Ale
VELOCITA_ELISA_GIRO = 120        # Eli quando va in giro per casa
VELOCITA_ELISA_SVEGLIA = 108     # Eli quando ti cerca
VELOCITA_GATTO = 95              # Tamiyo

# --- REGOLE -----------------------------------------------------------------
VITE_INIZIALI = 3                # le "ore di sonno" che puoi perdere
TASCA_INIZIALE = 2               # crocchette che hai in tasca all'inizio
TASCA_MASSIMA = 9

SCATOLETTA_SECONDI_EXTRA = 10    # secondi di notte guadagnati con la scatoletta
GATTO_CACCIA_CROCCHINO = 10      # dopo un crocchino Tamiyo va a caccia di insetti in giardino per...
GATTO_CACCIA_COCCOLE = 8         # ...dopo le coccole...
GATTO_CACCIA_SCATOLETTA = 30     # ...dopo la scatoletta ci sta molto di piu' (tempo guadagnato per te)

RICHIESTE_ATTIVE = True          # True = Eli e Tamiyo ti chiedono cose (attenzioni, aiuto, coccole, scatolette)
RICHIESTA_PRIMA_SECONDI = 14     # dopo quanti secondi arriva la prima richiesta
RICHIESTA_OGNI_SECONDI = (10, 17)  # ogni quanto ne arriva una nuova (minimo, massimo)
PAZIENZA_SECONDI = 28            # quanto aspettano prima di offendersi
TENUTA_SECONDI = 2.2             # quanto tieni premuto SPAZIO per coccole e attenzioni
PUNTI_RICHIESTA = 80             # punti per ogni richiesta esaudita
STRESS_ATTIVO = True             # True = l'AFFANNO sale quando hai troppe cose da fare
BISOGNO_ATTIVO = True            # True = ogni tanto Ale deve andare in bagno (pancia in subbuglio)
BISOGNO_SECONDI = (110, 170)       # dopo quanti secondi la pancia "chiama" (minimo, massimo)
SEDUTA_SECONDI = 3.2             # quanto dura la seduta in bagno (non ti alzi prima!)
PUNTI_SOLLIEVO = 50              # punti per il sollievo

GATTO_PAZIENZA = 2.0             # se non hai crocchette, dopo quanti secondi si stufa
GATTO_RIPOSO = 8.0               # dopo una crocchetta Tamiyo ti lascia in pace per...

ELISA_GIRO_SECONDI = (8, 14)     # per quanto tempo Eli gira per casa (min, max)
ELISA_SOSTA_SECONDI = (0.8, 1.8) # quanto si ferma a "fare le sue cose"
ELISA_VISTA_CELLE = 5.5          # da quanto lontano ti nota (in "caselle"); 0 = non ti nota mai
ELISA_SOSPETTO_SECONDI = 0.7     # per quanto resta col dubbio ("?") prima di inseguirti
ELISA_RICERCA_SECONDI = 7.0      # per quanto ti cerca, chiamandoti, quando ti ha perso
# (la durata della notte, quanto Eli ti cerca, quanto sbaglia strada e quanto il
#  gatto ti segue cambiano da livello a livello: vedi LIVELLI qui sotto)

# --- PUNTEGGI ---------------------------------------------------------------
PUNTI_CROCCHETTA = 10
PUNTI_SCATOLETTA = 50
PUNTI_CROCCHETTA_AL_GATTO = 20
PUNTI_PER_VITA_RIMASTA = 100     # bonus a fine livello
PUNTI_PER_SECONDO_RIMASTO = 2

# --- FINE LIVELLO: Ale sparisce con un puf e vola via su un aereo VDS ----------
VOLO_SPARIZIONE = 0.9            # secondi di luccichii prima del puf
VOLO_INGRESSO = 1.7              # dopo quanti secondi entra l'aereo
VOLO_VELOCITA = 250              # velocita' dell'aereo che sorvola casa (pixel al secondo)
VOLO_ARRIVO_INGRESSO = 0.1       # all'inizio del livello dopo
VOLO_ARRIVO_VELOCITA = 330
VOLO_RISATA_DURATA = 0.95         # quanto dura la risata (5 'ha'), poi una breve pausa
VOLO_RISATA = 1.25               # ogni quanti secondi Ale ride dal finestrino
VOLO_QUOTA_USCITA = 410           # altezza (dal bordo alto della scena) a cui vola l'aereo che esce
VOLO_SCALA_SCOOTER = 0.62        # grandezza dello scooter (passaggio al terzo livello)
VOLO_VELOCITA_SCOOTER = 300      # velocita' dello scooter (pixel al secondo)
SCOOTER_RITARDO = 330            # di quanto Elisa resta indietro mentre li insegue (pixel)
SCOOTER_TERRA = 430              # altezza della strada (dal bordo alto della scena)
VOLO_SCALA_AEREO = 0.62          # grandezza dell'aereo (e del pilota) rispetto al disegno di base
VOLO_PIROETTA_X = 400            # a che punto (pixel da sinistra) l'aereo inizia la piroetta all'indietro (la 'e' corsiva)
VOLO_PIROETTA_RAGGIO = 140       # raggio del giro
VOLO_PIROETTA_SECONDI = 2.6      # durata del giro
VOLO_VELOCITA_DOPO = 420         # velocita' dopo la piroetta, per uscire in fretta
NUVOLE_SECONDI = 0.95            # durata di ogni passaggio di nuvole (transizione)
COLORI_MAGIA = ((255, 230, 100), (255, 140, 200), (150, 220, 255), (190, 160, 255))

# --- AUDIO ------------------------------------------------------------------
SUONI_ATTIVI = True

# --- FILE IMMAGINI (cartella "immagini"; puoi cambiare i nomi qui) -----------
FILE_ALE_CAMMINATA = "personaggi/ale_walk.png"
FILE_ELISA_CAMMINATA = "personaggi/eli_walk.png"
FILE_GATTO_CAMMINATA = "personaggi/gatto_walk.png"
FILE_ALE_SEDUTO_VESTITO = "personaggi/ale_sit_pantaloni.png"
FILE_ALE_SEDUTO_NUDO = "personaggi/ale_sit_nudo.png"
FILE_RITRATTO_ALE = "io.png"
FILE_FACCIA_ELISA = "pilota/faccia_elisa.png"      # il viso di Elisa dalla foto (la crea strumenti/crea_elisa.py)
ELISA_OCCHI = (180, 270)         # punto del ritaglio al centro tra gli occhi
ELISA_UNITA = 0.23               # unita' del disegno per ogni pixel del ritaglio
FILE_FACCIA_TAMIYO = "pilota/faccia_tamiyo.png"    # la testa di Tamiyo dalla foto (la crea strumenti/crea_tamiyo.py)
TAMIYO_OCCHI = (209, 233)        # punto del ritaglio al centro tra gli occhi
TAMIYO_UNITA = 0.24              # unita' del disegno per ogni pixel del ritaglio
FILE_FACCIA_PILOTA = "pilota/faccia_ale.png"      # faccia scorporata dalla foto (la crea strumenti/crea_faccia.py)
# misure del ritaglio (pixel del file): fascia della bocca (inizio denti, fine labbro), centro e larghezza della
# deformazione, occhi; FACCIA_UNITA = unita' del disegno per ogni pixel del ritaglio; APERTURA = quanto si allunga la bocca
FACCIA_BOCCA = (378, 450, 242, 96)
FACCIA_OCCHI = (200, 219)        # punto del ritaglio che va al centro della testa, all'altezza degli occhi
FACCIA_UNITA = 0.235
FACCIA_APERTURA = (-18, 62)
FILE_RITRATTO_ELISA = "elisa.png"
FILE_RITRATTO_GATTO = "gatto.png"
FILE_ARREDI = "kenney/arredi.png"

# --- LIVELLI ----------------------------------------------------------------
# Ogni livello ha la sua casa (mappa) e la sua difficolta'. Per aggiungerne uno
# copia un blocco { ... } e cambialo. TUTTE le mappe devono avere la stessa
# grandezza (24 x 17 qui), cosi' la finestra non cambia.
#
# COME SI DISEGNA UNA MAPPA (una riga = una fila di caselle, tutte lunghe uguali)
#   Pareti e fuori:   #  muro     w  muro con finestra     q  muro con quadro
#                     H  siepe    Z  albero                x  aiuola (si cammina)
#   Pavimenti:        .  legno    :  piastrelle    _  cemento    ,  erba
#                     g  pietra   r  tappeto       d  porta (si cammina)
#   Mobili (si urtano):  T tavolo   A sedia   S divano   K mobile cucina
#                     N lavello   V fornelli   F frigo   P pianta   B libreria
#                     W armadio   Y water   X lavandino   U vasca   D scrivania
#                     M mobile TV   I letto singolo   p pilastro
#   Speciali:         L  il tuo letto (qui parte Ale e qui devi tornare)
#                     E  qui parte Eli      G  qui parte Tamiyo
# Le crocchette e le scatolette NON si scrivono nella mappa: il gioco sparge
# le crocchette da solo ("crocchette" = quante) e le scatolette stanno nelle
# caselle (colonna, riga) elencate in "scatolette".
#
# PARAMETRI DI DIFFICOLTA' (piu' alto = piu' difficile, tranne "errore"):
#   elisa_giro / elisa_sveglia   moltiplicano la velocita' di Eli
#   sveglia_secondi              quanto a lungo Eli ti cerca davvero
#   errore                       quanto spesso Eli sbaglia strada (0 = mai)
#   curiosita                    quanto Tamiyo ti segue (0 = vaga a caso)
#   notte_secondi                tempo a disposizione (02:00 -> 06:00)
#   tappe                        posti dove Eli va "a fare le sue cose" (colonna, riga)
# La casa di Via Castelfidardo: tutti e tre i livelli si svolgono qui (cambiano velocita' di Eli, tempo, crocchette,
# pancia e dove stanno le crocchette), cosi' la casa diventa familiare.
MAPPA_CASA = (
            "HHHHHHHHHHHHHHHHHHHHHHHH",
            "HZ,,,x,,,,,,,,,,,x,,,,ZH",
            "H,,###d#####d########,,H",
            "H,,#w#dwq#w#dw#qw##w#,,H",
            "H,,#FK:NV#.L..W#YX:U#,,H",
            "H,,#:G:TT#.rrr.#:::U#,,H",
            "H,,#:::AA#Prrr.#:::U#,,H",
            "H,,###d#####d####d###,,H",
            "H,,#B.......rrrrr..P#,,H",
            "H,,#........rrrrr...#,,H",
            "H,,#.rrr.###d####d###,,H",
            "H,,#.SSS.#B...B#P...#,,H",
            "H,,d..T..#...AD#...I#,,H",
            "H,,#.MMM.#P...D#..EI#,,H",
            "H,,###w###w###w###w##,,H",
            "HZ,,,x,,,,,,,,,,,,x,,,ZH",
            "HHHHHHHHHHHHHHHHHHHHHHHH",
)
TAPPE_CASA = ((17, 5), (18, 13), (6, 5), (12, 5), (6, 9), (12, 12), (14, 8), (12, 1))

LIVELLI = (
    {
        "nome": "Via Castelfidardo",
        "intro": ("Sono le 2:00. Tamiyo ha sparso le crocchette!",
                  "Raccoglile tutte e corri al letto prima dell'alba."),
        "fine": ("Puf! Ale sparisce e vola via. Che notte!",
                 "Ma Tamiyo ha gia' un altro piano..."),
        "elisa_giro": 1.0, "elisa_sveglia": 1.0, "sveglia_secondi": 6,
        "errore": 0.12, "curiosita": 0.35, "notte_secondi": 240,
        "crocchette": 44, "seme": 11, "bisogno": (110, 170),
        "scatolette": ((2, 2), (21, 2), (2, 15), (21, 15)),
        "muri": "intonaco", "colore_muro": (222, 204, 172), "divano": (150, 78, 66),
        "mappa": MAPPA_CASA,
        "tappe": TAPPE_CASA,
    },
    {
        "nome": "Via Castelfidardo",
        "intro": ("Livello 2: un'altra notte, stessa casa.",
                  "Eli ha il sonno piu' leggero e Tamiyo ti segue di piu'!"),
        "fine": ("Puf! Anche stanotte ce l'hai fatta!",
                 "Ma l'ultima notte sara' la piu' dura..."),
        "elisa_giro": 1.08, "elisa_sveglia": 1.05, "sveglia_secondi": 7,
        "errore": 0.08, "curiosita": 0.45, "notte_secondi": 225,
        "crocchette": 48, "seme": 23, "bisogno": (85, 130),
        "scatolette": ((2, 2), (21, 2), (2, 15), (21, 15)),
        "muri": "intonaco", "colore_muro": (222, 204, 172), "divano": (150, 78, 66),
        "mappa": MAPPA_CASA,
        "tappe": TAPPE_CASA,
    },
    {
        "nome": "Via Castelfidardo",
        "intro": ("Livello 3: l'ultima notte!",
                  "Crocchette ovunque. Eli corre, Tamiyo ti segue."),
        "fine": ("Buongiorno, Via Castelfidardo!",
                 "Ale si sveglia sorridendo."),
        "elisa_giro": 1.17, "elisa_sveglia": 1.12, "sveglia_secondi": 8,
        "errore": 0.04, "curiosita": 0.55, "notte_secondi": 220,
        "crocchette": 54, "seme": 37, "bisogno": (65, 100),
        "scatolette": ((2, 2), (21, 2), (2, 15), (21, 15)),
        "muri": "intonaco", "colore_muro": (222, 204, 172), "divano": (150, 78, 66),
        "mappa": MAPPA_CASA,
        "tappe": TAPPE_CASA,
    },
)

# --- FRASI ------------------------------------------------------------------
# Cambiale quando ti vengono in mente quelle vere di Eli! Ogni voce e' una
# coppia di righe (riga 1, riga 2).
FRASI_ELISA = (
    ("Ale... dormi?", "Eli ti ha svegliato!"),
    ("Torno subito, tu dormi!", "Ma ormai sei sveglio."),
    ("Scusa, ti ho svegliato?", "Un po'..."),
    ("Amore, che ore sono?", "Troppo presto per essere sveglio."),
)
FRASI_ELISA_SOSPETTA = ("Eli si e' fermata...", "Ha sentito qualcosa?")
FRASI_ELISA_TI_VEDE = ("Eli ti ha visto!", "Sta arrivando: vuole qualcosa da te.")
# Quando Eli non ti trova ti cerca chiamandoti. Ogni voce: (parola nel fumetto, due righe del messaggio)
FRASI_ELISA_CERCA = (
    ("Ale?", ("Ale? Dove sei?", "Eli ti sta cercando...")),
    ("Ale...?", ("Ale... dove ti sei nascosto?", "Resta fermo e in silenzio.")),
    ("Dove sei?", ("Amore, sei qui?", "Eli guarda dietro i mobili.")),
    ("Aleee?", ("Aleee? Rispondimi!", "Non fare rumore...")),
)
FRASI_PANCIA_PRIMA = ("Strizzone di pancia!", "Meglio trovare un bagno...")
FRASI_PANCIA = (
    ("Uhhh... un altro strizzone!", "Il bagno, presto!"),
    ("La pancia brontola...", "Cerca il water!"),
    ("Ngh... non resisto molto!", "Dov'e' il bagno?"),
)
FRASI_BAGNO_INIZIO = ("Ale si siede sulla tazza...", "Non ti alzi finche' non hai finito!")
FRASI_BAGNO_FINE = ("Ahhh... che sollievo!", "Come nuovo.")
FRASI_ELISA_BAGNO = ("Eli ti ha beccato sulla tazza!", "Che imbarazzo...")
FRASI_PRIMA_IL_BAGNO = ("Prima il bagno!", "Cosi' non riesci proprio a dormire.")
FRASI_RICHIESTA_ESAUDITA_ELI = (
    ("Grazie amore!", "Sei sempre il mio aiuto."),
    ("Che bello avere te!", "Ti amo. Tutto qua."),
    ("Mi hai salvata!", "Che farei senza di te?"),
)
FRASI_RICHIESTA_ESAUDITA_GATTO = (
    ("Tamiyo fa le fusa...", "Sei il suo preferito."),
    ("Tamiyo e' felice!", "Prrr prrr prrr..."),
)
FRASI_ELISA_DELUSA = ("Uffa, Ale! Non mi ascolti mai!", "Eli e' delusa... (perdi un'ora di sonno)")
FRASI_GATTO_OFFESO = ("Tamiyo ti ignora, offesa.", "Se ne va con la coda alta.")
FRASI_STRESS_AL_LIMITE = ("Troppe cose da fare!", "Ale e' esausto... (perdi un'ora di sonno)")
FRASI_MANI_OCCUPATE = ("Hai le mani occupate!", "Consegna prima quello che porti.")
FRASI_GATTO_BLOCCA = (
    "Tamiyo vuole una crocchetta!",
    "Premi SPAZIO per dargliela.",
)
FRASI_GATTO_SENZA = (
    "Tamiyo ti fissa... e non hai crocchette!",
    "Aspetta che si stufi.",
)
FRASI_GATTO_CONTENTO = (
    "Tamiyo mangia felice.",
    "Poi va a caccia di insetti in giardino.",
)
FRASI_SCATOLETTA = (
    "Tamiyo adora la scatoletta!",
    "Va a caccia di insetti in giardino per un bel po'.",
)
FRASI_TUTTE_RACCOLTE = (
    "Crocchette finite!",
    "Corri al letto: Ale sta per volare!",
)
TITOLO_SCHERMATA_VITTORIA = "BUONANOTTE!"
FRASI_VITTORIA = (
    "Ti amo, tutto qua!",
)
TITOLO_SCHERMATA_VITE = "NOTTE INSONNE"
FRASI_VITE_FINITE = (
    "Eli: \"Sai che ti amo vero?\"",
    "Ale: \"No, non lo so.\"",
)
TITOLO_SCHERMATA_SOLE = "E' SORTO IL SOLE"
FRASI_SOLE = (
    "Sono le 6:00 e hai ancora crocchette da raccogliere.",
    "Tamiyo vuole la colazione!",
)


# -----------------------------------------------------------------------------
#  Musica (generata dal codice: niente file audio)
# -----------------------------------------------------------------------------
# Ogni brano ha una melodia e un basso, scritti come note ("A4", "G#5") o "."
# per una pausa. Ogni battuta ha 8 note (crome). Puoi cambiare note e velocita'
# (bpm) per comporre la tua musica.
VOLUME_MUSICA = 0.5

_ACCORDI_NOTTE = (("A2", "E3"), ("A2", "E3"), ("F2", "C3"), ("F2", "C3"),
                  ("G2", "D3"), ("G2", "D3"), ("E2", "B2"), ("E2", "B2"))
_ACCORDI_TITOLO = (("C3", "G3"), ("A2", "E3"), ("F2", "C3"), ("G2", "D3")) * 2

_MELODIA_NOTTE = (
    "E5 . C5 . A4 . C5 .  E5 . A5 . G5 . E5 .  "
    "F5 . C5 . A4 . C5 .  F5 . A5 . G5 . F5 .  "
    "D5 . B4 . G4 . B4 .  D5 . G5 . F5 . D5 .  "
    "E5 . G5 . B5 . G5 .  E5 G#5 B5 G#5 E5 . . ."
)
_MELODIA_TITOLO = (
    "C5 E5 G5 E5 C5 E5 G5 .  A4 C5 E5 C5 A4 C5 E5 .  "
    "F4 A4 C5 A4 F4 A4 C5 .  G4 B4 D5 B4 G4 B4 D5 .  "
    "E5 G5 C6 G5 E5 G5 C6 .  C5 E5 A5 E5 C5 E5 A5 .  "
    "A4 C5 F5 C5 A4 C5 F5 .  G4 B4 D5 G5 D5 B4 G4 ."
)


def _basso(accordi, figura):
    """figura: 8 simboli, 'r' = nota base, 'q' = quinta, '.' = pausa."""
    note = []
    for radice, quinta in accordi:
        note.extend({"r": radice, "q": quinta}.get(s, ".") for s in figura)
    return note


_ACCORDI_SCOOTER = (("D2", "A2"), ("D2", "A2"), ("A#1", "F2"), ("C2", "G2"),
                    ("D2", "A2"), ("D2", "A2"), ("G1", "D2"), ("A1", "E2"))
_MELODIA_SCOOTER = (
    "D5 . F5 . G5 . A5 .  D5 . F5 . G5 . A5 .  A#4 . D5 . F5 . G5 .  C5 . E5 . G5 . A5 .  "
    "D5 . F5 . G5 . A5 .  C6 A5 G5 F5 D5 . . .  G4 . A#4 . D5 . F5 .  A4 C#5 E5 A5 G5 F5 E5 ."
)


MUSICHE = {
    "titolo": {"bpm": 126, "melodia": _MELODIA_TITOLO.split(), "duty": 0.5,
               "basso": _basso(_ACCORDI_TITOLO, "r.q.r.q.")},
    "notte": {"bpm": 132, "melodia": _MELODIA_NOTTE.split(), "duty": 0.25,
              "basso": _basso(_ACCORDI_NOTTE, "r.r.q.r.")},
    "scooter": {"bpm": 156, "melodia": _MELODIA_SCOOTER.split(), "duty": 0.25,
                "basso": _basso(_ACCORDI_SCOOTER, "rrrrqqrr")},
    "sveglia": {"bpm": 170, "melodia": _MELODIA_NOTTE.split(), "duty": 0.125,
                "basso": _basso(_ACCORDI_NOTTE, "rrrrqqrr")},
}

_SEMITONI = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def frequenza_nota(nome):
    """'A4' -> 440 Hz. Una pausa ('.') vale 0."""
    if not nome or nome == ".":
        return 0.0
    resto = nome[1:]
    alterazione = 0
    if resto.startswith("#"):
        alterazione, resto = 1, resto[1:]
    elif resto.startswith("b"):
        alterazione, resto = -1, resto[1:]
    try:
        semitoni = _SEMITONI[nome[0]] + alterazione + (int(resto) - 4) * 12 - 9
    except (KeyError, ValueError):
        raise ValueError(f"Nota musicale non valida: '{nome}'. Usa per esempio A4, C#5, G3 oppure '.' per una pausa.")
    return 440.0 * 2 ** (semitoni / 12)


# -----------------------------------------------------------------------------
#  Suoni (onde quadre, stile 8 bit: nessun file da installare)
# -----------------------------------------------------------------------------
class Suoni:
    FREQUENZA = 44100
    CANALI = 2
    BUFFER = 4096 if sys.platform == "emscripten" else 1024      # piu' grande = niente scricchiolii se il gioco rallenta

    NOTE = {
        "croc_a": [(660, 35)],
        "croc_b": [(880, 35)],
        "dai": [(600, 50), (900, 80)],
        "scatoletta": [(523, 60), (784, 60), (1047, 110)],
        "gatto": [(900, 70), (700, 70), (900, 70), (0, 30), (1100, 90)],
        "sveglia": [(600, 90), (450, 90), (300, 200)],
        "allerta": [(1200, 60), (0, 40), (1200, 60)],
        "tutte": [(784, 80), (988, 80), (1175, 160)],
        "vittoria": [(523, 110), (659, 110), (784, 110), (1047, 300)],
        "sole": [(500, 200), (400, 200), (300, 200), (200, 400)],
        "magia": [(1047, 35), (1319, 35), (1568, 35), (2093, 35), (2637, 35), (3136, 35), (2637, 35),
                  (3136, 40), (3951, 110)],
        "poof": [(1400, 25), (900, 30), (600, 40), (380, 55), (240, 80)],
        "ahah": [(520, 55), (0, 35), (470, 55), (0, 35), (540, 60), (0, 35), (490, 60), (0, 35), (570, 95)],
    }

    def __init__(self, attivi):
        self.suoni = {}
        self.tracce = {}
        self.canale = None
        self.musica_voluta = None
        self.attivo = False
        self._alterna = False
        self._motore = self._motorino = None
        self._motore_acceso = False
        self._motore_tipo = "aereo"
        if not attivi:
            return
        try:
            pygame.mixer.quit()
            pygame.mixer.init(self.FREQUENZA, -16, self.CANALI, self.BUFFER, allowedchanges=0)
            if pygame.mixer.get_init() != (self.FREQUENZA, -16, self.CANALI):
                return
            for nome, note in self.NOTE.items():
                self.suoni[nome] = self._carica_sfx(nome) or self._crea(note)
            pygame.mixer.set_reserved(2)
            self.canale = pygame.mixer.Channel(0)
            self._carica_traccia("titolo")                      # le altre arrivano una alla volta, a gioco avviato
            self.attivo = True
            try:
                self._motore = self._carica_sfx("motore_aereo") or self._crea_motore()
                self._motorino = self._carica_sfx("motore_scooter") or self._crea_motore(base=100, colpi=30, rumore=0.35, volume=0.12)
            except (pygame.error, TypeError, ValueError) as errore:
                print(f"[Motore dell'aereo non disponibile: {errore}]")
        except (pygame.error, TypeError, ValueError) as errore:
            print(f"[Audio disattivato: {errore}]")

    def _voce(self, note, passo, duty, ampiezza, triangolare=False):
        """Trasforma una lista di note in campioni audio (onda a impulsi o triangolare)."""
        rate = self.FREQUENZA
        n_suona = int(passo * 0.7)
        campioni = []
        for nota in note:
            f = frequenza_nota(nota)
            if f <= 0:
                campioni.extend([0] * passo)
                continue
            if triangolare:
                blocco = [int((4 * abs((i * f % rate) / rate - 0.5) - 1) * ampiezza) for i in range(n_suona)]
            else:
                soglia = duty * rate
                blocco = [ampiezza if (i * f) % rate < soglia else -ampiezza for i in range(n_suona)]
            campioni.extend(blocco)
            campioni.extend([0] * (passo - n_suona))
        return campioni

    def _stereo(self, mono):
        """Da un array mono (array 'h') a un Sound stereo: stessa onda su sinistra e destra."""
        doppio = array("h", bytes(len(mono) * 4))
        doppio[0::2] = mono
        doppio[1::2] = mono
        return pygame.mixer.Sound(buffer=doppio.tobytes())

    def _carica_traccia(self, nome):
        if nome in MUSICHE and nome not in self.tracce:
            self.tracce[nome] = self._carica_brano(nome) or self._crea_brano(MUSICHE[nome])

    def precarica_una(self):
        """Carica un solo brano ancora mancante (chiamata a ogni fotogramma: l'avvio resta rapido)."""
        if self.canale is None or len(self.tracce) >= len(MUSICHE):
            return
        for nome in MUSICHE:
            if nome not in self.tracce:
                self._carica_traccia(nome)
                return

    def _carica_sfx(self, nome):
        """Effetti gia' pronti (suoni/sfx_<nome>.ogg, da strumenti/crea_musica.py): partire e' piu' veloce, soprattutto nel browser."""
        percorso = CARTELLA_SUONI / f"sfx_{nome}.ogg"
        if not percorso.is_file():
            return None
        try:
            return pygame.mixer.Sound(str(percorso))
        except pygame.error:
            return None

    def _carica_brano(self, nome):
        """La musica vera: suoni/musica_<nome>.ogg (creata da strumenti/crea_musica.py), gia' stereo e senza clic."""
        percorso = CARTELLA_SUONI / f"musica_{nome}.ogg"
        if not percorso.is_file():
            return None
        try:
            suono = pygame.mixer.Sound(str(percorso))
        except pygame.error as errore:
            print(f"[Musica {percorso.name} non leggibile: {errore}]")
            return None
        suono.set_volume(VOLUME_MUSICA)
        return suono

    def _crea_brano(self, brano):
        passo = int(self.FREQUENZA * 60 / brano["bpm"] / 2)
        melodia = self._voce(brano["melodia"], passo, brano["duty"], int(32767 * 0.10))
        basso = self._voce(brano["basso"], passo, 0.5, int(32767 * 0.12), triangolare=True)
        mix = array("h", [a + b for a, b in zip(melodia, basso)])
        suono = self._stereo(mix)
        suono.set_volume(VOLUME_MUSICA)
        return suono

    def imposta_musica(self, nome):
        """Fa partire (in loop) il brano 'nome'; None = silenzio."""
        if nome == self.musica_voluta:
            return
        self.musica_voluta = nome
        self._applica_musica()

    def _applica_musica(self):
        if self.canale is None:
            return
        self.canale.stop()
        if self.attivo:
            self._carica_traccia(self.musica_voluta)
        if self.attivo and self.musica_voluta in self.tracce:
            self.canale.play(self.tracce[self.musica_voluta], loops=-1)

    def pausa_musica(self, in_pausa):
        if self.canale is None:
            return
        if in_pausa:
            self.canale.pause()
        else:
            self.canale.unpause()

    def _crea(self, note, volume=0.18):
        ampiezza = int(32767 * volume)
        campioni = array("h")
        for freq, ms in note:
            n = int(self.FREQUENZA * ms / 1000)
            sfumo = max(1, min(n // 4, int(self.FREQUENZA * 0.004)))        # 4 ms di entrata/uscita: niente "clic"
            for i in range(n):
                if freq == 0:
                    campioni.append(0)
                else:
                    peso = min(1.0, (i + 1) / sfumo, (n - i) / sfumo)
                    campioni.append(int((ampiezza if (i * freq * 2 // self.FREQUENZA) % 2 == 0 else -ampiezza) * peso))
        return self._stereo(campioni)

    def _crea_motore(self, base=62, colpi=18, rumore=0.25, volume=0.14):
        """Il 'put put put' dell'ultraleggero (o del motorino): dente di sega a colpi, con un po' di rumore. In loop."""
        rate = self.FREQUENZA
        caso = random.Random(7)
        campioni = array("h")
        for i in range(rate // 2):
            tempo = i / rate
            dente = ((tempo * base) % 1.0) * 2 - 1
            colpo = 0.55 + 0.45 * math.sin(2 * math.pi * colpi * tempo)
            campioni.append(int(32767 * volume * (dente * colpo + caso.uniform(-rumore, rumore))))
        return self._stereo(campioni)

    def _suono_motore(self):
        return self._motorino if self._motore_tipo == "scooter" and self._motorino is not None else self._motore

    def motore(self, acceso, tipo="aereo"):
        """Accende o spegne il motore in loop: tipo 'aereo' o 'scooter'."""
        if self._motore is None or (acceso == self._motore_acceso and tipo == self._motore_tipo):
            return
        if self._motore_acceso:
            self._suono_motore().fadeout(200)
        self._motore_acceso, self._motore_tipo = acceso, tipo
        if acceso and self.attivo:
            self._suono_motore().play(loops=-1, fade_ms=150)

    def gioca(self, nome):
        if self.attivo and nome in self.suoni:
            self.suoni[nome].play()

    def crocchetta(self):
        self._alterna = not self._alterna
        self.gioca("croc_a" if self._alterna else "croc_b")

    def on_off(self):
        if self.suoni:
            self.attivo = not self.attivo
            self._applica_musica()
            if not self.attivo and self._motore is not None:
                self._suono_motore().stop()
            elif self._motore_acceso and self._motore is not None:
                self._suono_motore().play(loops=-1)
        return self.attivo





# =============================================================================
#  MOTORE DEL GIOCO (non serve toccare)
# =============================================================================
WEB = sys.platform == "emscripten"            # True quando gira dentro un browser
IMPACCHETTATO = bool(getattr(sys, "frozen", False))   # True quando e' l'.exe


def _cartella_risorse():
    """Cartella con immagini, suoni e font: quella del file, o quella temporanea dell'.exe."""
    if IMPACCHETTATO:
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent


CARTELLA = _cartella_risorse()
CARTELLA_SALVATAGGIO = Path(sys.executable).resolve().parent if IMPACCHETTATO else CARTELLA
CARTELLE_IMMAGINI = (CARTELLA / "immagini", CARTELLA)
CARTELLA_SUONI = CARTELLA / "suoni"
CARTELLA_FONT = CARTELLA / "font"
FILE_RECORD = CARTELLA_SALVATAGGIO / "record.txt"

T = 32                          # lato di una casella in pixel (i disegni sono fatti per 32)
ALTEZZA_BARRA_ALTA = 78
ALTEZZA_BARRA_BASSA = 66

NERO = (0, 0, 0)
BIANCO = (245, 245, 245)
GIALLO = (255, 221, 0)
ROSA = (255, 105, 180)
ARANCIO = (255, 150, 40)
AZZURRO = (110, 200, 240)
MARRONE = (190, 120, 50)
VERDE = (90, 200, 120)
ROSSO = (235, 70, 70)

SU, GIU, SINISTRA, DESTRA = (0, -1), (0, 1), (-1, 0), (1, 0)
DIREZIONI = (SU, GIU, SINISTRA, DESTRA)
RIGA_SPRITE = {SU: 0, SINISTRA: 1, GIU: 2, DESTRA: 3}

LUNA = (
    "..XXX..",
    ".XX....",
    "XX.....",
    "XX.....",
    "XX.....",
    ".XX....",
    "..XXX..",
)

SOLIDI = frozenset("#wqHZTASKNVFPBWYUXDMIp")
MURI = frozenset("#wq")
BASE_PAVIMENTO = {".": "legno", ":": "piastrelle", "_": "cemento", ",": "erba", "g": "pietra",
                  "x": "erba", "d": "legno", "L": "legno", "r": "legno", "E": None, "G": None}
SIMBOLI_VALIDI = SOLIDI | frozenset(BASE_PAVIMENTO)


def somma(a, b):
    return (a[0] + b[0], a[1] + b[1])


def opposto(d):
    return (-d[0], -d[1])


def distanza(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def scura(colore, f):
    return tuple(max(0, min(255, int(v * f))) for v in colore[:3])


def trova_file(nome):
    for cartella in CARTELLE_IMMAGINI:
        percorso = cartella / nome
        if percorso.is_file():
            return percorso
    return None


_AVVISATI = set()


def carica_immagine(nome):
    """Carica un PNG dalla cartella immagini. Se manca o e' rovinato ritorna None."""
    percorso = trova_file(nome)
    if percorso is None:
        if nome not in _AVVISATI:
            _AVVISATI.add(nome)
            print(f"[File {nome} non trovato nella cartella immagini: uso un disegno semplice]")
        return None
    try:
        return pygame.image.load(str(percorso)).convert_alpha()
    except (pygame.error, OSError) as errore:
        print(f"[Immagine {nome} non leggibile ({errore}): uso un disegno semplice]")
        return None


# -----------------------------------------------------------------------------
#  Il mondo: la mappa di un livello
# -----------------------------------------------------------------------------
class Mondo:
    """Legge la mappa e risponde a domande tipo 'questa casella e' libera?'."""

    def __init__(self, livello):
        righe = livello["mappa"]
        if not righe or not righe[0]:
            raise ValueError("La mappa e' vuota.")
        for n, riga in enumerate(righe, start=1):
            if len(riga) != len(righe[0]):
                raise ValueError(f"Tutte le righe della mappa devono essere lunghe uguali "
                                 f"(la riga {n} e' diversa dalla prima).")
        self.righe = tuple(righe)
        self.colonne = len(righe[0])
        self.righe_n = len(righe)
        self.start = {}
        self._leggi()
        for simbolo, nome in (("L", "il letto"), ("E", "Eli"), ("G", "Tamiyo")):
            if simbolo not in self.start:
                raise ValueError(f"Nella mappa manca il simbolo '{simbolo}' ({nome}).")
        self.bloccate = frozenset((c, r) for r, riga in enumerate(self.righe)
                                  for c, ch in enumerate(riga) if ch in SOLIDI)
        self._cache = {}
        self._pav = {}
        self.raggiungibili = self._raggiungibili_da(self.start["L"])
        for simbolo, nome in (("E", "Eli"), ("G", "Tamiyo")):
            if self.start[simbolo] not in self.raggiungibili:
                raise ValueError(f"{nome} e' chiusa tra i muri o non comunica con il letto.")
        self.gabinetti = tuple((c, r) for r, riga in enumerate(self.righe) for c, ch in enumerate(riga)
                               if ch == "Y" and any(n in self.raggiungibili for _, n in self.vicini((c, r))))
        self.scatolette = self._celle_valide(livello["scatolette"], "scatolette")
        self.crocchette = self._sparpaglia(livello["crocchette"], livello.get("seme", 1))
        if not self.crocchette:
            raise ValueError("Nella mappa non c'e' posto per nessuna crocchetta.")

    def _leggi(self):
        for r, riga in enumerate(self.righe):
            for c, ch in enumerate(riga):
                if ch not in SIMBOLI_VALIDI:
                    raise ValueError(f"Simbolo '{ch}' non valido nella mappa (riga {r + 1}, colonna {c + 1}).")
                if ch in "LEG":
                    if ch in self.start:
                        raise ValueError(f"Nella mappa il simbolo '{ch}' compare due volte: ne serve uno solo.")
                    self.start[ch] = (c, r)

    def carattere(self, cella):
        c, r = cella
        if 0 <= c < self.colonne and 0 <= r < self.righe_n:
            return self.righe[r][c]
        return "#"

    def libera(self, cella):
        c, r = cella
        return 0 <= c < self.colonne and 0 <= r < self.righe_n and cella not in self.bloccate

    def vicini(self, cella):
        """Lista di (direzione, casella) raggiungibili da questa casella."""
        trovati = []
        for d in DIREZIONI:
            n = somma(cella, d)
            if self.libera(n):
                trovati.append((d, n))
        return trovati

    def celle_libere(self):
        return [(c, r) for r in range(self.righe_n) for c in range(self.colonne)
                if (c, r) not in self.bloccate]

    def _raggiungibili_da(self, cella):
        visti = {cella}
        coda = deque([cella])
        while coda:
            cur = coda.popleft()
            for _, n in self.vicini(cur):
                if n not in visti:
                    visti.add(n)
                    coda.append(n)
        return visti

    def distanze(self, meta):
        """Passi da ogni casella fino a 'meta'. Serve a Eli per inseguire."""
        if meta in self._cache:
            return self._cache[meta]
        dist = {meta: 0}
        coda = deque([meta])
        while coda:
            cur = coda.popleft()
            for _, n in self.vicini(cur):
                if n not in dist:
                    dist[n] = dist[cur] + 1
                    coda.append(n)
        self._cache[meta] = dist
        return dist

    def _celle_valide(self, celle, nome):
        validi = []
        for cella in celle:
            if cella not in self.raggiungibili or self.carattere(cella) in "dLEG":
                raise ValueError(f"In '{nome}' la casella {tuple(cella)} non e' un pavimento raggiungibile.")
            validi.append(tuple(cella))
        return tuple(validi)

    def _sparpaglia(self, quante, seme):
        """Sparge le crocchette il piu' possibile uniformi su tutto il livello."""
        lontane = (self.start["E"], self.start["G"])
        candidate = [c for c in sorted(self.raggiungibili)
                     if self.carattere(c) not in "dLEG" and c not in self.scatolette
                     and all(abs(c[0] - e[0]) + abs(c[1] - e[1]) >= 3 for e in lontane)
                     and abs(c[0] - self.start["L"][0]) + abs(c[1] - self.start["L"][1]) >= 2]
        if not candidate:
            return frozenset()
        rng = random.Random(seme)
        scelte = [rng.choice(candidate)]
        dmin = {c: (c[0] - scelte[0][0]) ** 2 + (c[1] - scelte[0][1]) ** 2 for c in candidate}
        while len(scelte) < min(quante, len(candidate)):
            massimo = max(dmin.values())
            migliori = [c for c, d in dmin.items() if d >= massimo * 0.8 and d > 0]
            if not migliori:
                break
            nuova = rng.choice(sorted(migliori))
            scelte.append(nuova)
            for c in candidate:
                d = (c[0] - nuova[0]) ** 2 + (c[1] - nuova[1]) ** 2
                if d < dmin[c]:
                    dmin[c] = d
        return frozenset(scelte)

    def tipo_pavimento(self, cella):
        """Che pavimento c'e' (anche sotto i mobili): legno, piastrelle, cemento, erba, pietra."""
        if cella in self._pav:
            return self._pav[cella]
        trovato = "legno"
        visti = {cella}
        coda = deque([(cella, 0)])
        while coda:
            cur, d = coda.popleft()
            tipo = BASE_PAVIMENTO.get(self.carattere(cur))
            if tipo:
                trovato = tipo
                break
            if d >= 4:
                continue
            for dd in DIREZIONI:
                n = somma(cur, dd)
                if n not in visti:
                    visti.add(n)
                    coda.append((n, d + 1))
        self._pav[cella] = trovato
        return trovato

    def linea_libera(self, a, b):
        """True se tra le caselle a e b non ci sono muri o mobili in mezzo (vista di Eli)."""
        (ax, ay), (bx, by) = a, b
        passi = max(2, int(math.hypot(bx - ax, by - ay) * 4))
        for i in range(1, passi):
            t = i / passi
            cella = (int(math.floor(ax + (bx - ax) * t + 0.5)), int(math.floor(ay + (by - ay) * t + 0.5)))
            if cella != a and cella != b and cella in self.bloccate:
                return False
        return True


# -----------------------------------------------------------------------------
#  Disegno del mondo: pavimenti, pareti e mobili (in stile pixel art 3/4)
# -----------------------------------------------------------------------------
def _rng(c, r, k=0):
    return random.Random(c * 7919 + r * 104729 + k * 1299709)


def _sup(w=T, h=T, alpha=False):
    return pygame.Surface((w, h), pygame.SRCALPHA) if alpha else pygame.Surface((w, h))


def pav_legno(c, r):
    s = _sup()
    rng = _rng(c, r, 1)
    tinte = ((188, 130, 78), (178, 120, 70), (196, 140, 88))
    for i in range(4):
        y = i * 8
        pygame.draw.rect(s, tinte[(c + r * 2 + i) % 3], (0, y, T, 8))
        pygame.draw.line(s, (122, 78, 44), (0, y + 7), (T, y + 7))
        sx = rng.randint(4, 27)
        pygame.draw.line(s, (122, 78, 44), (sx, y), (sx, y + 6))
        for _ in range(3):
            s.set_at((rng.randint(0, 31), y + rng.randint(1, 5)), (162, 106, 60))
    return s


def pav_piastrelle(c, r):
    s = _sup()
    for bx in (0, 1):
        for by in (0, 1):
            col = (232, 234, 238) if (bx + by + c + r) % 2 == 0 else (212, 220, 228)
            pygame.draw.rect(s, col, (bx * 16, by * 16, 16, 16))
    for v in (0, 16):
        pygame.draw.line(s, (170, 180, 192), (v, 0), (v, T))
        pygame.draw.line(s, (170, 180, 192), (0, v), (T, v))
    return s


def pav_cemento(c, r):
    s = _sup()
    s.fill((142, 144, 152))
    rng = _rng(c, r, 3)
    for _ in range(26):
        x, y = rng.randint(0, 31), rng.randint(0, 31)
        s.set_at((x, y), rng.choice(((120, 122, 130), (158, 160, 168), (132, 134, 142))))
    pygame.draw.line(s, (104, 106, 114), (T - 1, 0), (T - 1, T))
    pygame.draw.line(s, (104, 106, 114), (0, T - 1), (T, T - 1))
    return s


def pav_erba(c, r):
    s = _sup()
    s.fill((84, 150, 72))
    rng = _rng(c, r, 4)
    for _ in range(9):
        x, y = rng.randint(1, 29), rng.randint(2, 29)
        pygame.draw.line(s, (58, 114, 52), (x, y), (x, y - 2))
        pygame.draw.line(s, (58, 114, 52), (x + 2, y), (x + 2, y - 1))
    for _ in range(6):
        s.set_at((rng.randint(0, 31), rng.randint(0, 31)), (116, 178, 94))
    return s


def pav_pietra(c, r):
    s = _sup()
    s.fill((112, 108, 102))
    rng = _rng(c, r, 5)
    for riga in range(4):
        y = riga * 8
        x = -(riga % 2) * 6
        while x < T:
            w = rng.randint(9, 13)
            tono = rng.choice(((158, 152, 142), (150, 146, 136), (164, 158, 148)))
            pygame.draw.rect(s, tono, (x + 1, y + 1, w - 2, 6), border_radius=2)
            x += w
    return s


def pav_erba_fiori(c, r):
    s = pav_erba(c, r)
    rng = _rng(c, r, 6)
    for _ in range(5):
        x, y = rng.randint(3, 27), rng.randint(5, 27)
        col = rng.choice(((250, 220, 90), (250, 250, 250), (240, 120, 160), (170, 140, 240)))
        s.set_at((x, y), col)
        s.set_at((x - 1, y), col)
        s.set_at((x + 1, y), col)
        s.set_at((x, y - 1), col)
        s.set_at((x, y + 1), col)
        s.set_at((x, y), (250, 200, 60))
    return s


def disegna_tappeto(s, n, e, so, w):
    """Tappeto rosso con bordo crema; i lati che continuano su un altro tappeto non hanno bordo."""
    rosso, scuro, crema = (150, 48, 56), (120, 34, 44), (238, 222, 182)
    x0, y0 = (0 if w else 3), (0 if n else 3)
    x1, y1 = (T if e else T - 3), (T if so else T - 3)
    pygame.draw.rect(s, scuro, (x0, y0, x1 - x0, y1 - y0))
    pygame.draw.rect(s, rosso, (x0 + (0 if w else 1), y0 + (0 if n else 1),
                                (x1 - x0) - (0 if w else 1) - (0 if e else 1),
                                (y1 - y0) - (0 if n else 1) - (0 if so else 1)))
    for i in range(0, T, 8):
        pygame.draw.line(s, scuro, (x0, y0 + i + 4), (x1 - 1, y0 + i + 4))
    if not n:
        pygame.draw.line(s, crema, (x0 + 2, y0 + 3), (x1 - 3, y0 + 3))
    if not so:
        pygame.draw.line(s, crema, (x0 + 2, y1 - 4), (x1 - 3, y1 - 4))
    if not w:
        pygame.draw.line(s, crema, (x0 + 3, y0 + 2), (x0 + 3, y1 - 3))
    if not e:
        pygame.draw.line(s, crema, (x1 - 4, y0 + 2), (x1 - 4, y1 - 3))


def disegna_porta(s, orizzontale):
    """Soglia con stipiti di legno (il pavimento e' gia' disegnato sotto)."""
    legno, chiaro = (98, 62, 36), (150, 104, 64)
    if orizzontale:
        pygame.draw.rect(s, legno, (0, 0, 5, T))
        pygame.draw.rect(s, legno, (T - 5, 0, 5, T))
        pygame.draw.line(s, chiaro, (1, 0), (1, T))
        pygame.draw.line(s, chiaro, (T - 4, 0), (T - 4, T))
        pygame.draw.rect(s, (0, 0, 0, 38), (5, 0, T - 10, T))
    else:
        pygame.draw.rect(s, legno, (0, 0, T, 5))
        pygame.draw.rect(s, legno, (0, T - 5, T, 5))
        pygame.draw.line(s, chiaro, (0, 1), (T, 1))
        pygame.draw.line(s, chiaro, (0, T - 4), (T, T - 4))
        pygame.draw.rect(s, (0, 0, 0, 38), (0, 5, T, T - 10))


def disegna_muro_alto(s, c, r):
    s.fill((72, 60, 82))
    rng = _rng(c, r, 7)
    for _ in range(10):
        s.set_at((rng.randint(0, 31), rng.randint(2, 31)), (84, 72, 96))
    pygame.draw.line(s, (112, 100, 124), (0, 0), (T, 0))
    pygame.draw.line(s, (52, 42, 62), (0, T - 1), (T, T - 1))


def disegna_muro_faccia(s, c, r, stile, colore):
    """Faccia visibile di una parete: bordo scuro in alto, parete, zoccolino."""
    if stile == "mattoni":
        s.fill(colore)
        malta = scura(colore, 1.35)
        for riga in range(0, 24, 6):
            pygame.draw.line(s, malta, (0, 6 + riga), (T, 6 + riga))
            off = 8 if (riga // 6) % 2 else 0
            for x in range(off, T, 16):
                pygame.draw.line(s, malta, (x, 6 + riga), (x, 11 + riga))
        rng = _rng(c, r, 8)
        for _ in range(14):
            s.set_at((rng.randint(0, 31), rng.randint(6, 25)), scura(colore, 0.82))
        pygame.draw.rect(s, (96, 94, 102), (0, 25, T, 7))
        pygame.draw.line(s, (130, 128, 136), (0, 25), (T, 25))
    else:
        s.fill(colore)
        for x in range(0, T, 8):
            pygame.draw.line(s, scura(colore, 0.96), (x, 6), (x, 24))
        pygame.draw.rect(s, (150, 104, 70), (0, 25, T, 7))
        pygame.draw.line(s, (186, 134, 92), (0, 25), (T, 25))
        pygame.draw.line(s, (104, 70, 46), (0, 31), (T, 31))
    pygame.draw.rect(s, (74, 62, 84), (0, 0, T, 6))
    pygame.draw.line(s, (116, 104, 128), (0, 5), (T, 5))
    pygame.draw.line(s, (46, 38, 56), (0, 6), (T, 6))


def disegna_finestra(s, c, r):
    """Finestra di notte: vetro blu scuro con stelle e luna."""
    legno = (112, 74, 44)
    pygame.draw.rect(s, legno, (6, 7, 20, 17))
    pygame.draw.rect(s, (24, 36, 84), (8, 9, 16, 12))
    rng = _rng(c, r, 9)
    for _ in range(3):
        s.set_at((rng.randint(9, 22), rng.randint(10, 19)), (220, 230, 255))
    pygame.draw.circle(s, (240, 240, 210), (19, 13), 3)
    pygame.draw.circle(s, (24, 36, 84), (20, 12), 2)
    pygame.draw.line(s, legno, (16, 9), (16, 20))
    pygame.draw.line(s, legno, (8, 15), (23, 15))
    pygame.draw.rect(s, (160, 116, 76), (4, 23, 24, 3))
    pygame.draw.line(s, (96, 62, 38), (4, 25), (27, 25))


def disegna_siepe(s, c, r):
    s.fill((38, 92, 48))
    rng = _rng(c, r, 10)
    for _ in range(14):
        x, y = rng.randint(1, 28), rng.randint(1, 28)
        pygame.draw.circle(s, rng.choice(((52, 118, 62), (66, 140, 76), (30, 78, 40))), (x, y), rng.randint(3, 5))
    for _ in range(5):
        s.set_at((rng.randint(0, 31), rng.randint(0, 31)), (150, 210, 130))
    pygame.draw.rect(s, (24, 60, 32), (0, T - 3, T, 3))


# ----- mobili disegnati a mano ------------------------------------------------
def disegna_divano(w_vic, e_vic, colore):
    s = _sup(alpha=True)
    scuro, chiaro = scura(colore, 0.72), tuple(min(255, int(v * 1.22)) for v in colore)
    x0, x1 = (0 if w_vic else 4), (T if e_vic else T - 4)
    pygame.draw.rect(s, (0, 0, 0, 60), (x0, 26, x1 - x0, 5))
    pygame.draw.rect(s, scuro, (x0, 3, x1 - x0, 13), border_radius=3)
    pygame.draw.rect(s, colore, (x0, 14, x1 - x0, 12), border_radius=2)
    pygame.draw.rect(s, chiaro, (x0 + 2, 15, x1 - x0 - 4, 3))
    pygame.draw.line(s, scuro, (T // 2, 16), (T // 2, 25))
    if not w_vic:
        pygame.draw.rect(s, scuro, (0, 8, 6, 20), border_radius=3)
        pygame.draw.rect(s, colore, (1, 9, 3, 17))
    if not e_vic:
        pygame.draw.rect(s, scuro, (T - 6, 8, 6, 20), border_radius=3)
        pygame.draw.rect(s, colore, (T - 4, 9, 3, 17))
    return s


def disegna_armadio():
    s = _sup(T, 46, alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 60), (1, 42, 30, 4))
    pygame.draw.rect(s, (84, 52, 30), (1, 1, 30, 43))
    pygame.draw.rect(s, (150, 98, 58), (2, 2, 28, 41))
    pygame.draw.rect(s, (176, 120, 72), (0, 0, 32, 5))
    pygame.draw.line(s, (84, 52, 30), (16, 6), (16, 42))
    for x in (4, 18):
        pygame.draw.rect(s, (128, 82, 48), (x, 8, 10, 32))
        pygame.draw.rect(s, (160, 108, 64), (x + 1, 9, 8, 30))
    pygame.draw.rect(s, (236, 220, 170), (13, 22, 2, 5))
    pygame.draw.rect(s, (236, 220, 170), (17, 22, 2, 5))
    return s


def disegna_water():
    s = _sup(alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 55), (6, 27, 20, 4))
    pygame.draw.rect(s, (234, 238, 244), (8, 4, 16, 9), border_radius=2)
    pygame.draw.rect(s, (160, 170, 186), (8, 4, 16, 9), width=1, border_radius=2)
    pygame.draw.rect(s, (216, 220, 228), (21, 6, 3, 2))
    pygame.draw.ellipse(s, (240, 244, 248), (7, 12, 18, 15))
    pygame.draw.ellipse(s, (160, 170, 186), (7, 12, 18, 15), 1)
    pygame.draw.ellipse(s, (200, 210, 224), (10, 14, 12, 9))
    return s


def disegna_lavandino():
    s = _sup(alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 55), (6, 28, 20, 3))
    pygame.draw.rect(s, (226, 230, 238), (12, 17, 8, 11))
    pygame.draw.ellipse(s, (240, 244, 248), (4, 8, 24, 13))
    pygame.draw.ellipse(s, (160, 170, 186), (4, 8, 24, 13), 1)
    pygame.draw.ellipse(s, (170, 196, 224), (8, 10, 16, 8))
    pygame.draw.rect(s, (190, 196, 206), (15, 4, 3, 6))
    pygame.draw.rect(s, (190, 196, 206), (12, 4, 9, 2))
    return s


def disegna_vasca(n, e, so, w):
    s = _sup(alpha=True)
    x0, x1 = (0 if w else 2), (T if e else T - 2)
    y0, y1 = (0 if n else 3), (T if so else T - 2)
    pygame.draw.rect(s, (0, 0, 0, 50), (x0, y1 - 1, x1 - x0, 3))
    pygame.draw.rect(s, (236, 240, 246), (x0, y0, x1 - x0, y1 - y0), border_radius=5)
    pygame.draw.rect(s, (160, 170, 186), (x0, y0, x1 - x0, y1 - y0), width=1, border_radius=5)
    pygame.draw.rect(s, (150, 196, 226), (x0 + (0 if w else 4), y0 + (0 if n else 4),
                                          (x1 - x0) - (0 if w else 4) - (0 if e else 4),
                                          (y1 - y0) - (0 if n else 4) - (0 if so else 4)), border_radius=3)
    return s


def disegna_mobile_tv(con_tv, colore_lampada):
    s = _sup(T, 40, alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 60), (0, 36, T, 4))
    pygame.draw.rect(s, (112, 72, 42), (0, 22, T, 16), border_radius=2)
    pygame.draw.rect(s, (150, 100, 60), (1, 23, T - 2, 4))
    pygame.draw.line(s, (84, 52, 30), (16, 28), (16, 37))
    pygame.draw.rect(s, (230, 210, 150), (7, 31, 3, 2))
    pygame.draw.rect(s, (230, 210, 150), (22, 31, 3, 2))
    if con_tv:
        pygame.draw.rect(s, (22, 24, 30), (3, 3, 26, 19), border_radius=2)
        pygame.draw.rect(s, (78, 118, 170), (5, 5, 22, 14))
        pygame.draw.rect(s, (140, 180, 220), (6, 6, 8, 3))
        pygame.draw.rect(s, (22, 24, 30), (12, 21, 8, 2))
    else:
        pygame.draw.rect(s, (96, 64, 36), (13, 20, 6, 3))
        pygame.draw.polygon(s, colore_lampada, [(9, 20), (23, 20), (19, 8), (13, 8)])
        pygame.draw.line(s, scura(colore_lampada, 0.7), (16, 8), (16, 20))
    return s


def disegna_albero():
    s = _sup(64, 84, alpha=True)
    pygame.draw.ellipse(s, (0, 0, 0, 60), (14, 74, 36, 9))
    pygame.draw.rect(s, (94, 64, 38), (28, 52, 8, 28))
    pygame.draw.rect(s, (124, 86, 52), (28, 52, 3, 28))
    for (x, y, r, col) in ((32, 22, 22, (36, 92, 52)), (18, 34, 15, (44, 106, 60)), (46, 34, 15, (44, 106, 60)),
                           (32, 36, 17, (52, 122, 66)), (26, 18, 11, (76, 150, 84)), (40, 24, 9, (76, 150, 84))):
        pygame.draw.circle(s, col, (x, y), r)
    return s


def disegna_pilastro():
    s = _sup(T, 52, alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 55), (3, 47, 26, 5))
    pygame.draw.rect(s, (160, 160, 170), (8, 6, 16, 42))
    pygame.draw.rect(s, (196, 196, 206), (8, 6, 4, 42))
    pygame.draw.rect(s, (128, 128, 140), (20, 6, 4, 42))
    pygame.draw.rect(s, (176, 176, 186), (4, 2, 24, 6))
    pygame.draw.rect(s, (176, 176, 186), (5, 44, 22, 6))
    pygame.draw.line(s, (112, 112, 124), (4, 8), (27, 8))
    return s


def disegna_pianta_riserva(c, r):
    s = _sup(alpha=True)
    pygame.draw.rect(s, (0, 0, 0, 50), (8, 27, 16, 4))
    pygame.draw.polygon(s, (60, 150, 140), [(9, 19), (23, 19), (21, 29), (11, 29)])
    for (x, y) in ((16, 6), (9, 11), (23, 11), (13, 14), (19, 14)):
        pygame.draw.ellipse(s, (70, 150, 60), (x - 4, y - 5, 8, 12))
    return s


def disegna_crocchetta():
    s = _sup(14, 11, alpha=True)
    for (x, y) in ((4, 6), (9, 5), (6, 3)):
        pygame.draw.circle(s, (26, 12, 4), (x, y), 3)                     # contorno quasi nero: stacca dal pavimento
        pygame.draw.circle(s, (74, 38, 14), (x, y), 2)                     # corpo cioccolato scuro
        s.set_at((x - 1, y - 1), (150, 92, 44))
    return s


def disegna_scatoletta():
    s = _sup(18, 18, alpha=True)
    pygame.draw.ellipse(s, (0, 0, 0, 70), (2, 14, 14, 4))
    pygame.draw.rect(s, (176, 188, 202), (3, 5, 12, 10), border_radius=2)
    pygame.draw.rect(s, (236, 90, 120), (3, 8, 12, 4))
    pygame.draw.rect(s, (255, 230, 120), (6, 9, 6, 2))
    pygame.draw.ellipse(s, (214, 224, 236), (3, 3, 12, 5))
    pygame.draw.ellipse(s, (120, 132, 148), (3, 3, 12, 5), 1)
    pygame.draw.line(s, (255, 255, 255), (5, 6), (8, 5))
    return s


class Arte:
    """Costruisce lo sfondo di un livello (pavimenti, pareti, tappeti) e l'elenco dei mobili."""

    # tessere del foglio di Kenney: (colonna, riga)
    FRIGO, LAVELLO, FORNELLI = (14, 12), (8, 12), (14, 14)
    PIANTE = ((16, 0), (17, 0))
    LIBRERIE = ((20, 17), (21, 17), (19, 17))
    PENSILI = ((0, 12), (1, 12), (2, 12))
    QUADRI = ((19, 12), (20, 12), (19, 13), (16, 12), (21, 12), (17, 12), (19, 14), (18, 12), (20, 14))
    SPECCHIO, OROLOGIO, TORCIA, STEMMA = (22, 14), (22, 11), (21, 6), (22, 8)
    LETTO, LETTINO, SCRIVANIA = (9, 6), (9, 7), (5, 5)

    def __init__(self):
        sheet = None
        percorso = trova_file(FILE_ARREDI)
        if percorso is None:
            print(f"[File {FILE_ARREDI} non trovato: uso mobili disegnati a mano]")
        else:
            try:
                sheet = pygame.image.load(str(percorso)).convert_alpha()
            except (pygame.error, OSError) as errore:
                print(f"[Arredi non leggibili ({errore}): uso mobili disegnati a mano]")
        self.sheet = sheet
        self._cache = {}

    def k(self, colonna, riga):
        """Tessera 16x16 del foglio di Kenney, ingrandita a 32x32 (None se manca il foglio)."""
        chiave = (colonna, riga)
        if chiave not in self._cache:
            img = None
            if self.sheet is not None:
                try:
                    pezzo = self.sheet.subsurface((colonna * 17, riga * 17, 16, 16)).copy()
                    img = pygame.transform.scale(pezzo, (T, T))
                except (ValueError, pygame.error):
                    img = None
            self._cache[chiave] = img
        return self._cache[chiave]

    def k_o_riserva(self, colonna, riga, colore):
        img = self.k(colonna, riga)
        if img is not None:
            return img
        s = _sup(alpha=True)
        pygame.draw.rect(s, colore, (3, 6, 26, 22), border_radius=4)
        pygame.draw.rect(s, scura(colore, 0.6), (3, 6, 26, 22), width=2, border_radius=4)
        return s

    # ---------------------------------------------------------------- costruzione
    def costruisci(self, mondo, livello):
        """Ritorna (sfondo, oggetti, luci). 'oggetti' = [(linea_dei_piedi, immagine, x, y)] da ordinare."""
        sfondo = _sup(mondo.colonne * T, mondo.righe_n * T)
        oggetti, luci = [], []
        luna = _sup(mondo.colonne * T, mondo.righe_n * T, alpha=True)
        for r in range(mondo.righe_n):
            for c in range(mondo.colonne):
                self._casella(sfondo, luna, oggetti, luci, mondo, livello, c, r)
        sfondo.blit(luna, (0, 0))
        oggetti.sort(key=lambda o: o[0])
        return sfondo, oggetti, luci

    def _stesso(self, mondo, c, r, dc, dr, insieme):
        return mondo.carattere((c + dc, r + dr)) in insieme

    def _pavimento(self, mondo, c, r):
        tipo = mondo.tipo_pavimento((c, r))
        if tipo == "piastrelle":
            return pav_piastrelle(c, r)
        if tipo == "cemento":
            return pav_cemento(c, r)
        if tipo == "erba":
            return pav_erba_fiori(c, r) if mondo.carattere((c, r)) == "x" else pav_erba(c, r)
        if tipo == "pietra":
            return pav_pietra(c, r)
        return pav_legno(c, r)

    def _casella(self, sfondo, luna, oggetti, luci, mondo, livello, c, r):
        ch = mondo.carattere((c, r))
        x, y = c * T, r * T
        if ch in MURI:
            self._muro(sfondo, luna, mondo, livello, c, r, ch, luci)
            return
        if ch == "H":
            tile = _sup()
            disegna_siepe(tile, c, r)
            sfondo.blit(tile, (x, y))
            return
        sfondo.blit(self._pavimento(mondo, c, r), (x, y))
        if ch == "r":
            tile = _sup(alpha=True)
            same = lambda dc, dr: self._stesso(mondo, c, r, dc, dr, "r")
            disegna_tappeto(tile, same(0, -1), same(1, 0), same(0, 1), same(-1, 0))
            sfondo.blit(tile, (x, y))
        elif ch == "d":
            tile = _sup(alpha=True)
            orizzontale = mondo.carattere((c - 1, r)) in MURI and mondo.carattere((c + 1, r)) in MURI
            disegna_porta(tile, orizzontale)
            sfondo.blit(tile, (x, y))
        elif ch == "L":
            self._ombra(sfondo, x, y)
            sfondo.blit(self.k_o_riserva(*self.LETTO, (200, 90, 50)), (x, y))
            luci.append((x + 16, y + 22, 56))                              # la luce del tuo letto: la meta' e' sempre in vista
        elif ch == "I":
            self._ombra(sfondo, x, y)
            sfondo.blit(self.k_o_riserva(*self.LETTINO, (80, 160, 100)), (x, y))
        elif ch in SOLIDI:
            self._mobile(sfondo, oggetti, luci, mondo, livello, c, r, ch)

    def _ombra(self, sfondo, x, y, w=T, h=6):
        ombra = _sup(w, h, alpha=True)
        ombra.fill((0, 0, 0, 55))
        sfondo.blit(ombra, (x, y + T - h + 2))

    def _muro(self, sfondo, luna, mondo, livello, c, r, ch, luci):
        sud = mondo.carattere((c, r + 1))
        faccia = sud not in MURI and sud != "H" and (r + 1) < mondo.righe_n
        tile = _sup()
        if not faccia:
            disegna_muro_alto(tile, c, r)
            sfondo.blit(tile, (c * T, r * T))
            return
        disegna_muro_faccia(tile, c, r, livello.get("muri", "intonaco"), livello.get("colore_muro", (222, 204, 172)))
        if ch == "w":
            disegna_finestra(tile, c, r)
            self._raggio_di_luna(luna, c, r)
        elif ch == "q":
            scelta = (c * 5 + r * 3) % (len(self.QUADRI) + 3)             # quadri, ma ogni tanto uno specchio, un orologio o uno stemma
            if scelta == len(self.QUADRI):
                quadro = self.k(*self.SPECCHIO)
            elif scelta == len(self.QUADRI) + 1:
                quadro = self.k(*self.OROLOGIO)
            elif scelta == len(self.QUADRI) + 2:
                quadro = self.k(*self.STEMMA)
            else:
                quadro = self.k(*self.QUADRI[scelta])
            if quadro is not None:
                tile.blit(quadro, (0, 2))
        elif ch == "#" and (c * 7 + r * 13) % 6 == 0 and mondo.carattere((c - 1, r)) not in "wqd"                 and mondo.carattere((c + 1, r)) not in "wqd":
            torcia = self.k(*self.TORCIA)                                  # una torcia al muro: scalda la stanza con una luce
            if torcia is not None:
                tile.blit(torcia, (0, 2))
                luci.append((c * T + 16, r * T + 40, 46))
        sfondo.blit(tile, (c * T, r * T))

    def _raggio_di_luna(self, luna, c, r):
        """Chiazza di luce azzurra sul pavimento sotto una finestra."""
        pts = [(c * T + 6, (r + 1) * T), (c * T + 26, (r + 1) * T), (c * T + 38, (r + 3) * T), (c * T + 2, (r + 3) * T)]
        pygame.draw.polygon(luna, (170, 200, 255, 34), pts)

    def _mobile(self, sfondo, oggetti, luci, mondo, livello, c, r, ch):
        x, y = c * T, r * T
        S = lambda dc, dr, ins: self._stesso(mondo, c, r, dc, dr, ins)
        img = None
        if ch == "T":
            cx = 1 if (S(-1, 0, "T") and S(1, 0, "T")) else (2 if S(-1, 0, "T") else (0 if S(1, 0, "T") else -1))
            cy = 1 if S(0, -1, "T") else 0
            img = self.k_o_riserva(4, 2, (190, 140, 90)) if cx < 0 else self.k_o_riserva(cx, cy, (190, 140, 90))
        elif ch == "D":
            img = self.k_o_riserva(*self.SCRIVANIA, (176, 120, 72))
        elif ch == "A":
            if S(0, -1, "TD"):
                img = self.k_o_riserva(1, 2, (170, 120, 76))
            elif S(1, 0, "TD"):
                img = self.k_o_riserva(2, 2, (170, 120, 76))
            elif S(-1, 0, "TD"):
                img = self.k_o_riserva(3, 2, (170, 120, 76))
            else:
                img = self.k_o_riserva(0, 2, (170, 120, 76))
        elif ch == "K":
            img = self.k_o_riserva(*self.PENSILI[c % 3], (176, 130, 84))
        elif ch == "N":
            img = self.k_o_riserva(*self.LAVELLO, (180, 190, 200))
        elif ch == "V":
            img = self.k_o_riserva(*self.FORNELLI, (70, 70, 76))
        elif ch == "F":
            img = self.k_o_riserva(*self.FRIGO, (200, 210, 214))
        elif ch == "P":
            img = self.k(*self.PIANTE[(c + r) % 2]) or disegna_pianta_riserva(c, r)
        elif ch == "B":
            img = self.k_o_riserva(*self.LIBRERIE[(c + r) % 3], (150, 100, 60))
        elif ch == "S":
            img = disegna_divano(S(-1, 0, "S"), S(1, 0, "S"), livello.get("divano", (150, 78, 66)))
        elif ch == "W":
            img = disegna_armadio()
        elif ch == "Y":
            img = disegna_water()
        elif ch == "X":
            img = disegna_lavandino()
        elif ch == "U":
            img = disegna_vasca(S(0, -1, "U"), S(1, 0, "U"), S(0, 1, "U"), S(-1, 0, "U"))
        elif ch == "M":
            centro = (S(-1, 0, "M") and S(1, 0, "M")) or not (S(-1, 0, "M") or S(1, 0, "M"))
            img = disegna_mobile_tv(centro, (236, 200, 110))
            if centro:
                luci.append((x + 16, y + 6, 70))
        elif ch == "Z":
            img = disegna_albero()
            oggetti.append(((r + 1) * T, img, x + 16 - 32, (r + 1) * T - 84))
            return
        elif ch == "p":
            img = disegna_pilastro()
        if img is None:
            return
        if ch not in "ZY X":
            self._ombra(sfondo, x, y, T, 5)
        oggetti.append(((r + 1) * T, img, x, (r + 1) * T - img.get_height()))


# -----------------------------------------------------------------------------
#  Personaggi che camminano (fogli di fotogrammi)
# -----------------------------------------------------------------------------
class FoglioPersonaggio:
    """Fotogrammi di camminata per le 4 direzioni (righe: su, sinistra, giu, destra)."""

    def __init__(self, frames, passo_px, ciclo_da):
        self.frames = frames
        self.passo_px = passo_px
        self.ciclo_da = ciclo_da
        self.n = len(frames[0])
        self.piede = max(f.get_bounding_rect().bottom for riga in frames for f in riga)
        self.largo = frames[0][0].get_width()

    def fotogramma(self, faccia, fermo, distanza_percorsa):
        riga = self.frames[RIGA_SPRITE.get(faccia, 2)]
        if fermo:
            return riga[0]
        passi = self.n - self.ciclo_da
        return riga[self.ciclo_da + int(distanza_percorsa / self.passo_px) % passi]


def _taglia(img, w, h, colonne, righe):
    return [[img.subsurface((i * w, r * h, w, h)).copy() for i in range(colonne)] for r in range(righe)]


def carica_foglio_lpc(nome, colore):
    img = carica_immagine(nome)
    if img is not None and img.get_width() >= 576 and img.get_height() >= 256:
        return FoglioPersonaggio(_taglia(img, 64, 64, 9, 4), 6.0, 1)
    return foglio_riserva_persona(colore)


def carica_foglio_gatto(nome):
    img = carica_immagine(nome)
    if img is not None and img.get_width() >= 160 and img.get_height() >= 128:
        return FoglioPersonaggio(_taglia(img, 40, 32, 4, 4), 6.0, 0)
    return foglio_riserva_gatto()


def foglio_riserva_persona(colore):
    """Omino semplice (testa, corpo, due gambe) usato se manca il PNG dei personaggi."""
    frames = []
    for _ in range(4):
        riga = []
        for i in range(9):
            s = pygame.Surface((64, 64), pygame.SRCALPHA)
            passo = 0 if i == 0 else int(math.sin(i / 8 * 2 * math.pi) * 5)
            pygame.draw.rect(s, scura(colore, 0.5), (24 + passo // 2, 44, 6, 12))
            pygame.draw.rect(s, scura(colore, 0.5), (34 - passo // 2, 44, 6, 12))
            pygame.draw.rect(s, colore, (22, 24, 20, 22), border_radius=4)
            pygame.draw.circle(s, (240, 200, 160), (32, 18), 9)
            riga.append(s)
        frames.append(riga)
    return FoglioPersonaggio(frames, 6.0, 1)


def foglio_riserva_gatto():
    frames = []
    for _ in range(4):
        riga = []
        for i in range(4):
            s = pygame.Surface((40, 32), pygame.SRCALPHA)
            passo = (-3, 0, 3, 0)[i]
            pygame.draw.ellipse(s, (140, 146, 158), (6, 8, 28, 14))
            pygame.draw.circle(s, (140, 146, 158), (32, 10), 7)
            for x in (10, 14, 24, 28):
                pygame.draw.rect(s, (110, 116, 128), (x + passo, 20, 3, 9))
            riga.append(s)
        frames.append(riga)
    return FoglioPersonaggio(frames, 6.0, 0)


# -----------------------------------------------------------------------------
#  Suoni veri (cartella "suoni") sopra a quelli generati dal gioco
# -----------------------------------------------------------------------------
class SuoniReali(Suoni):
    """Aggiunge passi, porte, miagolii e la risata di Tamiyo; se un file manca usa i suoni generati."""

    NOTE = dict(Suoni.NOTE, sospetta=[(700, 60), (950, 90)], glup=[(260, 70), (170, 120)],
                pop=[(900, 25), (1300, 35)],
                chiama=[(494, 110), (587, 90), (659, 190)],
                gorgoglio=[(80, 80), (110, 60), (70, 100), (95, 70), (60, 140)],
                sforzo=[(160, 90), (130, 120), (110, 150)],
                sciacquone=[(300, 300), (260, 300), (220, 400), (200, 500)])
    CAMPIONI = {
        "passo_legno": (("passo_legno_1.ogg", "passo_legno_2.ogg", "passo_legno_3.ogg", "passo_legno_4.ogg"), 0.35),
        "passo_erba": (("passo_erba_1.ogg", "passo_erba_2.ogg"), 0.30),
        "porta": (("porta.ogg",), 0.45),
        "colpo": (("colpo.ogg",), 0.6),
        "oggetto": (("oggetto.ogg",), 0.5),
        "risata": (("risata_gatto.ogg",), 0.9),
        "miagolio": (("miagolio.ogg",), 0.8),
        "gattino": (("gattino.ogg",), 0.7),
        "interruttore": (("interruttore.ogg",), 0.5),
        "acqua": (("acqua.ogg",), 0.5),
        "ahah": (("risata_ale.ogg",), 0.9),
        "canto": (("canto_scooter.ogg",), 0.9),            # facoltativo: la tua registrazione dell'inciso
    }
    ALIAS = {"gatto": "miagolio"}

    def __init__(self, attivi):
        super().__init__(attivi)
        self.campioni = {}
        self.ambiente = None
        self.ambiente_voluto = False
        if self.canale is None:
            return
        for nome, (files, volume) in self.CAMPIONI.items():
            lista = []
            for f in files:
                percorso = CARTELLA_SUONI / f
                if not percorso.is_file():
                    continue
                try:
                    suono = pygame.mixer.Sound(str(percorso))
                    suono.set_volume(volume)
                    lista.append(suono)
                except pygame.error as errore:
                    print(f"[Suono {f} non leggibile: {errore}]")
            if lista:
                self.campioni[nome] = lista
        percorso = CARTELLA_SUONI / "ambiente_notte.ogg"
        if percorso.is_file():
            try:
                self.ambiente = pygame.mixer.Sound(str(percorso))
                self.ambiente.set_volume(0.16)
            except pygame.error as errore:
                print(f"[Suono ambiente non leggibile: {errore}]")

    def gioca(self, nome):
        if not self.attivo:
            return
        if nome == "sciacquone" and "acqua" in self.campioni:
            self.campioni["acqua"][0].play(maxtime=2300, fade_ms=120)
            return
        nome = self.ALIAS.get(nome, nome)
        if nome in self.campioni:
            random.choice(self.campioni[nome]).play()
        else:
            super().gioca(nome)

    def durata(self, nome, predefinita=1.6):
        if nome in self.campioni:
            return self.campioni[nome][0].get_length()
        return predefinita

    def imposta_ambiente(self, acceso):
        if acceso == self.ambiente_voluto:
            return
        self.ambiente_voluto = acceso
        self._applica_ambiente()

    def _applica_ambiente(self):
        if self.ambiente is None or pygame.mixer.get_init() is None:
            return
        canale = pygame.mixer.Channel(1)
        canale.stop()
        if self.attivo and self.ambiente_voluto:
            canale.play(self.ambiente, loops=-1)

    def on_off(self):
        stato = super().on_off()
        self._applica_ambiente()
        return stato

    def pausa_musica(self, in_pausa):
        super().pausa_musica(in_pausa)
        if self.ambiente is not None and pygame.mixer.get_init() is not None:
            canale = pygame.mixer.Channel(1)
            if in_pausa:
                canale.pause()
            else:
                canale.unpause()


# -----------------------------------------------------------------------------
#  Personaggi
# -----------------------------------------------------------------------------
class Ale:
    """Ale cammina liberamente (non a caselle) ed e' fermato da muri e mobili."""

    def __init__(self, x, y):
        self.partenza = (x, y)
        self.reset()

    def reset(self):
        self.x, self.y = self.partenza
        self.faccia = GIU
        self.fermo = True
        self.distanza = 0.0

    @property
    def cella(self):
        return (int(self.x // T), int((self.y - 6) // T))

    def _libero(self, mondo, x, y):
        for px, py in ((x - 7, y - 8), (x + 7, y - 8), (x - 7, y - 1), (x + 7, y - 1)):
            if not mondo.libera((int(px // T), int(py // T))):
                return False
        return True

    def muovi(self, dt, vx, vy, mondo, velocita):
        """Ritorna i pixel percorsi in questo istante."""
        self.fermo = not (vx or vy)
        if self.fermo:
            return 0.0
        if vx and vy:
            vx, vy = vx * 0.7071, vy * 0.7071
        px, py = self.x, self.y
        nx = self.x + vx * velocita * dt
        if self._libero(mondo, nx, self.y):
            self.x = nx
        ny = self.y + vy * velocita * dt
        if self._libero(mondo, self.x, ny):
            self.y = ny
        fatto = distanza((px, py), (self.x, self.y))
        if vx:
            self.faccia = DESTRA if vx > 0 else SINISTRA
        elif vy:
            self.faccia = GIU if vy > 0 else SU
        self.fermo = fatto < 0.01
        self.distanza += fatto
        return fatto


class Personaggio:
    """Eli e Tamiyo: si muovono di casella in casella in modo fluido."""

    def __init__(self, cella, velocita_px):
        self.partenza = cella
        self.velocita = velocita_px / T
        self.reset()

    def reset(self):
        self.cella = self.partenza
        self.verso = None
        self.progresso = 0.0
        self.dir = (0, 0)
        self.faccia = GIU
        self.distanza = 0.0
        self.fermo = True

    def imposta_velocita_px(self, velocita_px):
        self.velocita = velocita_px / T

    def piedi(self):
        x, y = self.cella
        if self.verso is not None:
            x += (self.verso[0] - self.cella[0]) * self.progresso
            y += (self.verso[1] - self.cella[1]) * self.progresso
        return ((x + 0.5) * T, (y + 0.5) * T + 11)

    def cella_attuale(self):
        if self.verso is not None and self.progresso >= 0.5:
            return self.verso
        return self.cella

    def scegli(self, mondo):
        raise NotImplementedError

    def muovi(self, dt, mondo):
        restante = self.velocita * dt
        mosso = False
        while restante > 1e-9:
            if self.verso is None:
                d = self.scegli(mondo)
                if d is None or not mondo.libera(somma(self.cella, d)):
                    break
                self.dir = d
                self.verso = somma(self.cella, d)
                self.progresso = 0.0
            passo = min(restante, 1.0 - self.progresso)
            self.progresso += passo
            restante -= passo
            mosso = True
            self.distanza += passo * T
            if self.progresso >= 1.0 - 1e-9:
                self.cella = self.verso
                self.verso = None
                self.progresso = 0.0
        self.fermo = not mosso
        if mosso and self.dir != (0, 0):
            self.faccia = self.dir

    def opzioni(self, mondo):
        opz = mondo.vicini(self.cella)
        if len(opz) > 1 and self.dir != (0, 0):
            senza_indietro = [o for o in opz if o[0] != opposto(self.dir)]
            opz = senza_indietro or opz
        return opz

    def verso_la_meta(self, mondo, opz, meta):
        dist = mondo.distanze(meta)
        migliore = min(dist.get(c, 10 ** 6) for _, c in opz)
        return random.choice([d for d, c in opz if dist.get(c, 10 ** 6) == migliore])


class Elisa(Personaggio):
    def __init__(self, cella):
        self.meta = cella
        self.errore = 0.0
        self.sosta = 0.0
        super().__init__(cella, VELOCITA_ELISA_GIRO)

    def reset(self):
        super().reset()
        self.sosta = 0.0
        self.meta = self.partenza

    def scegli(self, mondo):
        opz = self.opzioni(mondo)
        if not opz:
            return None
        if random.random() < self.errore:
            return random.choice(opz)[0]
        return self.verso_la_meta(mondo, opz, self.meta)


class Gatto(Personaggio):
    def __init__(self, cella):
        self.bersaglio = cella
        self.curiosita = 0.35
        super().__init__(cella, VELOCITA_GATTO)

    def scegli(self, mondo):
        opz = self.opzioni(mondo)
        if not opz:
            return None
        if random.random() < self.curiosita:
            return self.verso_la_meta(mondo, opz, self.bersaglio)
        return random.choice(opz)[0]


# -----------------------------------------------------------------------------
#  Effetti (particelle, testi che volano)
# -----------------------------------------------------------------------------
def disegna_cuore(colore, scala=1):
    s = pygame.Surface((9 * scala, 8 * scala), pygame.SRCALPHA)
    for (x, y) in ((2, 2), (6, 2)):
        pygame.draw.circle(s, colore, (x * scala, y * scala + scala), 2 * scala)
    pygame.draw.polygon(s, colore, [(0, 3 * scala), (9 * scala, 3 * scala), (4 * scala + scala // 2, 8 * scala)])
    return s


class Effetti:
    def __init__(self):
        self.lista = []
        self.cuore_rosa = disegna_cuore((255, 110, 170))
        self.goccia_img = pygame.Surface((9, 12), pygame.SRCALPHA)
        disegna_goccia(self.goccia_img, 4.5, 4, 1.2)

    def testo(self, x, y, img, vita=0.9):
        self.lista.append({"k": "img", "x": x, "y": y, "vx": 0, "vy": -34, "t": 0.0, "d": vita, "img": img})

    def scintille(self, x, y, colore, n=7):
        for _ in range(n):
            a = random.uniform(0, 2 * math.pi)
            v = random.uniform(30, 80)
            self.lista.append({"k": "punto", "x": x, "y": y, "vx": math.cos(a) * v, "vy": math.sin(a) * v - 20,
                               "t": 0.0, "d": random.uniform(0.3, 0.55), "col": colore})

    def cuori(self, x, y, n=8):
        for _ in range(n):
            self.lista.append({"k": "img", "x": x + random.uniform(-10, 10), "y": y + random.uniform(-6, 6),
                               "vx": random.uniform(-30, 30), "vy": random.uniform(-80, -40), "t": 0.0,
                               "d": random.uniform(0.7, 1.2), "img": self.cuore_rosa})

    def sudore(self, x, y):
        self.lista.append({"k": "img", "x": x, "y": y, "vx": random.uniform(-8, 8), "vy": 22, "t": 0.0,
                           "d": 0.8, "img": self.goccia_img})

    def polvere(self, x, y):
        self.lista.append({"k": "polvere", "x": x + random.uniform(-3, 3), "y": y, "vx": random.uniform(-6, 6),
                           "vy": -8, "t": 0.0, "d": 0.35, "col": (206, 190, 160)})

    def aggiorna(self, dt):
        vive = []
        for p in self.lista:
            p["t"] += dt
            if p["t"] < p["d"]:
                p["x"] += p["vx"] * dt
                p["y"] += p["vy"] * dt
                if p["k"] == "punto":
                    p["vy"] += 160 * dt
                vive.append(p)
        self.lista = vive

    def disegna(self, s):
        for p in self.lista:
            alfa = max(0.0, 1.0 - p["t"] / p["d"])
            if p["k"] == "img":
                img = p["img"]
                img.set_alpha(int(255 * min(1.0, alfa * 1.6)))
                s.blit(img, img.get_rect(center=(int(p["x"]), int(p["y"]))))
                img.set_alpha(255)
            elif p["k"] == "punto":
                pygame.draw.rect(s, p["col"], (int(p["x"]), int(p["y"]), 2, 2))
            elif p["k"] == "polvere":
                r = 2 + int((1 - alfa) * 4)
                macchia = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
                pygame.draw.circle(macchia, p["col"] + (int(110 * alfa),), (r, r), r)
                s.blit(macchia, (int(p["x"]) - r, int(p["y"]) - r))


# -----------------------------------------------------------------------------
#  Scena iniziale: Ale preoccupato, Tamiyo che ride, Eli che sorride
# -----------------------------------------------------------------------------
def disegna_goccia(s, x, y, scala):
    """Goccia di sudore azzurra (punta in alto)."""
    pygame.draw.circle(s, (150, 210, 255), (int(x), int(y + 2.5 * scala)), int(2.6 * scala))
    pygame.draw.polygon(s, (150, 210, 255), [(x - 2.4 * scala, y + 2 * scala), (x + 2.4 * scala, y + 2 * scala),
                                              (x, y - 3 * scala)])
    pygame.draw.circle(s, (235, 248, 255), (int(x - 0.9 * scala), int(y + 2 * scala)), max(1, int(0.8 * scala)))


def disegna_zampina(scala):
    """Zampina di gatto vista da davanti (la usa Tamiyo per coprirsi la bocca mentre ride)."""
    w, h = 24, 28
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    pelo, chiaro, scuro, cuscinetto = (152, 156, 168), (190, 194, 204), (36, 38, 50), (226, 150, 158)
    pygame.draw.ellipse(s, scuro, (3, 12, 18, 18))
    pygame.draw.ellipse(s, pelo, (4, 13, 16, 17))
    for (x, y) in ((6, 9), (12, 7), (18, 9)):
        pygame.draw.circle(s, scuro, (x, y), 4)
        pygame.draw.circle(s, pelo, (x, y), 3)
        pygame.draw.circle(s, chiaro, (x - 1, y - 1), 1)
    pygame.draw.ellipse(s, cuscinetto, (8, 15, 9, 7))
    for (x, y) in ((8, 11), (12, 9), (16, 11)):
        s.set_at((x, y + 1), cuscinetto)
    return pygame.transform.scale(s, (int(w * scala), int(h * scala)))


class Intro:
    """Animazione della schermata iniziale. Dopo la risata di Tamiyo si ripete ogni tanto."""

    PERIODO = 11.0
    INIZIO_RISATA = 1.7

    def __init__(self, suoni, f_titolo, f_testo, f_piccolo, f_bubble):
        self.suoni = suoni
        self.f_titolo, self.f_testo, self.f_piccolo, self.f_bubble = f_titolo, f_testo, f_piccolo, f_bubble
        self.lato = {"ale": 288, "eli": 216, "tamiyo": 216}
        self.img = {}
        for nome, lato in self.lato.items():
            img = carica_immagine(f"intro/{nome}.png")
            if img is not None and img.get_size() != (lato, lato):
                img = pygame.transform.smoothscale(img, (lato, lato))
            self.img[nome] = img
        self.durata_risata = suoni.durata("risata", 1.6)
        self.zampa = {}
        self.t = 0.0
        self.ciclo = -1
        self.glup_fatto = self.risata_fatta = False
        self.stelle = [(random.Random(i).randint(8, 760), random.Random(i * 7).randint(6, 330), i * 0.7) for i in range(46)]
        self.sfondo = None

    def riavvia(self):
        self.t = 0.0
        self.ciclo = -1

    def aggiorna(self, dt):
        self.t += dt
        ciclo = int(self.t // self.PERIODO)
        if ciclo != self.ciclo:
            self.ciclo = ciclo
            self.glup_fatto = self.risata_fatta = False
        fase = self.t % self.PERIODO
        if not self.glup_fatto and fase >= 0.9:
            self.glup_fatto = True
            self.suoni.gioca("glup")
        if not self.risata_fatta and fase >= self.INIZIO_RISATA:
            self.risata_fatta = True
            self.suoni.gioca("risata")

    # ------------------------------------------------------------------ disegno
    def _sfondo(self, w, h):
        if self.sfondo is None or self.sfondo.get_size() != (w, h):
            s = pygame.Surface((w, h))
            for y in range(h):
                f = y / h
                pygame.draw.line(s, (int(14 + 26 * f), int(16 + 28 * f), int(44 + 52 * f)), (0, y), (w, y))
            pygame.draw.rect(s, (46, 34, 56), (0, h - 70, w, 70))
            pygame.draw.rect(s, (30, 22, 40), (0, h - 70, w, 5))
            self.sfondo = s
        return self.sfondo

    def _bubble(self, s, testo, centro, pop=1.0, inclina=0):
        img = self.f_bubble.render(testo, True, (20, 20, 30))
        w, h = img.get_width() + 22, img.get_height() + 14
        fondo = pygame.Surface((w, h + 12), pygame.SRCALPHA)
        pygame.draw.rect(fondo, (250, 250, 252), (0, 0, w, h), border_radius=10)
        pygame.draw.rect(fondo, (20, 20, 30), (0, 0, w, h), width=3, border_radius=10)
        pygame.draw.polygon(fondo, (250, 250, 252), [(w // 2 - 7 + inclina, h - 2), (w // 2 + 7 + inclina, h - 2),
                                                      (w // 2 + inclina, h + 11)])
        pygame.draw.lines(fondo, (20, 20, 30), False, [(w // 2 - 7 + inclina, h - 2), (w // 2 + inclina, h + 11),
                                                       (w // 2 + 7 + inclina, h - 2)], 3)
        fondo.blit(img, (11, 7))
        if pop < 1.0:
            nuova = (max(1, int(fondo.get_width() * pop)), max(1, int(fondo.get_height() * pop)))
            fondo = pygame.transform.scale(fondo, nuova)
        s.blit(fondo, fondo.get_rect(midbottom=(centro[0], centro[1])))

    def _ritratto(self, nome, colore, pos, offset=(0, 0), angolo=0, extra=None):
        img = self.img[nome]
        if img is None:
            lato = self.lato[nome]
            img = pygame.Surface((lato, lato), pygame.SRCALPHA)
            pygame.draw.rect(img, colore, img.get_rect(), border_radius=20)
        s = img.copy()
        sc = s.get_width() / 72.0
        if extra is not None:
            extra(s, sc)
        pygame.draw.rect(s, colore, s.get_rect(), width=max(3, int(sc * 2.6)), border_radius=int(s.get_width() * 0.09))
        if angolo:
            s = pygame.transform.rotate(s, angolo)
        return s, (pos[0] + offset[0], pos[1] + offset[1])

    def disegna(self, s, record, lampeggia):
        W, H = s.get_size()
        t = self.t
        fase = t % self.PERIODO
        s.blit(self._sfondo(W, H), (0, 0))
        self._cielo(s, W, t)
        self._eli(s, W, H, t, fase)
        self._tamiyo(s, W, H, t, fase)
        self._ale(s, W, H, t, fase)
        self._testi(s, W, H, t, record, lampeggia)
        if t < 0.9:
            velo = pygame.Surface((W, H))
            velo.set_alpha(int(255 * (1 - t / 0.9)))
            s.blit(velo, (0, 0))

    def _cielo(self, s, W, t):
        for (x, y, ph) in self.stelle:
            if math.sin(t * 2.2 + ph) > -0.2:
                s.set_at((x, y), (230, 235, 255))
                if math.sin(t * 2.2 + ph) > 0.8:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        s.set_at((x + dx, y + dy), (150, 160, 200))
        pygame.draw.circle(s, (250, 246, 214), (W - 84, 76), 26)
        pygame.draw.circle(s, (30, 38, 84), (W - 72, 68), 22)

    def _eli(self, s, W, H, t, fase):
        pos = (W - 252, 150)
        dy = math.sin(t * 2.1) * 2.5
        img, p = self._ritratto("eli", ROSA, pos, (0, dy), math.sin(t * 1.3) * 1.2)
        s.blit(img, img.get_rect(center=(p[0] + 108, p[1] + 108)))
        # cuoricini che salgono ogni tanto
        for k in range(3):
            ft = (t * 0.55 + k / 3.0) % 1.0
            if t > 0.8:
                cuore = disegna_cuore((255, 110, 170), 2)
                cuore.set_alpha(int(255 * (1 - ft)))
                s.blit(cuore, (p[0] + 20 + k * 70 + math.sin(ft * 6 + k) * 8, p[1] + 30 - ft * 70))

    def _tamiyo(self, s, W, H, t, fase):
        pos = (W // 2 - 108 + 14, 170)
        lt = fase - self.INIZIO_RISATA
        ride = 0 <= lt <= self.durata_risata
        sale = 0 <= lt <= self.durata_risata + 0.35
        dy = -abs(math.sin(lt * 17)) * 7 if ride else math.sin(t * 1.7) * 1.5
        ang = math.sin(lt * 13) * 3.5 if ride else 0

        def extra(sup, sc):
            if ride:
                for (ex, ey) in ((24.5, 39.5), (46.8, 40)):
                    pygame.draw.ellipse(sup, (122, 126, 138), (int((ex - 7.5) * sc), int((ey - 4) * sc), int(15 * sc), int(8 * sc)))
                    punti = [((ex - 6) * sc, (ey + 2) * sc), ((ex - 3) * sc, (ey - 1) * sc), (ex * sc, (ey - 2.2) * sc),
                             ((ex + 3) * sc, (ey - 1) * sc), ((ex + 6) * sc, (ey + 2) * sc)]
                    pygame.draw.lines(sup, (30, 32, 44), False, punti, max(2, int(2 * sc)))
                    gocciolina = (lt * 2.4 + ex) % 1.0
                    pygame.draw.circle(sup, (170, 220, 255), (int((ex + (4 if ex > 30 else -4)) * sc), int((ey + 3 + gocciolina * 8) * sc)), max(1, int(sc)))
            if sale:
                salita = 1.0 - min(1.0, max(0.0, lt / 0.18)) if lt < 0.18 else (min(1.0, (lt - self.durata_risata) / 0.3) if lt > self.durata_risata else 0.0)
                tremolio = math.sin(lt * 40) * (1.2 if ride else 0)
                if sc not in self.zampa:
                    self.zampa[sc] = disegna_zampina(sc)
                z = self.zampa[sc]
                sup.blit(z, (int(36.7 * sc - z.get_width() / 2 + tremolio * sc), int((45 + salita * 24) * sc)))

        img, p = self._ritratto("tamiyo", ARANCIO, pos, (0, dy), ang, extra)
        s.blit(img, img.get_rect(center=(p[0] + 108, p[1] + 108)))
        if ride and lt > 0.2:
            pop = min(1.0, (lt - 0.2) / 0.18)
            ritmo = "hi hi hi hi!" if int(lt * 6) % 2 == 0 else "hi hi hi!"
            self._bubble(s, ritmo, (p[0] + 150, p[1] + 20 - abs(math.sin(lt * 12)) * 4), pop, 20)

    def _ale(self, s, W, H, t, fase):
        pos = (10, H - 300)
        agita = 1.0 + (0.6 if 0.9 <= fase <= 2.6 else 0.0)
        dx, dy = math.sin(t * 47) * 1.7 * agita, math.sin(t * 31 + 1) * 1.3 * agita
        respiro = math.sin(t * 5) * 3

        def extra(sup, sc):
            for k in range(3):
                ft = (t * 0.7 + k / 3.0) % 1.0
                x = (24 + k * 12 + math.sin(ft * 7 + k) * 2) * sc
                disegna_goccia(sup, x, (11 + ft * 36) * sc, sc * 0.9)
            ft = (t * 0.5) % 1.0
            disegna_goccia(sup, 56 * sc, (30 + ft * 26) * sc, sc * 0.8)

        img, p = self._ritratto("ale", GIALLO, pos, (dx, dy + respiro * 0.3), 0, extra)
        s.blit(img, img.get_rect(center=(p[0] + 144, p[1] + 144)))
        if 0.9 <= fase <= 2.7:
            pop = min(1.0, (fase - 0.9) / 0.2)
            self._bubble(s, "glup...", (p[0] + 190, p[1] + 14), pop, -14)

    def _testi(self, s, W, H, t, record, lampeggia):
        desl = min(1.0, t / 0.7)
        y = int(-60 + 96 * (1 - (1 - desl) ** 3))
        for riga, colore, dy in (("Non ero calcolato!..", GIALLO, 0), ("Bei tempi!", ROSA, 44)):
            img = self.f_titolo.render(riga, True, colore)
            ombra = self.f_titolo.render(riga, True, (0, 0, 0))
            r = img.get_rect(center=(W // 2, y + dy))
            s.blit(ombra, r.move(3, 3))
            s.blit(img, r)
        if getattr(self, "touch", False):
            istruzioni = ("Croce: cammina", "Pulsante: dai un crocchino a Tamiyo", "II: pausa")
        else:
            istruzioni = ("Frecce / WASD  cammina", "SPAZIO  dai una crocchetta a Tamiyo",
                          "P pausa     M suoni" + ("" if WEB else "     ESC esci"))
        carattere = getattr(self, "f_msg", self.f_piccolo)
        for i, riga in enumerate(istruzioni):
            img = carattere.render(riga, True, BIANCO)
            s.blit(img, (W - img.get_width() - 24, H - 142 + i * 24))
        if t > 2.6:
            img = self.f_testo.render(getattr(self, "invito", "PREMI INVIO"), True, GIALLO if lampeggia else (150, 132, 30))
            s.blit(img, img.get_rect(center=(W - 160, H - 34)))
        rec = getattr(self, "f_msg", self.f_piccolo).render(f"RECORD {record:06d}", True, ROSA)
        s.blit(rec, rec.get_rect(midleft=(312, H - 34)))


# -----------------------------------------------------------------------------
#  Il gioco vero e proprio
# -----------------------------------------------------------------------------
TIPI_RICHIESTA = {
    "gatto_crocchini": {"chi": "gatto", "bolla": "Miao!", "colore": GIALLO, "scheda": "TAMIYO: CROCCHINI",
                        "inizio": ("Tamiyo vuole i crocchini!", "Premi SPAZIO per dargliene uno.")},
    "gatto_coccole": {"chi": "gatto", "bolla": "Prrr?", "colore": ROSA, "scheda": "TAMIYO: COCCOLE",
                      "inizio": ("Tamiyo vuole le coccole!", "Stalle vicino e tieni premuto SPAZIO.")},
    "gatto_scatoletta": {"chi": "gatto", "bolla": "MIAAO!", "colore": AZZURRO, "scheda": "TAMIYO: SCATOLETTA",
                         "inizio": ("Tamiyo vuole una scatoletta!", "Ce ne sono in giardino: portagliela.")},
    "eli_attenzioni": {"chi": "eli", "bolla": "Ale?", "colore": ROSA, "scheda": "ELI: ATTENZIONI",
                       "inizio": ("Eli vuole un po' di attenzioni!", "Sta venendo da te: restale vicino.")},
    "eli_aiuto": {"chi": "eli", "bolla": "Aiuto?", "colore": (170, 230, 255), "scheda": "ELI: AIUTO",
                  "inizio": ("Eli ha bisogno di una mano!", "Sta venendo da te...")},
}
OGGETTI_AIUTO = (("il caricatore", (230, 230, 240), "CARICATORE"), ("un asciugamano", (120, 200, 230), "ASCIUGAMANO"),
                 ("il telecomando", (70, 70, 84), "TELECOMANDO"), ("un bicchiere d'acqua", (150, 210, 255), "ACQUA"),
                 ("il plaid", (210, 100, 100), "PLAID"), ("le chiavi", (240, 200, 70), "CHIAVI"),
                 ("gli occhiali", (160, 110, 70), "OCCHIALI"), ("il telefono", (100, 100, 130), "TELEFONO"), ("il portafoglio", (150, 92, 52), "PORTAFOGLIO"))


def disegna_oggetto_aiuto(colore, breve=None):
    """L'oggetto che Eli ti chiede di portarle: ognuno con il suo disegnino riconoscibile (se 'breve' e' noto),
    altrimenti un pacchettino colorato."""
    s = pygame.Surface((18, 18), pygame.SRCALPHA)
    pygame.draw.ellipse(s, (0, 0, 0, 70), (2, 14, 14, 4))
    N = (24, 18, 30)                                                       # contorno scuro
    if breve == "CARICATORE":
        pygame.draw.rect(s, N, (4, 3, 10, 9), border_radius=2)
        pygame.draw.rect(s, (240, 240, 248), (5, 4, 8, 7), border_radius=1)
        pygame.draw.rect(s, (200, 200, 90), (6, 1, 2, 3))
        pygame.draw.rect(s, (200, 200, 90), (10, 1, 2, 3))
        pygame.draw.line(s, N, (9, 12), (9, 16), 2)
        return s
    if breve == "ASCIUGAMANO":
        pygame.draw.rect(s, N, (2, 3, 14, 12), border_radius=2)
        pygame.draw.rect(s, (110, 205, 235), (3, 4, 12, 10), border_radius=1)
        for y in (6, 9, 12):
            pygame.draw.line(s, (255, 255, 255), (3, y), (14, y))
        return s
    if breve == "TELECOMANDO":
        pygame.draw.rect(s, N, (5, 1, 8, 15), border_radius=2)
        pygame.draw.rect(s, (60, 62, 78), (6, 2, 6, 13), border_radius=1)
        pygame.draw.rect(s, (230, 70, 70), (7, 3, 4, 2))
        for y in (7, 10, 13):
            pygame.draw.rect(s, (200, 205, 220), (7, y, 2, 2))
            pygame.draw.rect(s, (200, 205, 220), (10, y, 2, 2))
        return s
    if breve == "ACQUA":
        pygame.draw.polygon(s, N, [(3, 2), (15, 2), (13, 16), (5, 16)])
        pygame.draw.polygon(s, (150, 215, 255), [(4, 3), (14, 3), (12, 15), (6, 15)])
        pygame.draw.rect(s, (235, 248, 255), (4, 3, 10, 3))
        return s
    if breve == "PLAID":
        pygame.draw.rect(s, N, (1, 3, 16, 12), border_radius=2)
        pygame.draw.rect(s, (214, 96, 96), (2, 4, 14, 10), border_radius=1)
        for x in (6, 11):
            pygame.draw.line(s, (255, 190, 150), (x, 4), (x, 13))
        pygame.draw.line(s, (255, 190, 150), (2, 8), (15, 8))
        return s
    if breve == "CHIAVI":
        pygame.draw.circle(s, N, (6, 6), 5)
        pygame.draw.circle(s, (245, 205, 70), (6, 6), 4)
        pygame.draw.circle(s, N, (6, 6), 1)
        pygame.draw.rect(s, N, (8, 9, 3, 8))
        pygame.draw.rect(s, (245, 205, 70), (9, 9, 1, 7))
        pygame.draw.rect(s, (245, 205, 70), (10, 13, 3, 1))
        return s
    if breve == "OCCHIALI":
        pygame.draw.circle(s, N, (5, 9), 4)
        pygame.draw.circle(s, N, (13, 9), 4)
        pygame.draw.circle(s, (190, 225, 245), (5, 9), 3)
        pygame.draw.circle(s, (190, 225, 245), (13, 9), 3)
        pygame.draw.line(s, N, (8, 8), (10, 8), 2)
        pygame.draw.line(s, N, (1, 7), (0, 5))
        pygame.draw.line(s, N, (17, 7), (17, 5))
        return s
    if breve == "TELEFONO":
        pygame.draw.rect(s, N, (4, 1, 10, 16), border_radius=2)
        pygame.draw.rect(s, (120, 200, 255), (5, 3, 8, 11))
        pygame.draw.rect(s, (255, 255, 255), (6, 4, 3, 2))
        pygame.draw.circle(s, (200, 205, 220), (9, 15), 1)
        return s
    if breve == "PORTAFOGLIO":
        pygame.draw.rect(s, N, (1, 3, 16, 12), border_radius=2)
        pygame.draw.rect(s, (160, 98, 54), (2, 4, 14, 10), border_radius=1)
        pygame.draw.rect(s, (120, 70, 36), (2, 4, 14, 4))
        pygame.draw.rect(s, (245, 205, 70), (12, 8, 3, 3))
        pygame.draw.line(s, (60, 36, 18), (2, 8), (15, 8))
        return s
    pygame.draw.rect(s, scura(colore, 0.55), (2, 4, 14, 11), border_radius=2)
    pygame.draw.rect(s, colore, (3, 5, 12, 9), border_radius=2)
    pygame.draw.rect(s, (255, 255, 255), (8, 4, 2, 11))
    pygame.draw.rect(s, (255, 255, 255), (3, 8, 12, 2))
    return s


class Pennello:
    """Disegna con coordinate 'di progetto' a grande risoluzione e poi riduce l'immagine (supersampling):
    i bordi vengono lisci a qualunque dimensione dello schermo. Serve per l'aereo e il pilota del volo."""

    def __init__(self, larghezza, altezza, scala, origine_x=0.0, origine_y=0.0, ss=2):
        self.scala, self.ss = scala, ss
        self.k = scala * ss
        self.w, self.h = larghezza, altezza
        self.ox, self.oy = origine_x, origine_y
        self.sup = pygame.Surface((max(2, int(larghezza * self.k)), max(2, int(altezza * self.k))), pygame.SRCALPHA)

    def P(self, p):
        return ((p[0] + self.ox) * self.k, (p[1] + self.oy) * self.k)

    def _sp(self, sp):
        return max(1, int(round(sp * self.k)))

    def poly(self, punti, colore, bordo=None, sp=3):
        q = [self.P(p) for p in punti]
        pygame.draw.polygon(self.sup, colore, q)
        if bordo is not None:
            self.linea(list(punti) + [punti[0]], bordo, sp)

    def ell(self, x, y, w, h, colore, bordo=None, sp=3):
        r = pygame.Rect(0, 0, max(1, int(w * self.k)), max(1, int(h * self.k)))
        r.topleft = (int((x + self.ox) * self.k), int((y + self.oy) * self.k))
        if colore is not None:
            pygame.draw.ellipse(self.sup, colore, r)
        if bordo is not None:
            pygame.draw.ellipse(self.sup, bordo, r, self._sp(sp))

    def circ(self, x, y, r, colore, bordo=None, sp=3):
        cx, cy = self.P((x, y))
        pygame.draw.circle(self.sup, colore, (int(cx), int(cy)), max(1, int(r * self.k)))
        if bordo is not None:
            pygame.draw.circle(self.sup, bordo, (int(cx), int(cy)), max(1, int(r * self.k)), self._sp(sp))

    def linea(self, punti, colore, sp=3):
        """Linea spessa con giunzioni arrotondate."""
        q = [self.P(p) for p in punti]
        w = self._sp(sp)
        for a, b in zip(q, q[1:]):
            pygame.draw.line(self.sup, colore, a, b, w)
        for a in q:
            pygame.draw.circle(self.sup, colore, (int(a[0]), int(a[1])), max(1, w // 2))

    @staticmethod
    def curva(p0, p1, p2, n=14):
        """Curva di Bezier quadratica come lista di punti."""
        return [((1 - u) ** 2 * p0[0] + 2 * (1 - u) * u * p1[0] + u * u * p2[0],
                 (1 - u) ** 2 * p0[1] + 2 * (1 - u) * u * p1[1] + u * u * p2[1])
                for u in (i / n for i in range(n + 1))]

    def fine(self):
        return pygame.transform.smoothscale(self.sup, (max(1, int(self.w * self.scala)), max(1, int(self.h * self.scala))))


class Richiesta:
    """Qualcosa che Eli o Tamiyo vogliono da Ale, con la loro pazienza che scende."""

    def __init__(self, tipo, pazienza):
        info = TIPI_RICHIESTA[tipo]
        self.tipo = tipo
        self.chi = info["chi"]
        self.pazienza = self.totale = pazienza
        self.attiva = self.chi == "gatto"      # Eli diventa 'attiva' quando ti raggiunge
        self.progresso = 0.0
        self.oggetto = None
        self.breve = ""
        self.cella = None
        self.colore_oggetto = BIANCO

    @property
    def scheda(self):
        if self.oggetto:
            return f"ELI: PORTA {self.breve}"
        return TIPI_RICHIESTA[self.tipo]["scheda"]

    @property
    def bolla(self):
        return TIPI_RICHIESTA[self.tipo]["bolla"]

    @property
    def colore(self):
        return TIPI_RICHIESTA[self.tipo]["colore"]


class Gioco:
    def __init__(self, finestra, mondi):
        self.finestra = finestra
        self.mondi = mondi
        self.larghezza = mondi[0].colonne * T
        self.altezza_mondo = mondi[0].righe_n * T
        self.dimensione = (self.larghezza, ALTEZZA_BARRA_ALTA + self.altezza_mondo + ALTEZZA_BARRA_BASSA)
        self.canvas = pygame.Surface(self.dimensione, 0, 32)
        self.vista = pygame.Surface((self.larghezza, self.altezza_mondo), 0, 32)
        self.clock = pygame.time.Clock()
        self.suoni = SuoniReali(SUONI_ATTIVI)
        self._prepara_font()
        self._prepara_immagini()
        self.arte = Arte()
        self.record = self._leggi_record()
        self.effetti = Effetti()
        self.intro = Intro(self.suoni, self.f_titolo, self.f_grande, self.f_msg, self.f_bubble)
        self.ultimo_tasto = None
        self.stato = "titolo"
        self.stato_prima_pausa = "gioco"
        self.esito = None
        self.tempo_totale = 0.0
        self.punti = 0
        self.punti_inizio_livello = 0
        self.scossa = 0.0
        self.lampo = 0.0
        self.pausa_colpo = 0.0
        self.testi_cache = {}
        self.luci_cache = {}
        self.arte_livelli = {}
        self.attesa_fine = 0.0
        self.mostra_controlli = False
        self.tocchi = {}
        self.messaggio = ((), 0.0, None)
        self.coda_messaggi = []
        self.pausa_messaggi = 0.0
        self.joy = {}                                   # dito -> dove ha toccato per primo (joystick che segue il dito)
        self.cam = None                                 # centro della telecamera (zoom sul telefono)
        self.vista_visibile = None                      # parte della mappa che si vede sullo schermo (Rect)
        self._dialogo_cache = {}
        self._dialogo_pos = None
        self._dialogo_chi = None
        self._dialogo_mosso = 0.0
        self._dialogo_alfa = 255.0
        self.alfa_dialogo = 255.0
        self._dialogo_da = None
        self.rett_dialogo = None
        self._scala_vista = 1.0
        self._off_vista = (0, 0)
        self._controlli_img = None
        self.consigli = set()
        self.senza_raccolta = 0.0
        self._buio = self._crt_cache = self._velo_pannello = None
        self.volo = None                 # scena del volo (uscita dal livello o arrivo nel successivo)
        self.nuvole = None               # transizione a nuvole
        self.ale_visibile = True
        self._aereo_cache = None
        self._scooter_cache = None
        self._facce_cache = {}
        self._layout_comandi = "dentro"
        self._zone_cache = None
        self._veli = {}
        self._imposta_livello(0)
        self._avvia_livello(avvia=False)

    # ------------------------------------------------------------ preparazione
    _font_aperti = {}

    @staticmethod
    def _font(dimensione):
        """Un font tipo macchina da scrivere (incluso nel gioco); se manca ne cerca uno di sistema. Si apre una volta sola."""
        if dimensione not in Gioco._font_aperti:
            Gioco._font_aperti[dimensione] = Gioco._apri_font(dimensione)
        return Gioco._font_aperti[dimensione]

    @staticmethod
    def _apri_font(dimensione):
        ttf = CARTELLA_FONT / "Cousine-Bold.ttf"
        try:
            if ttf.is_file():
                return pygame.font.Font(str(ttf), dimensione)
        except (pygame.error, OSError):
            pass
        try:
            return pygame.font.SysFont("couriernew,consolas,lucidaconsole,monospace", dimensione, bold=True)
        except (pygame.error, OSError):
            return pygame.font.Font(None, dimensione + 6)

    def _prepara_font(self):
        self.f_titolo = self._font(40)
        self.f_finale = self._font(64)
        self.f_grande = self._font(24)
        self.f_hud = self._font(19)
        self.f_msg = self._font(16)
        self.f_bubble = self._font(22)
        self.f_piccolo = self._font(13)

    def _prepara_immagini(self):
        self.foglio_ale = carica_foglio_lpc(FILE_ALE_CAMMINATA, (240, 240, 240))
        self.foglio_eli = carica_foglio_lpc(FILE_ELISA_CAMMINATA, (80, 160, 90))
        self.foglio_gatto = carica_foglio_gatto(FILE_GATTO_CAMMINATA)
        self.ale_seduto = {chiave: self._carica_seduto(nome) for chiave, nome in
                           (("vestito", FILE_ALE_SEDUTO_VESTITO), ("nudo", FILE_ALE_SEDUTO_NUDO))}
        self._seduto_cache = {}
        self.ritratti = {}
        for chi, nome in (("ale", FILE_RITRATTO_ALE), ("eli", FILE_RITRATTO_ELISA), ("gatto", FILE_RITRATTO_GATTO)):
            img = carica_immagine(nome)
            if img is not None:
                img = pygame.transform.smoothscale(img, (48, 48))
            self.ritratti[chi] = img
        self.img_croc = disegna_crocchetta()
        self.img_scat = disegna_scatoletta()
        self.img_croc_hud = pygame.transform.scale(self.img_croc, (21, 17))
        self.img_luna = self._bitmap(LUNA, AZZURRO, 3)

    @staticmethod
    def _carica_seduto(nome):
        """La posa 'seduto su una sedia' (terzo fotogramma della riga 'giu') del foglio sit."""
        img = carica_immagine(nome)
        if img is None or img.get_width() < 192 or img.get_height() < 192:
            return None
        return img.subsurface((128, 128, 64, 64)).copy()

    def _ale_seduto(self, fase):
        """Ale sul water. fase 0 = pantaloni su, 1 = ai ginocchi, 2 = alle caviglie."""
        if fase in self._seduto_cache:
            return self._seduto_cache[fase]
        vestito, nudo = self.ale_seduto["vestito"], self.ale_seduto["nudo"]
        if vestito is None or nudo is None:
            img = self.foglio_ale.fotogramma(GIU, True, 0)
        elif fase == 0:
            img = vestito
        else:
            img = nudo.copy()
            r = nudo.get_bounding_rect()
            jeans, scuro = (58, 86, 172), (30, 50, 116)
            if fase == 1:
                y = r.top + int(r.height * 0.62)
                pygame.draw.rect(img, jeans, (r.centerx - 11, y, 22, 7), border_radius=2)
                pygame.draw.rect(img, scuro, (r.centerx - 11, y, 22, 7), width=1, border_radius=2)
            else:
                y = r.bottom - 9
                for dx in (-8, 8):
                    pygame.draw.ellipse(img, jeans, (r.centerx + dx - 6, y, 12, 7))
                    pygame.draw.ellipse(img, scuro, (r.centerx + dx - 6, y, 12, 7), 1)
        self._seduto_cache[fase] = img
        return img

    @staticmethod
    def _bitmap(righe, colore, scala):
        s = pygame.Surface((len(righe[0]) * scala, len(righe) * scala), pygame.SRCALPHA)
        for y, riga in enumerate(righe):
            for x, ch in enumerate(riga):
                if ch == "X":
                    pygame.draw.rect(s, colore, (x * scala, y * scala, scala, scala))
        return s

    def _leggi_record(self):
        try:
            if WEB:
                import platform
                return int(platform.window.localStorage.getItem("crocchette_record") or 0)
            return int(FILE_RECORD.read_text().strip())
        except (OSError, ValueError, AttributeError, TypeError, ImportError):
            return 0

    def _salva_record(self):
        try:
            if WEB:
                import platform
                platform.window.localStorage.setItem("crocchette_record", str(self.record))
            else:
                FILE_RECORD.write_text(str(self.record))
        except (OSError, AttributeError, TypeError, ImportError) as errore:
            print(f"[Non riesco a salvare il record: {errore}]")

    def _luce(self, raggio):
        """Cerchio di luce con bordo morbido (usato per la torcia di Ale e per la TV)."""
        if raggio not in self.luci_cache:
            s = pygame.Surface((raggio * 2, raggio * 2), pygame.SRCALPHA)
            s.fill((255, 255, 255, 255))
            for rad in range(raggio, 0, -2):
                alfa = int(255 * (rad / raggio) ** 1.6)
                pygame.draw.circle(s, (255, 255, 255, alfa), (raggio, raggio), rad)
            self.luci_cache[raggio] = s
        return self.luci_cache[raggio]

    def _testo_img(self, testo, colore, font=None):
        chiave = (testo, colore, id(font or self.f_hud))
        if chiave not in self.testi_cache:
            f = font or self.f_hud
            base = f.render(testo, True, colore)
            ombra = f.render(testo, True, (0, 0, 0))
            s = pygame.Surface((base.get_width() + 2, base.get_height() + 2), pygame.SRCALPHA)
            s.blit(ombra, (2, 2))
            s.blit(base, (0, 0))
            self.testi_cache[chiave] = s
        return self.testi_cache[chiave]

    # ----------------------------------------------------------------- livelli
    def _imposta_livello(self, indice):
        """Carica casa, personaggi e difficolta' del livello 'indice' (0 = primo)."""
        self.indice_livello = indice
        self.liv = LIVELLI[indice]
        self.mondo = self.mondi[indice]
        if indice not in self.arte_livelli:
            self.arte_livelli[indice] = self.arte.costruisci(self.mondo, self.liv)
        self.sfondo, self.oggetti, self.luci = self.arte_livelli[indice]
        self.ale = Ale(*self._partenza_ale())
        self.elisa = Elisa(self.mondo.start["E"])
        self.gatto = Gatto(self.mondo.start["G"])
        self.gatto.curiosita = self.liv["curiosita"]
        self.tappe = [t for t in self.liv["tappe"] if t in self.mondo.raggiungibili]
        self.notte_totale = float(self.liv["notte_secondi"])
        self.celle_giardino = [c for c in sorted(self.mondo.raggiungibili)
                               if self.mondo.tipo_pavimento(c) in ("erba", "pietra") and self.mondo.carattere(c) not in "dLEG"]

    def _partenza_ale(self):
        letto = self.mondo.start["L"]
        for d in (DESTRA, SINISTRA, GIU, SU):
            n = somma(letto, d)
            if self.mondo.libera(n):
                return ((n[0] + 0.5) * T, (n[1] + 0.5) * T + 10)
        return ((letto[0] + 0.5) * T, (letto[1] + 0.5) * T + 10)

    def _avvia_livello(self, avvia=True):
        self.vite = VITE_INIZIALI
        self.tasca = TASCA_INIZIALE
        self.tempo_notte = self.notte_totale
        self.crocchette = set(self.mondo.crocchette)
        self.scatolette = set(self.mondo.scatolette)
        self.letto_attivo = False
        self.esito = None
        self.reset_posizioni()
        self._reset_pancia()
        self._reset_richieste()
        self.dici(self.liv["intro"], 6.0, "ale")
        self.timer_stato = 2.0
        self.effetti.lista.clear()
        if avvia:
            self.stato = "pronti"

    def nuova_partita(self, avvia=True):
        """Ricomincia da capo: primo livello e zero punti."""
        self.punti = 0
        self.punti_inizio_livello = 0
        self._imposta_livello(0)
        self._avvia_livello(avvia)

    def prossimo_livello(self):
        self.punti_inizio_livello = self.punti
        self._imposta_livello(self.indice_livello + 1)
        self._avvia_livello()

    def riprova_livello(self):
        """Dopo una sconfitta si riprova lo stesso livello, con i punti che avevi all'inizio."""
        self.punti = self.punti_inizio_livello
        self._imposta_livello(self.indice_livello)
        self._avvia_livello()

    @property
    def ultimo_livello(self):
        return self.indice_livello >= len(LIVELLI) - 1

    def reset_posizioni(self):
        self.ale.reset()
        self.elisa.reset()
        self.gatto.reset()
        self.bloccato = False
        self.blocco_timer = 0.0
        self.gatto_riposo = 2.0
        self.gatto_sazio = 0.0
        self.elisa_modo = "giro"
        self.elisa_timer = random.uniform(*ELISA_GIRO_SECONDI)
        self.elisa.meta = self._nuova_tappa()
        self._velocita_elisa("giro")
        self.dist_passo = 0.0
        self.ultimo_carattere = ""
        self.ultima_vista = None
        self.chiamata_timer = 0.0
        self.chiamata_visibile = 0.0
        self.chiamata_bolla = "Ale?"
        self.seduta = None
        self.crampo_blocco = 0.0
        self.ale_visibile = True
        self._azzera_richieste()

    def _velocita_elisa(self, modo):
        if modo == "sveglia":
            self.elisa.imposta_velocita_px(VELOCITA_ELISA_SVEGLIA * self.liv["elisa_sveglia"])
        else:
            self.elisa.imposta_velocita_px(VELOCITA_ELISA_GIRO * self.liv["elisa_giro"])

    def _nuova_tappa(self):
        scelte = [t for t in self.tappe if t != self.elisa.cella] or self.tappe
        return random.choice(scelte)

    def dici(self, righe, secondi=3.0, chi=None, urgente=False):
        """Un messaggio per volta, con il tempo di leggerlo: se ce n'e' gia' uno sullo schermo i nuovi aspettano in coda
        (al massimo due: i piu' vecchi si perdono) e compaiono dopo una pausa. 'urgente' lo mostra subito."""
        righe = tuple(righe)
        if not righe:
            return
        if secondi < 90:
            secondi = max(secondi, 2.4 + 0.05 * sum(len(x) for x in righe))        # il tempo di leggerlo
        nuovo = (righe, secondi, chi)
        corrente = self.messaggio
        if secondi >= 90 or urgente or (corrente[1] <= 0 and self.pausa_messaggi <= 0 and not self.coda_messaggi):
            self.messaggio = nuovo
            self.coda_messaggi = [m for m in self.coda_messaggi if m[0] != righe]
            return
        if righe == tuple(corrente[0]) or any(m[0] == righe for m in self.coda_messaggi):
            return
        self.coda_messaggi.append(nuovo)
        del self.coda_messaggi[:-PAUSA_CODA_MAX]

    def _azzera_messaggi(self):
        self.messaggio = ((), 0.0, None)
        self.coda_messaggi = []
        self.pausa_messaggi = 0.0

    # ------------------------------------------------------------------- input
    def tasto(self, tasto):
        if tasto in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self._conferma()
        elif tasto == pygame.K_SPACE:
            if self.stato == "gioco" and self.bloccato:
                r = self._richiesta_di("gatto")
                if r is None or r.tipo == "gatto_crocchini":
                    self.dai_crocchetta()
            elif self.stato in ("titolo", "guida", "fine", "volo"):
                self._conferma()
        elif tasto == pygame.K_p:
            self._pausa()
        elif tasto == pygame.K_m:
            self.suoni.on_off()
            if self.stato == "pausa":
                self.suoni.pausa_musica(True)

    def _conferma(self):
        """INVIO / SPAZIO nelle schermate di titolo, di fine livello e durante il volo (per saltarlo)."""
        if self.nuvole is not None:
            return
        if self.stato == "titolo":
            self.stato = "guida"
            self.suoni.gioca("interruttore")
        elif self.stato == "guida":
            self.nuova_partita()
        elif self.stato == "volo":
            v = self.volo
            if v is not None and v["modo"] == "esce" and v["t"] > 2.0 and not v.get("nuvole"):
                v["nuvole"] = True
                self._avvia_nuvole(self._fine_volo)
        elif self.stato == "fine":
            if self.attesa_fine > 0:
                return
            self._avvia_nuvole(self._dopo_fine)

    def _pausa(self):
        if self.stato == "pausa":
            self.stato = self.stato_prima_pausa
            self.suoni.pausa_musica(False)
        elif self.stato in ("gioco", "pronti"):
            self.stato_prima_pausa = self.stato
            self.stato = "pausa"
            self.suoni.pausa_musica(True)

    def dai_crocchetta(self):
        if self.tasca <= 0:
            return
        self.tasca -= 1
        self.punti += PUNTI_CROCCHETTA_AL_GATTO
        self.bloccato = False
        self.gatto_riposo = GATTO_RIPOSO
        self._manda_a_caccia(GATTO_CACCIA_CROCCHINO)
        self.suoni.gioca("dai")
        self.suoni.gioca("gattino")
        px, py = self.gatto.piedi()
        self.effetti.cuori(px, py - 22, 5)
        self.effetti.testo(self.ale.x, self.ale.y - 50, self._testo_img(f"+{PUNTI_CROCCHETTA_AL_GATTO}", ROSA))
        self.dici(FRASI_GATTO_CONTENTO, 2.5, "gatto")
        r = self._richiesta_di("gatto")
        if r is not None and r.tipo == "gatto_crocchini":
            self._completa_richiesta(r)

    # ----------------------------------------------------------- aggiornamento
    def _musica_voluta(self):
        if self.stato in ("volo", "arrivo") and self.volo is not None and self.volo.get("veicolo") == "scooter":
            return "scooter"
        if self.stato in ("titolo", "guida", "volo", "arrivo"):
            return "titolo"
        if self.stato == "gioco" and self.elisa_modo == "sveglia":
            return "sveglia"
        if self.stato in ("pronti", "gioco"):
            return "notte"
        return None

    def aggiorna(self, dt):
        self.tempo_totale += dt
        self.suoni.precarica_una()
        if self.stato != "pausa":
            self.suoni.imposta_musica(self._musica_voluta())
            self.suoni.imposta_ambiente(self.stato in ("pronti", "gioco", "morte"))
        self.effetti.aggiorna(dt)
        self.scossa = max(0.0, self.scossa - dt)
        self.lampo = max(0.0, self.lampo - dt)
        if self.nuvole is not None:
            self._aggiorna_nuvole(dt)
        testo, resta, chi = self.messaggio
        if resta < 90:
            nuovo_resta = max(0.0, resta - dt)
            if resta > 0 and nuovo_resta == 0:
                self.pausa_messaggi = PAUSA_TRA_MESSAGGI
            self.messaggio = (testo, nuovo_resta, chi)
        if self.messaggio[1] <= 0:
            self.pausa_messaggi -= dt
            if self.coda_messaggi and self.pausa_messaggi <= 0:
                self.messaggio = self.coda_messaggi.pop(0)
        if self.pausa_colpo > 0:
            self.pausa_colpo -= dt
            return
        if self.stato == "titolo":
            self.intro.aggiorna(dt)
        elif self.stato == "fine":
            self.attesa_fine = max(0.0, self.attesa_fine - dt)
        elif self.stato in ("volo", "arrivo"):
            self._aggiorna_volo(dt)
        elif self.stato == "pronti":
            self.timer_stato -= dt
            if self.timer_stato <= 0:
                self.stato = "gioco"
                self.suoni.gioca("interruttore")
                if "inizio" not in self.consigli:
                    self.consigli.add("inizio")
                    primo = "Trascina il pollice a sinistra per muoverti." if self.mostra_controlli else "Cammina con le frecce (o W A S D)."
                    self.dici((primo, "Raccogli le crocchette che trovi per terra!"), 8.0, "ale")
        elif self.stato == "morte":
            self.timer_stato -= dt
            if self.timer_stato <= 0:
                self.reset_posizioni()
                self.timer_stato = 1.2
                self.stato = "pronti"
        elif self.stato == "gioco":
            self._aggiorna_gioco(dt)

    def _direzione_tasti(self):
        k = pygame.key.get_pressed()
        vx = (1 if (k[pygame.K_RIGHT] or k[pygame.K_d]) else 0) - (1 if (k[pygame.K_LEFT] or k[pygame.K_a]) else 0)
        vy = (1 if (k[pygame.K_DOWN] or k[pygame.K_s]) else 0) - (1 if (k[pygame.K_UP] or k[pygame.K_w]) else 0)
        if self.tocchi:
            tx, ty = self._direzione_tocco()
            vx, vy = vx or tx, vy or ty
        return vx, vy

    def _aggiorna_gioco(self, dt, direzione=None):
        self.tempo_notte -= dt
        self.senza_raccolta += dt
        if self.tempo_notte <= 0:
            self.tempo_notte = 0
            self._finisci("sole")
            return
        vx, vy = direzione if direzione is not None else self._direzione_tasti()
        self.avviso_bagno = max(0.0, self.avviso_bagno - dt)
        self.mani_occupate = max(0.0, self.mani_occupate - dt)
        self._aggiorna_pancia(dt)
        self._aggiorna_richieste(dt)
        if self.stato != "gioco":
            return
        if self.seduta is not None:
            self._aggiorna_seduta(dt)
        if self.bloccato or self.seduta is not None or self.crampo_blocco > 0:
            self.crampo_blocco = max(0.0, self.crampo_blocco - dt)
            self.ale.fermo = True
        else:
            rallenta = 1.0 - 0.12 * max(0.0, (self.stress - 0.5) / 0.5)
            fatto = self.ale.muovi(dt, vx, vy, self.mondo, VELOCITA_IO * rallenta)
            self._passi(fatto)
        self._aggiorna_elisa(dt)
        self._aggiorna_gatto(dt)
        self._raccogli()
        self._controlla_contatti()
        if self.stato != "gioco":
            return
        self._controlla_vittoria()

    # ------------------------------------------------------------ pancia e bagno
    def _bagno_attivo(self):
        return BISOGNO_ATTIVO and bool(self.mondo.gabinetti)

    def _reset_pancia(self):
        self.pancia = random.uniform(0.0, 0.25)
        bisogno = self.liv.get("bisogno", BISOGNO_SECONDI)
        self.pancia_vel = 1.0 / random.uniform(*bisogno) if bisogno[1] > 0 else 0.0
        self.crampo_timer = 3.0
        self.crampi = 0
        self.avviso_bagno = 0.0

    def _aggiorna_pancia(self, dt):
        if not self._bagno_attivo() or self.seduta is not None:
            return
        carico = 0.45 if len(self.richieste) >= 2 else (0.7 if self.richieste else 1.0)       # con tante richieste la pancia aspetta
        self.pancia = min(1.0, self.pancia + self.pancia_vel * carico * dt)
        if self.pancia < 0.5:
            return
        for wc in self.mondo.gabinetti:
            if distanza((self.ale.x, self.ale.y - 8), ((wc[0] + 0.5) * T, (wc[1] + 0.5) * T + 8)) < 36:
                self._inizia_seduta(wc)
                return
        self.crampo_timer -= dt
        if self.crampo_timer <= 0 and self.elisa_modo != "sveglia" and not self.bloccato and self.crampo_blocco <= 0:
            self._crampo()

    def _crampo(self):
        """Uno strizzone di pancia: Ale si piega in due per un attimo."""
        self.crampo_timer = random.uniform(6.0, 9.0) if self.pancia < 1.0 else random.uniform(3.0, 4.5)
        self.crampo_blocco = 0.7
        self.scossa = max(self.scossa, 0.22)
        self.suoni.gioca("gorgoglio")
        self.effetti.scintille(self.ale.x, self.ale.y - 34, (150, 210, 255), 4)
        self.dici(FRASI_PANCIA_PRIMA if self.crampi == 0 else random.choice(FRASI_PANCIA), 3.0, "ale", urgente=True)
        self.crampi += 1

    def _uscita_water(self, wc):
        for d in (GIU, DESTRA, SINISTRA, SU):
            n = somma(wc, d)
            if self.mondo.libera(n):
                return ((n[0] + 0.5) * T, (n[1] + 0.5) * T + 10)
        return ((wc[0] + 0.5) * T, (wc[1] + 0.5) * T + 10)

    def _inizia_seduta(self, wc):
        self.seduta = {"t": 0.0, "wc": wc, "fatti": set()}
        self.crampo_blocco = 0.0
        self.bloccato = False
        self.ale.x, self.ale.y = (wc[0] + 0.5) * T, (wc[1] + 0.5) * T + 18
        self.ale.faccia = GIU
        self.ale.fermo = True
        self.dici(FRASI_BAGNO_INIZIO, SEDUTA_SECONDI, "ale", urgente=True)

    def fase_pantaloni(self, t):
        fine = SEDUTA_SECONDI
        if t < 0.4:
            return 0
        if t < 0.9:
            return 1
        if t < fine - 0.9:
            return 2
        if t < fine - 0.45:
            return 1
        return 0

    def _aggiorna_seduta(self, dt):
        s = self.seduta
        s["t"] += dt
        t = s["t"]
        for chiave, quando, suono in (("a", 1.0, "sforzo"), ("b", 1.7, "sforzo"), ("c", SEDUTA_SECONDI - 0.6, "sciacquone")):
            if t >= quando and chiave not in s["fatti"]:
                s["fatti"].add(chiave)
                self.suoni.gioca(suono)
                if suono == "sforzo":
                    self.effetti.scintille(self.ale.x, self.ale.y - 34, (150, 210, 255), 5)
        if t >= SEDUTA_SECONDI:
            self._finisci_seduta()

    def _finisci_seduta(self):
        wc = self.seduta["wc"]
        self.seduta = None
        self.ale.x, self.ale.y = self._uscita_water(wc)
        self.pancia = 0.0
        self.pancia_vel = 1.0 / random.uniform(*self.liv.get("bisogno", BISOGNO_SECONDI))
        self.punti += PUNTI_SOLLIEVO
        self.suoni.gioca("oggetto")
        self.effetti.cuori(self.ale.x, self.ale.y - 30, 6)
        self.effetti.testo(self.ale.x, self.ale.y - 56, self._testo_img(f"+{PUNTI_SOLLIEVO}", AZZURRO, self.f_hud), 1.1)
        self.dici(FRASI_BAGNO_FINE, 3.0, "ale", urgente=True)

    def _passi(self, fatto):
        """Rumore dei passi (diverso su legno e su erba) e porte che si attraversano."""
        self.dist_passo += fatto
        if self.dist_passo >= 24:
            self.dist_passo = 0.0
            tipo = self.mondo.tipo_pavimento(self.ale.cella)
            self.suoni.gioca("passo_erba" if tipo in ("erba", "pietra", "cemento") else "passo_legno")
            if tipo in ("erba", "pietra"):
                self.effetti.polvere(self.ale.x, self.ale.y)
        ch = self.mondo.carattere(self.ale.cella)
        if ch == "d" and self.ultimo_carattere != "d":
            self.suoni.gioca("porta")
        self.ultimo_carattere = ch

    # -------------------------------------------------------------- Eli (guardia)
    def _cella_ale(self):
        c = self.ale.cella
        if self.mondo.libera(c):
            return c
        for d in DIREZIONI:
            n = somma(c, d)
            if self.mondo.libera(n):
                return n
        return self.mondo.start["L"]

    def _elisa_vede_ale(self):
        """Eli ti nota se sei abbastanza vicino, davanti a lei e senza mobili o muri in mezzo."""
        if ELISA_VISTA_CELLE <= 0:
            return False
        a, b = self.elisa.cella_attuale(), self._cella_ale()
        d = distanza(a, b)
        if d > ELISA_VISTA_CELLE:
            return False
        if d > 0.5:
            f = self.elisa.faccia
            if ((b[0] - a[0]) * f[0] + (b[1] - a[1]) * f[1]) / d < -0.25:
                return False
        visto = self.mondo.linea_libera(a, b)
        if visto:
            self.ultima_vista = b
        return visto

    def _elisa_sospetta(self):
        self.elisa_modo = "sospetta"
        self.elisa_timer = ELISA_SOSPETTO_SECONDI
        a, b = self.elisa.cella_attuale(), self._cella_ale()
        dx, dy = b[0] - a[0], b[1] - a[1]
        self.elisa.faccia = (DESTRA if dx > 0 else SINISTRA) if abs(dx) >= abs(dy) else (GIU if dy > 0 else SU)
        self.elisa.fermo = True
        self.suoni.gioca("sospetta")
        self.dici(FRASI_ELISA_SOSPETTA, 2.0, "eli")

    def _elisa_sveglia(self, da_vista):
        self.elisa_modo = "sveglia"
        self.elisa_timer = self.liv["sveglia_secondi"] * (0.85 if da_vista else 1.0)
        self._velocita_elisa("sveglia")
        self.elisa.sosta = 0.0
        self.suoni.gioca("allerta")
        if da_vista:
            self.dici(FRASI_ELISA_TI_VEDE, 2.5, "eli", urgente=True)
        elif "cerca" not in self.consigli:
            self.consigli.add("cerca")
            self.dici(("Eli ti sta cercando: vuole qualcosa!", "Raggiungila per non farla arrabbiare."), 4.0, "eli")

    def _elisa_cerca(self):
        """Eli ti ha perso: va dove ti ha visto l'ultima volta, si guarda intorno e ti chiama."""
        self.elisa_modo = "cerca"
        self.elisa_timer = ELISA_RICERCA_SECONDI
        self._velocita_elisa("giro")
        self.elisa.sosta = 0.0
        self.elisa.meta = self._centro_ricerca()
        self.chiamata_timer = 0.8
        self.chiamata_visibile = 0.0

    def _centro_ricerca(self):
        if self.ultima_vista in self.mondo.raggiungibili:
            return self.ultima_vista
        return self.elisa.cella_attuale()

    def _elisa_chiama(self):
        bolla, righe = random.choice(FRASI_ELISA_CERCA)
        self.chiamata_timer = random.uniform(2.2, 3.0)
        self.chiamata_visibile = 1.6
        self.chiamata_bolla = bolla
        self.suoni.gioca("chiama")
        self.dici(righe, 2.6, "eli")

    def _meta_di_ricerca(self):
        """Un posto vicino a dove ti ha visto l'ultima volta, dove andare a guardare."""
        dist = self.mondo.distanze(self._centro_ricerca())
        vicine = [c for c, d in dist.items() if 1 <= d <= 6 and c != self.elisa.cella]
        return random.choice(sorted(vicine)) if vicine else self._centro_ricerca()

    def _elisa_torna_al_giro(self):
        self.ultima_vista = None
        self.elisa_modo = "giro"
        self.elisa_timer = random.uniform(*ELISA_GIRO_SECONDI)
        self._velocita_elisa("giro")
        self.elisa.meta = self._nuova_tappa()

    def _aggiorna_elisa(self, dt):
        e = self.elisa
        self.elisa_timer -= dt
        self.chiamata_visibile = max(0.0, self.chiamata_visibile - dt)
        if self.elisa_modo == "chiede":
            e.fermo = True
            return
        if self.elisa_modo == "sospetta":
            e.fermo = True
            if self.elisa_timer <= 0:
                if self._elisa_vede_ale():
                    self._elisa_sveglia(da_vista=True)
                else:
                    self._elisa_cerca()
            return
        if self.elisa_modo == "giro":
            if self.elisa_timer <= 0:
                self._elisa_sveglia(da_vista=False)
            elif self._elisa_vede_ale():
                self._elisa_sospetta()
                return
        elif self.elisa_modo == "cerca":
            if self._elisa_vede_ale():
                self._elisa_sospetta()
                return
            if self.elisa_timer <= 0:
                self._elisa_torna_al_giro()
            else:
                self.chiamata_timer -= dt
                if self.chiamata_timer <= 0:
                    self._elisa_chiama()
        elif self.elisa_timer <= 0:
            self._elisa_cerca()
        if self.elisa_modo == "sveglia":
            self._elisa_vede_ale()
            e.meta = self._cella_ale()
            e.errore = self.liv["errore"]
        else:
            e.errore = 0.0
            if e.sosta > 0:
                e.sosta -= dt
                e.fermo = True
                return
            if e.verso is None and e.cella == e.meta:
                e.sosta = random.uniform(*ELISA_SOSTA_SECONDI)
                e.fermo = True
                if self.elisa_modo == "cerca":
                    e.faccia = random.choice(DIREZIONI)
                    e.meta = self._meta_di_ricerca()
                else:
                    e.meta = self._nuova_tappa()
                return
        e.muovi(dt, self.mondo)

    # ------------------------------------------------------------- Tamiyo (gatto)
    def _aggiorna_gatto(self, dt):
        g = self.gatto
        self.gatto_riposo = max(0.0, self.gatto_riposo - dt)
        if self.gatto_caccia > 0:
            self.gatto_caccia -= dt
            if self.gatto_caccia <= 0:
                self.gatto.curiosita = self.liv["curiosita"]
                self.gatto_riposo = 2.0
            elif g.verso is None and g.cella == g.bersaglio:
                self._nuova_meta_caccia()
        if self.gatto_sazio > 0:
            self.gatto_sazio -= dt
            g.fermo = True
        else:
            if self.gatto_caccia <= 0:
                g.bersaglio = self._cella_ale()
            g.muovi(dt, self.mondo)
        if self.bloccato:
            self.blocco_timer -= dt
            if self.blocco_timer <= 0:
                self.bloccato = False
                self.gatto_riposo = 4.0
        elif (self._vicini(g.piedi(), 22) and self.gatto_riposo <= 0 and self.gatto_sazio <= 0
              and self.gatto_caccia <= 0):
            self._gatto_blocca()

    def _gatto_blocca(self):
        r = self._richiesta_di("gatto")
        if r is None and RICHIESTE_ATTIVE:
            r = self._nuova_richiesta("gatto_crocchini")
        tipo = r.tipo if r is not None else "gatto_crocchini"
        if tipo == "gatto_scatoletta":
            self.gatto_riposo = 1.5
            self.suoni.gioca("gatto")
            if self.mano != "scatoletta":
                self.dici(("Tamiyo vuole una scatoletta!", "Ce ne sono in giardino."), 2.5, "gatto")
            return
        self.bloccato = True
        self.suoni.gioca("gatto")
        if tipo == "gatto_coccole":
            self.blocco_timer = float("inf")
            self.dici(("Tamiyo ti si struscia sulle gambe.", "Tieni premuto SPAZIO per le coccole."), 99.0, "gatto")
        elif self.tasca > 0:
            self.blocco_timer = float("inf")
            self.dici(FRASI_GATTO_BLOCCA, 99.0, "gatto")
        else:
            self.blocco_timer = GATTO_PAZIENZA
            self.dici(FRASI_GATTO_SENZA, GATTO_PAZIENZA, "gatto")

    def _vicini(self, punto, raggio):
        return distanza((self.ale.x, self.ale.y), punto) < raggio

    # ---------------------------------------------------------- oggetti e contatti
    def _centro_oggetto(self, cella):
        return ((cella[0] + 0.5) * T, (cella[1] + 0.5) * T + 4)

    def _raccogli(self):
        corpo = (self.ale.x, self.ale.y - 7)
        cc = self.ale.cella
        for dc in (-1, 0, 1):
            for dr in (-1, 0, 1):
                cella = (cc[0] + dc, cc[1] + dr)
                if cella in self.crocchette and distanza(corpo, self._centro_oggetto(cella)) < 16:
                    self._prendi_crocchetta(cella)
                elif cella in self.scatolette and distanza(corpo, self._centro_oggetto(cella)) < 18:
                    self._prendi_scatoletta(cella)

    def _prendi_crocchetta(self, cella):
        self.crocchette.discard(cella)
        self.punti += PUNTI_CROCCHETTA
        self.tasca = min(TASCA_MASSIMA, self.tasca + 1)
        x, y = self._centro_oggetto(cella)
        self.suoni.crocchetta()
        self.senza_raccolta = 0.0
        if "prima" not in self.consigli and self.crocchette:
            self.consigli.add("prima")
            self.dici((f"Bene! Ne servono {len(self.mondo.crocchette)}: guarda il contatore in alto.",
                       "Presto Eli e Tamiyo ti chiederanno delle cose..."), 6.0, "ale")
        self.effetti.scintille(x, y, (255, 214, 120), 6)
        self.effetti.testo(x, y - 14, self._testo_img(f"+{PUNTI_CROCCHETTA}", (255, 232, 140), self.f_msg), 0.8)
        if not self.crocchette:
            self.letto_attivo = True
            self.suoni.gioca("tutte")
            self.dici(FRASI_TUTTE_RACCOLTE, 4.0, "ale", urgente=True)

    def _prendi_scatoletta(self, cella):
        if self.mano is not None:
            if self.mani_occupate <= 0:
                self.mani_occupate = 3.0
                self.dici(FRASI_MANI_OCCUPATE, 2.5, "ale")
            return
        self.scatolette.discard(cella)
        self.mano = "scatoletta"
        self.mano_nome = "scatoletta"
        self.tempo_notte += SCATOLETTA_SECONDI_EXTRA
        x, y = self._centro_oggetto(cella)
        self.suoni.gioca("scatoletta")
        self.suoni.gioca("oggetto")
        self.effetti.scintille(x, y, (150, 220, 255), 10)
        self.dici(("Hai una scatoletta! (+10 secondi di notte)", "Portala a Tamiyo."), 3.5, "ale")

    def _consegna_scatoletta(self):
        self.mano = None
        self.punti += PUNTI_SCATOLETTA
        self._manda_a_caccia(GATTO_CACCIA_SCATOLETTA)
        gx, gy = self.gatto.piedi()
        self.suoni.gioca("scatoletta")
        self.suoni.gioca("gattino")
        self.effetti.cuori(gx, gy - 22, 9)
        self.effetti.testo(gx, gy - 46, self._testo_img(f"+{PUNTI_SCATOLETTA}", AZZURRO, self.f_hud), 1.1)
        r = self._richiesta_di("gatto")
        if r is not None:
            self._completa_richiesta(r)
        else:
            self.dici(FRASI_SCATOLETTA, 3.5, "gatto")

    # ------------------------------------------- richieste: troppe cose da fare!
    def _richiesta_di(self, chi):
        for r in self.richieste:
            if r.chi == chi:
                return r
        return None

    def _azzera_richieste(self):
        self.richieste = []
        self.mano = None
        self.mano_nome = ""
        self.elisa_cooldown = 4.0
        self.mani_occupate = 0.0
        self.gatto.curiosita = self.liv["curiosita"]
        self.gatto_caccia = 0.0
        self.stress = min(getattr(self, "stress", 0.1), 0.4)
        self.richiesta_timer = max(getattr(self, "richiesta_timer", 0.0), 8.0)

    def _reset_richieste(self):
        self._azzera_richieste()
        self.richiesta_timer = RICHIESTA_PRIMA_SECONDI
        self.stress = 0.1
        self.stress_sudore = 0.0
        self.elisa_cooldown = 0.0

    def _cella_lontana(self, da, minimo):
        """Una casella di pavimento raggiungibile, lontana da 'da' (dove mettere un oggetto)."""
        candidate = [c for c in sorted(self.mondo.raggiungibili)
                     if self.mondo.carattere(c) not in "dLEG" and c not in self.crocchette and c not in self.scatolette
                     and abs(c[0] - da[0]) + abs(c[1] - da[1]) >= minimo]
        return random.choice(candidate) if candidate else self._cella_ale()

    def _nuova_richiesta(self, tipo=None):
        occupati = {r.chi for r in self.richieste}
        if tipo is None:
            scelte = []
            if "gatto" not in occupati and self.gatto_caccia <= 0 and self.gatto_sazio <= 0:
                scelte += ["gatto_crocchini"] * 3 + ["gatto_coccole"] * 2 + ["gatto_scatoletta"] * 2
            if "eli" not in occupati and self.elisa_cooldown <= 0 and self.elisa_modo != "chiede":
                scelte += ["eli_attenzioni"] * 2 + ["eli_aiuto"] * 2
            if not scelte:
                return None
            tipo = random.choice(scelte)
        r = Richiesta(tipo, PAZIENZA_SECONDI)
        self.richieste.append(r)
        if r.chi == "gatto":
            self.gatto.curiosita = 1.0
            self.gatto_riposo = 0.0
            self.gatto_sazio = 0.0
            if tipo == "gatto_scatoletta" and not self.scatolette and self.mano != "scatoletta":
                self.scatolette.add(self._cella_lontana(self._cella_ale(), 8))
        elif self.elisa_modo != "chiede":
            self._elisa_sveglia(da_vista=False)
        self.suoni.gioca("pop")
        self.dici(TIPI_RICHIESTA[tipo]["inizio"], 4.5, "gatto" if r.chi == "gatto" else "eli")
        return r

    def _aggiorna_richieste(self, dt):
        if not RICHIESTE_ATTIVE:
            return
        self.richiesta_timer -= dt
        self.elisa_cooldown = max(0.0, self.elisa_cooldown - dt)
        if self.richiesta_timer <= 0:
            self.richiesta_timer = random.uniform(*RICHIESTA_OGNI_SECONDI)
            self._nuova_richiesta()
        for r in list(self.richieste):
            r.pazienza -= dt * (0.5 if (r.chi == "eli" and not r.attiva) else 1.0)
            if r.pazienza <= 0:
                self._richiesta_fallita(r)
                if self.stato != "gioco":
                    return
        self._aggiorna_tenute(dt)
        self._aggiorna_consegne()
        self._aggiorna_stress(dt)

    def _chiudi_richiesta(self, r):
        if r in self.richieste:
            self.richieste.remove(r)
        if r.chi == "gatto":
            self.bloccato = False
            self.gatto_riposo = GATTO_RIPOSO
            self.gatto.curiosita = self.liv["curiosita"]
        else:
            if self.mano == "aiuto":
                self.mano = None
            self._elisa_torna_al_giro()
            self.elisa_cooldown = 10.0

    def _manda_a_caccia(self, secondi):
        """Tamiyo ha mangiato: se ne va in giardino a caccia di insetti. Con la scatoletta ci sta di piu'."""
        self.bloccato = False
        self.gatto_riposo = 0.0
        if not self.celle_giardino:
            self.gatto_sazio = max(self.gatto_sazio, secondi)
            return
        self.gatto_caccia = max(self.gatto_caccia, secondi)
        self.gatto.curiosita = 1.0
        self._nuova_meta_caccia()

    def _nuova_meta_caccia(self):
        scelte = [c for c in self.celle_giardino if c != self.gatto.cella_attuale()]
        self.gatto.bersaglio = random.choice(scelte) if scelte else self.gatto.cella_attuale()

    def _completa_richiesta(self, r):
        self._chiudi_richiesta(r)
        if r.chi == "gatto":
            self._manda_a_caccia({"gatto_scatoletta": GATTO_CACCIA_SCATOLETTA,
                                  "gatto_coccole": GATTO_CACCIA_COCCOLE}.get(r.tipo, GATTO_CACCIA_CROCCHINO))
        self.punti += PUNTI_RICHIESTA
        self.stress = max(0.0, self.stress - 0.25)
        x, y = self.gatto.piedi() if r.chi == "gatto" else self.elisa.piedi()
        self.effetti.cuori(x, y - 24, 7)
        self.effetti.testo(x, y - 52, self._testo_img(f"+{PUNTI_RICHIESTA}", ROSA, self.f_hud), 1.1)
        self.suoni.gioca("oggetto")
        self.suoni.gioca("gattino" if r.chi == "gatto" else "tutte")
        frasi = FRASI_RICHIESTA_ESAUDITA_GATTO if r.chi == "gatto" else FRASI_RICHIESTA_ESAUDITA_ELI
        self.dici(random.choice(frasi), 3.0, "gatto" if r.chi == "gatto" else "eli")

    def _richiesta_fallita(self, r):
        self._chiudi_richiesta(r)
        self.stress = min(1.0, self.stress + 0.2)
        if r.chi == "eli":
            self._perdi_vita(FRASI_ELISA_DELUSA, "eli")
        else:
            self._manda_a_caccia(GATTO_CACCIA_COCCOLE)
            self.dici(FRASI_GATTO_OFFESO, 3.0, "gatto")

    def _azione_premuta(self):
        if pygame.key.get_pressed()[pygame.K_SPACE]:
            return True
        ax, ay, ar = self._zone_controlli()["azione"]
        return any(distanza(p, (ax, ay)) < ar + 18 for i, p in self.tocchi.items() if i not in self.joy)

    def _aggiorna_tenute(self, dt):
        """Coccole a Tamiyo e attenzioni a Eli: si tiene premuto SPAZIO standole vicino."""
        premuto = self._azione_premuta()
        for r in list(self.richieste):
            if r.tipo not in ("gatto_coccole", "eli_attenzioni") or not r.attiva:
                continue
            bersaglio = self.gatto.piedi() if r.chi == "gatto" else self.elisa.piedi()
            vicino = distanza((self.ale.x, self.ale.y), bersaglio) < 46 and self.seduta is None
            if premuto and vicino:
                r.progresso = min(1.0, r.progresso + dt / TENUTA_SECONDI)
                if random.random() < dt * 5:
                    self.effetti.cuori(bersaglio[0], bersaglio[1] - 24, 1)
                if r.progresso >= 1.0:
                    self._completa_richiesta(r)
            else:
                r.progresso = max(0.0, r.progresso - dt * 0.7)

    def _aggiorna_consegne(self):
        """Scatolette a Tamiyo e oggetti a Eli: basta arrivare vicino mentre li porti."""
        if self.mano == "scatoletta" and distanza((self.ale.x, self.ale.y), self.gatto.piedi()) < 34:
            self._consegna_scatoletta()
            return
        r = self._richiesta_di("eli")
        if r is None or r.tipo != "eli_aiuto" or not r.attiva:
            return
        if self.mano == "aiuto" and distanza((self.ale.x, self.ale.y), self.elisa.piedi()) < 40:
            self.mano = None
            self._completa_richiesta(r)
        elif r.cella is not None and distanza((self.ale.x, self.ale.y - 7), self._centro_oggetto(r.cella)) < 20:
            if self.mano is None:
                self.mano = "aiuto"
                self.mano_nome = r.oggetto
                r.cella = None
                self.suoni.gioca("oggetto")
                self.dici((f"Hai preso {r.oggetto}.", "Portalo a Eli!"), 3.0, "ale")
            elif self.mani_occupate <= 0:
                self.mani_occupate = 3.0
                self.dici(FRASI_MANI_OCCUPATE, 2.5, "ale")

    def _aggiorna_stress(self, dt):
        """L'affanno di Ale sale con le cose da fare e si vede: sudore, tremiti, fiatone."""
        if not STRESS_ATTIVO:
            return
        n = len(self.richieste) + (1 if self._bagno_attivo() and self.pancia >= 0.85 else 0) + (1 if self.bloccato else 0)
        if n:
            self.stress = min(1.0, self.stress + dt * (0.008 + 0.011 * n))
        else:
            self.stress = max(0.0, self.stress - dt * 0.02)
        if self.stress > 0.4 and "affanno" not in self.consigli and self.stato == "gioco":
            self.consigli.add("affanno")
            self.dici(("Troppe cose insieme: Ale e' in affanno!", "Se arriva al massimo perdi un'ora di sonno."), 5.0, "ale")
        if self.stress > 0.25:
            self.stress_sudore -= dt
            if self.stress_sudore <= 0:
                self.stress_sudore = max(0.12, 1.1 - self.stress)
                self.effetti.sudore(self.ale.x + random.uniform(-7, 7), self.ale.y - 46)
        if self.stress >= 1.0:
            self.stress = 0.55
            self._perdi_vita(FRASI_STRESS_AL_LIMITE, "ale")

    def _controlla_contatti(self):
        if self._vicini(self.elisa.piedi(), 20):
            self._eli_incontra()

    def _perdi_vita(self, righe, chi):
        self.vite -= 1
        self.suoni.gioca("sveglia")
        self.suoni.gioca("colpo")
        self.scossa = 0.35
        self.lampo = 0.45
        self.pausa_colpo = 0.09
        if self.vite <= 0:
            self._finisci("vite")
            return
        self.dici(righe, 2.5, chi)
        self.seduta = None
        self.stato = "morte"
        self.timer_stato = 1.6

    def _eli_incontra(self):
        """Eli ti ha raggiunto: ti chiede qualcosa (o, con le richieste spente, ti sveglia)."""
        if not RICHIESTE_ATTIVE:
            self._perdi_vita(FRASI_ELISA_BAGNO if self.seduta is not None else random.choice(FRASI_ELISA), "eli")
            return
        r = self._richiesta_di("eli")
        if r is None:
            if self.elisa_cooldown > 0:
                return
            r = self._nuova_richiesta(random.choice(("eli_attenzioni", "eli_aiuto")))
            if r is None:
                return
        if not r.attiva:
            self._attiva_eli(r)

    def _attiva_eli(self, r):
        r.attiva = True
        r.pazienza = PAZIENZA_SECONDI
        self.elisa_modo = "chiede"
        self.elisa.fermo = True
        a, b = self.elisa.cella_attuale(), self._cella_ale()
        dx, dy = b[0] - a[0], b[1] - a[1]
        self.elisa.faccia = (DESTRA if dx > 0 else SINISTRA) if abs(dx) >= abs(dy) else (GIU if dy > 0 else SU)
        self.suoni.gioca("chiama")
        if self.seduta is not None:
            self.dici(FRASI_ELISA_BAGNO, 3.5, "eli")
        elif r.tipo == "eli_aiuto":
            r.oggetto, r.colore_oggetto, r.breve = random.choice(OGGETTI_AIUTO)
            r.cella = self._cella_lontana(self.elisa.cella_attuale(), 7)
            self.dici((f"Eli: \"Mi porti {r.oggetto}?\"", "Cercalo in giro per casa e portaglielo."), 5.0, "eli")
        else:
            self.dici(("Eli: \"Amore, un po' di attenzioni?\"", "Stalle vicino e tieni premuto SPAZIO."), 5.0, "eli")
        if r.tipo == "eli_aiuto" and r.oggetto is None:
            r.oggetto, r.colore_oggetto, r.breve = random.choice(OGGETTI_AIUTO)
            r.cella = self._cella_lontana(self.elisa.cella_attuale(), 7)

    def _controlla_vittoria(self):
        if not self.letto_attivo:
            return
        letto = self.mondo.start["L"]
        if distanza((self.ale.x, self.ale.y - 8), self._centro_oggetto(letto)) < 28:
            if self._bagno_attivo() and self.pancia >= 0.999:
                if self.avviso_bagno <= 0:
                    self.avviso_bagno = 3.5
                    self.dici(FRASI_PRIMA_IL_BAGNO, 3.0, "ale", urgente=True)
                return
            self.punti += self.vite * PUNTI_PER_VITA_RIMASTA
            self.punti += int(self.tempo_notte) * PUNTI_PER_SECONDO_RIMASTO
            self._avvia_volo("vittoria" if self.ultimo_livello else "livello")

    # ------------------------------------------------------- volo finale
    def _prepara_aereo(self):
        """Costruisce in anticipo i disegni dell'aereo (alla scala della finestra), cosi' non ci sono scatti all'ingresso."""
        se = (self._scala_vista or 1.0) * VOLO_SCALA_AEREO
        if self._aereo_cache is None or abs(self._aereo_cache["s"] - se) > 0.03 * se:
            self._aereo_cache = self._costruisci_aereo(se)

    def _veicolo(self, modo):
        """Con quale mezzo si passa al livello dopo: in aereo, tranne dal secondo al terzo livello (in scooter)."""
        if (modo == "esce" and self.indice_livello == 1) or (modo == "arriva" and self.indice_livello == 2):
            return "scooter"
        return "aereo"

    def _prepara_veicolo(self):
        if self.volo["veicolo"] == "scooter":
            self._prepara_scooter()
        else:
            self._prepara_aereo()

    def _tempo_uscita_volo(self):
        """Quando il veicolo (e, con lo scooter, Elisa che lo insegue) ha lasciato lo schermo."""
        v = self.volo
        if v["veicolo"] == "scooter":
            ingresso = VOLO_INGRESSO if v["modo"] == "esce" else VOLO_ARRIVO_INGRESSO
            return ingresso + (self.larghezza + 230 + SCOOTER_RITARDO + 260) / VOLO_VELOCITA_SCOOTER
        return self._tempo_uscita_aereo(v["modo"])

    def _avvia_volo(self, esito):
        """Tutte le crocchette e il letto raggiunto: Ale sparisce per magia e se ne va in volo."""
        self.stato = "volo"
        self.volo = {"t": 0.0, "modo": "esce", "esito": esito, "poof": False, "motore": False, "risate": -1,
                     "veicolo": self._veicolo("esce")}
        self.letto_attivo = False
        self.bloccato = False
        self._azzera_messaggi()
        self.suoni.gioca("magia")
        self._prepara_veicolo()

    def _avvia_arrivo(self):
        """Livello nuovo: l'aereo arriva da sinistra e fa comparire Ale (con un puf) a casa nuova."""
        self.stato = "arrivo"
        self.ale_visibile = False
        self.volo = {"t": 0.0, "modo": "arriva", "esito": None, "poof": False, "motore": True, "risate": -1,
                     "veicolo": self._veicolo("arriva")}
        self._azzera_messaggi()
        self.suoni.motore(True, self.volo["veicolo"])
        self._prepara_veicolo()

    def _avvia_nuvole(self, dopo=None):
        self.nuvole = {"t": 0.0, "modo": "copri", "dopo": dopo}

    def _aggiorna_nuvole(self, dt):
        n = self.nuvole
        n["t"] += dt
        if n["t"] < NUVOLE_SECONDI:
            return
        if n["modo"] == "copri":
            dopo = n["dopo"]
            self.nuvole = {"t": 0.0, "modo": "scopri", "dopo": None}
            if dopo is not None:
                dopo()
        else:
            self.nuvole = None

    def _aggiorna_volo(self, dt):
        v = self.volo
        v["t"] += dt
        if v["modo"] == "esce":
            self._aggiorna_volo_uscita(v)
        else:
            self._aggiorna_volo_arrivo(v)

    def _risate_aereo(self, v, inizio):
        """Una risata ogni VOLO_RISATA secondi, da quando l'aereo entra in scena. Con lo scooter Ale canta: parte il
        campione del canto (se c'e')."""
        if v["t"] < inizio:
            return
        if v.get("veicolo") == "scooter":
            if not v.get("canto"):
                v["canto"] = True
                self.suoni.gioca("canto")
            return
        giro = int((v["t"] - inizio) / VOLO_RISATA)
        if giro > v["risate"]:
            v["risate"] = giro
            self.suoni.gioca("ahah")

    def _puf(self, x, y, colori_extra=True):
        """Esplosione di luccichii nel mondo (coordinate della vista)."""
        self.scossa = max(self.scossa, 0.3)
        self.effetti.scintille(x, y, GIALLO, 26)
        self.effetti.scintille(x, y, BIANCO, 18)
        if colori_extra:
            for colore in COLORI_MAGIA:
                self.effetti.scintille(x, y, colore, 6)
        self.effetti.cuori(x, y - 10, 4)

    def _aggiorna_volo_uscita(self, v):
        t = v["t"]
        ax, ay = self.ale.x, self.ale.y - 20
        if not v["poof"]:
            if random.random() < 0.6:
                self.effetti.scintille(ax + random.uniform(-10, 10), ay + random.uniform(-14, 14),
                                       random.choice(COLORI_MAGIA), 2)
            if t >= VOLO_SPARIZIONE:
                v["poof"] = True
                self.ale_visibile = False
                self._puf(ax, ay)
                self.suoni.gioca("poof")
        fuori = self._tempo_uscita_volo()
        if t >= VOLO_INGRESSO and not v["motore"]:
            v["motore"] = True
            self.suoni.motore(True, v["veicolo"])
        self._risate_aereo(v, VOLO_INGRESSO)
        if t >= fuori - 1.0 and not v.get("nuvole"):
            v["nuvole"] = True
            self._avvia_nuvole(self._fine_volo)

    def _aggiorna_volo_arrivo(self, v):
        t = v["t"]
        if v["veicolo"] == "scooter":                                          # Ale compare quando lo scooter passa sul suo punto
            t_lancio = VOLO_ARRIVO_INGRESSO + (self.ale.x + 230) / VOLO_VELOCITA_SCOOTER
        else:
            t_lancio = self._piroetta("arriva")[5] + VOLO_PIROETTA_SECONDI      # a fine piroetta Ale compare (plop)
        if t >= VOLO_ARRIVO_INGRESSO and not v.get("miao"):
            v["miao"] = True
            self.suoni.gioca("gattino")                                         # Tamiyo, passeggera, saluta
        if not v["poof"] and t >= t_lancio:
            v["poof"] = True
            v["t_poof"] = t
            self.ale_visibile = True
            self._puf(self.ale.x, self.ale.y - 20)
            self.suoni.gioca("magia")
            self.suoni.gioca("poof")
        self._risate_aereo(v, VOLO_ARRIVO_INGRESSO)
        if t >= self._tempo_uscita_volo():
            self.suoni.motore(False)
            self.volo = None
            self.ale_visibile = True
            self.stato = "pronti"
            self.timer_stato = 1.4
            self.dici(self.liv["intro"], 6.0, "ale")

    def _fine_volo(self):
        esito = self.volo["esito"] if self.volo else "livello"
        self.volo = None
        self.suoni.motore(False)
        self._finisci(esito)

    def _dopo_fine(self):
        """Le nuvole hanno coperto lo schermo: si cambia scena."""
        if self.esito == "livello":
            self.prossimo_livello()
            self._avvia_arrivo()
        elif self.esito == "vittoria":
            self.nuova_partita()
            self._avvia_arrivo()
        else:
            self.riprova_livello()

    def _finisci(self, esito):
        self.esito = esito
        self.stato = "fine"
        self.attesa_fine = 0.8
        self._azzera_messaggi()
        self.suoni.gioca("vittoria" if esito in ("vittoria", "livello") else "sole")
        if self.punti > self.record:
            self.record = self.punti
            self._salva_record()

    # ------------------------------------------------------------------ disegno
    def orologio(self):
        """Ora mostrata: da 02:00 (inizio) a 06:00 (alba)."""
        trascorso = (self.notte_totale - self.tempo_notte) / self.notte_totale
        minuti = int(max(0.0, min(1.0, trascorso)) * 240)
        return f"{2 + minuti // 60:02d}:{minuti % 60:02d}"

    def disegna(self):
        c = self.canvas
        c.fill((10, 12, 26))
        if self.stato == "titolo":
            self.intro.invito = self._tocca("PREMI INVIO")
            self.intro.touch = self.mostra_controlli
            self.intro.f_msg = self.f_msg
            self.intro.disegna(c, self.record, int(self.tempo_totale * 2) % 2 == 0)
        elif self.stato == "guida":
            self._disegna_guida()
        else:
            self._aggiorna_camera()
            self._disegna_mondo()
            sx = sy = 0
            if self.scossa > 0:
                forza = 5 * (self.scossa / 0.35)
                sx, sy = int(random.uniform(-forza, forza)), int(random.uniform(-forza, forza))
            c.blit(self._vista_telefono(), (sx, ALTEZZA_BARRA_ALTA + sy))
            self._disegna_barre()
            self._disegna_schermate()
            self._disegna_volo()
            self._disegna_controlli()
        if EFFETTO_CRT:
            self._crt()

    def _aggiorna_camera(self):
        """Sul telefono la mappa e' piccola: si ingrandisce intorno ad Ale (la telecamera lo segue piano piano).
        Va chiamata PRIMA di disegnare il mondo: i fumetti devono sapere quale parte della mappa si vede."""
        if not self.mostra_controlli or ZOOM_TELEFONO <= 1.01 or self.stato not in ("gioco", "pronti", "pausa")                 or self.volo is not None:
            self.cam = None
            self.vista_visibile = None
            return
        W, H = self.larghezza, self.altezza_mondo
        vw, vh = int(W / ZOOM_TELEFONO), int(H / ZOOM_TELEFONO)
        bersaglio = (self.ale.x, self.ale.y)
        if self.cam is None:
            self.cam = bersaglio
        self.cam = (self.cam[0] + (bersaglio[0] - self.cam[0]) * 0.2, self.cam[1] + (bersaglio[1] - self.cam[1]) * 0.2)
        x = int(max(0, min(W - vw, self.cam[0] - vw / 2)))
        y = int(max(0, min(H - vh, self.cam[1] - vh / 2)))
        self.vista_visibile = pygame.Rect(x, y, vw, vh)

    def _vista_telefono(self):
        """La mappa da mostrare: tutta, oppure (sul telefono) la parte ingrandita scelta da _aggiorna_camera."""
        if self.vista_visibile is None:
            return self.vista
        W, H = self.larghezza, self.altezza_mondo
        if getattr(self, "_vista_zoom", None) is None or self._vista_zoom.get_size() != (W, H):
            self._vista_zoom = pygame.Surface((W, H))
        pygame.transform.smoothscale(self.vista.subsurface(self.vista_visibile), (W, H), self._vista_zoom)
        return self._vista_zoom

    def _crt(self):
        if self._crt_cache is None:
            w, h = self.dimensione
            self._crt_cache = pygame.Surface((w, h), pygame.SRCALPHA)
            for y in range(0, h, 3):
                pygame.draw.line(self._crt_cache, (0, 0, 0, 50), (0, y), (w, y))
        self.canvas.blit(self._crt_cache, (0, 0))

    def _ombra_personaggio(self, s, x, y, larghezza):
        ombra = pygame.Surface((larghezza, 10), pygame.SRCALPHA)
        pygame.draw.ellipse(ombra, (0, 0, 0, 80), ombra.get_rect())
        s.blit(ombra, (int(x - larghezza / 2), int(y - 5)))

    def _disegna_mondo(self):
        s = self.vista
        s.blit(self.sfondo, (0, 0))
        self._disegna_letto_attivo(s)
        for cella in self.crocchette:
            x, y = self._centro_oggetto(cella)
            salto = math.sin(self.tempo_totale * 3 + cella[0] * 1.3 + cella[1]) * 1.5
            s.blit(self.img_croc, self.img_croc.get_rect(center=(int(x), int(y + salto))))
        for cella in self.scatolette:
            x, y = self._centro_oggetto(cella)
            salto = math.sin(self.tempo_totale * 4 + cella[0]) * 2.5
            s.blit(self.img_scat, self.img_scat.get_rect(center=(int(x), int(y - 3 + salto))))
        re = self._richiesta_di("eli")
        if re is not None and re.tipo == "eli_aiuto" and re.attiva and re.cella is not None:
            ox, oy = self._centro_oggetto(re.cella)
            pulsa = 0.5 + 0.5 * math.sin(self.tempo_totale * 6)
            alone = pygame.Surface((30, 30), pygame.SRCALPHA)
            pygame.draw.circle(alone, (255, 240, 140, int(50 + 70 * pulsa)), (15, 15), 14)
            s.blit(alone, (int(ox) - 15, int(oy) - 12))
            raggio = int(22 + 5 * pulsa)                                       # anello grande: si nota da lontano
            pygame.draw.circle(s, (255, 240, 140), (int(ox), int(oy) - 4), raggio, 2)
            rimbalzo = int(abs(math.sin(self.tempo_totale * 5)) * 6)
            pygame.draw.polygon(s, GIALLO, [(ox - 8, oy - 38 - rimbalzo), (ox + 8, oy - 38 - rimbalzo), (ox, oy - 26 - rimbalzo)])
            pygame.draw.polygon(s, (90, 60, 10), [(ox - 8, oy - 38 - rimbalzo), (ox + 8, oy - 38 - rimbalzo), (ox, oy - 26 - rimbalzo)], 2)
            img = self._img_oggetto(re.colore_oggetto, re.breve)
            s.blit(img, (int(ox) - 9, int(oy) - 12 + int(math.sin(self.tempo_totale * 5) * 2)))
        ale, eli, gatto = self.ale, self.elisa, self.gatto
        ex, ey = eli.piedi()
        gx, gy = gatto.piedi()
        if self._ale_si_vede():
            self._ombra_personaggio(s, ale.x, ale.y, 22)
        self._ombra_personaggio(s, ex, ey, 22)
        self._ombra_personaggio(s, gx, gy, 24)
        elementi = [(o[0], 0, o) for o in self.oggetti]
        if self._ale_si_vede():
            elementi.append((ale.y, 1, "ale"))
        elementi.append((ey, 1, "eli"))
        elementi.append((gy, 1, "gatto"))
        elementi.sort(key=lambda e: (e[0], e[1]))
        for _, tipo, dato in elementi:
            if tipo == 0:
                s.blit(dato[1], (dato[2], dato[3]))
            else:
                self._disegna_personaggio(s, dato)
        self._disegna_buio(s)
        self._ritocchi_luce(s)
        self._disegna_fumetti(s)
        self._freccia_aiuto(s)
        self._freccia_bagno(s)
        self._freccia_oggetto(s)
        self.effetti.disegna(s)
        self._disegna_dialogo(s)                       # per ultimo: il testo resta leggibile
        if self.lampo > 0:
            velo = pygame.Surface(s.get_size(), pygame.SRCALPHA)
            velo.fill((255, 60, 60, int(110 * self.lampo / 0.45)))
            s.blit(velo, (0, 0))

    def _img_oggetto(self, colore, breve=None):
        if not hasattr(self, "_oggetti_img"):
            self._oggetti_img = {}
        if (colore, breve) not in self._oggetti_img:
            self._oggetti_img[(colore, breve)] = disegna_oggetto_aiuto(colore, breve)
        return self._oggetti_img[(colore, breve)]

    def _anello(self, s, x, y, valore):
        """Cerchio che si riempie: quanto manca per finire le coccole o le attenzioni."""
        r = 11
        pygame.draw.circle(s, (20, 20, 40), (int(x), int(y)), r + 2)
        punti = [(x, y)]
        passi = max(2, int(36 * valore))
        for k in range(passi + 1):
            a = -math.pi / 2 + 2 * math.pi * valore * k / passi
            punti.append((x + r * math.cos(a), y + r * math.sin(a)))
        if valore > 0.01:
            pygame.draw.polygon(s, (255, 110, 170), punti)
        pygame.draw.circle(s, BIANCO, (int(x), int(y)), r + 2, 2)

    def _disegna_personaggio(self, s, chi):
        if chi == "ale":
            foglio, p, x, y = self.foglio_ale, self.ale, self.ale.x, self.ale.y
            img = foglio.fotogramma(p.faccia, p.fermo, p.distanza)
            if self.seduta is not None:
                img = self._ale_seduto(self.fase_pantaloni(self.seduta["t"]))
                if 1.0 <= self.seduta["t"] <= SEDUTA_SECONDI - 0.9:
                    x += math.sin(self.tempo_totale * 55) * 1.2
        elif chi == "eli":
            foglio, p = self.foglio_eli, self.elisa
            x, y = p.piedi()
            img = foglio.fotogramma(p.faccia, p.fermo, p.distanza)
        else:
            foglio, p = self.foglio_gatto, self.gatto
            x, y = p.piedi()
            img = foglio.fotogramma(p.faccia, p.fermo or self.gatto_sazio > 0, p.distanza)
            if self.gatto_riposo > 0 or self.gatto_sazio > 0:
                img = img.copy()
                img.set_alpha(185 if self.gatto_sazio <= 0 else 225)
        if chi == "ale" and self.seduta is not None:
            pygame.draw.ellipse(s, (240, 244, 248), (int(x) - 17, int(y) - 26, 34, 17))
            pygame.draw.ellipse(s, (150, 160, 178), (int(x) - 17, int(y) - 26, 34, 17), 1)
            pygame.draw.rect(s, (236, 240, 246), (int(x) - 9, int(y) - 40, 18, 9), border_radius=2)
            s.blit(img, (int(x - 32), int(y - img.get_bounding_rect().bottom)))
        else:
            if chi == "ale" and self.stress > 0.35:
                x += math.sin(self.tempo_totale * 45) * (self.stress - 0.35) * 2.6
            s.blit(img, (int(x - foglio.largo / 2), int(y - foglio.piede - 1)))

    # ------------------------------------------------- disegno del volo (fumettistico)
    def _ale_si_vede(self):
        if not self.ale_visibile:
            return False
        v = self.volo
        if self.stato == "volo" and v is not None and not v["poof"] and v["t"] > 0.35:
            return int(v["t"] * 14) % 2 == 1          # lampeggia prima di sparire
        return True

    def _stella_fumetto(self, c, x, y, raggio, colore, bordo, punte=14, ruota=0.0):
        punti = []
        for k in range(punte * 2):
            r = raggio if k % 2 == 0 else raggio * 0.58
            a = ruota + math.pi * k / punte
            punti.append((x + r * math.cos(a), y + r * math.sin(a)))
        pygame.draw.polygon(c, colore, punti)
        pygame.draw.polygon(c, bordo, punti, 3)

    def _scritta_fumetto(self, c, testo, x, y, colore, angolo=0.0, scala=1.0):
        """Scritta da fumetto: colore pieno, bordo nero, un po' inclinata."""
        base = self.f_titolo.render(testo, False, colore)
        nera = self.f_titolo.render(testo, False, (0, 0, 0))
        img = pygame.Surface((base.get_width() + 8, base.get_height() + 8), pygame.SRCALPHA)
        for dx, dy in ((0, 0), (6, 0), (0, 6), (6, 6), (3, 0), (3, 6), (0, 3), (6, 3)):
            img.blit(nera, (dx, dy))
        img.blit(base, (3, 3))
        if scala != 1.0:
            img = pygame.transform.scale(img, (max(2, int(img.get_width() * scala)), max(2, int(img.get_height() * scala))))
        img = pygame.transform.rotate(img, angolo)                  # niente sfumature: pixel nitidi
        c.blit(img, img.get_rect(center=(int(x), int(y))))

    # ---------------------------------------- aereo e pilota ad alta risoluzione (liscio, a fumetto)
    COL_AE = {
        "k": (38, 28, 56), "giallo": (255, 205, 60), "giallo_s": (226, 148, 34), "giallo_l": (255, 238, 150),
        "rosso": (232, 66, 74), "rosso_s": (168, 38, 52), "rosso_l": (250, 130, 126), "bianco": (252, 252, 255),
        "grigio": (176, 182, 198), "grigio_s": (120, 126, 144), "vetro": (170, 226, 255), "vetro_s": (110, 176, 232),
        "pelle": (244, 188, 146), "pelle_s": (214, 142, 112), "pelle_l": (255, 214, 180),
        "capelli": (82, 54, 40), "capelli_l": (140, 108, 86), "capelli_s": (52, 34, 28),
        "barba": (128, 108, 96), "barba_g": (196, 184, 172), "barba_s": (84, 66, 58),
    }

    def _piroetta(self, modo="esce"):
        """Parametri della piroetta: velocita' d'ingresso, raggio, durata, velocita' angolare, deriva in avanti
        (puo' essere negativa: la 'e' corsiva torna un po' indietro), istante d'inizio e istante d'ingresso."""
        ingresso, v_in = (VOLO_INGRESSO, VOLO_VELOCITA) if modo == "esce" else (VOLO_ARRIVO_INGRESSO, VOLO_ARRIVO_VELOCITA)
        R, ts = VOLO_PIROETTA_RAGGIO, VOLO_PIROETTA_SECONDI
        w = 2 * math.pi / ts
        vd = v_in + 50 - R * w                           # nel giro l'aereo e' un po' piu' veloce
        t0 = ingresso + (VOLO_PIROETTA_X + 170) / v_in
        return v_in, R, ts, w, vd, t0, ingresso

    def _percorso_aereo(self, t, modo="esce"):
        """Percorso dell'aereo: entra da sinistra, fa una piroetta all'indietro (come una 'e' in corsivo: sale, si
        rovescia e torna giu') e poi se ne va a destra. Durante il giro l'aereo ha sempre il muso lungo la
        traiettoria (tangente). Ritorna (x, y, angolo in gradi, velocita')."""
        v_in, R, ts, w, vd, t0, ingresso = self._piroetta(modo)
        base = ALTEZZA_BARRA_ALTA + VOLO_QUOTA_USCITA
        tl = t - t0
        beccheggio = math.sin(t * 3.1) * 8
        if tl <= 0:
            return -170 + v_in * (t - ingresso), base + beccheggio, 0.0, v_in
        if tl <= ts:
            th = w * tl
            x = VOLO_PIROETTA_X + vd * tl + R * math.sin(th)
            y = base - R * (1 - math.cos(th)) + beccheggio * (1 - math.sin(math.pi * tl / ts))
            direzione = math.degrees(math.atan2(R * w * math.sin(th), vd + R * w * math.cos(th)))
            if direzione < 0:
                direzione += 360.0
            return x, y, direzione, v_in
        x_fine = VOLO_PIROETTA_X + vd * ts
        return x_fine + VOLO_VELOCITA_DOPO * (tl - ts), base + beccheggio, 0.0, VOLO_VELOCITA_DOPO

    def _tempo_uscita_aereo(self, modo="esce"):
        """Quando l'aereo e' uscito dallo schermo (a destra)."""
        v_in, R, ts, w, vd, t0, ingresso = self._piroetta(modo)
        x_fine = VOLO_PIROETTA_X + vd * ts
        return t0 + ts + (self.larghezza + 260 - x_fine) / VOLO_VELOCITA_DOPO

    def _pos_aereo(self):
        """Posizione dell'aereo (coordinate della tela) oppure None se non e' in scena.
        Ritorna (x, y, tempo, velocita', angolo)."""
        v = self.volo
        if v is None or self.stato not in ("volo", "arrivo"):
            return None
        t = v["t"]
        modo = v["modo"]
        if t < self._piroetta(modo)[6]:
            return None
        x, y, ang, vel = self._percorso_aereo(t, modo)
        if x > self.larghezza + 260:
            return None
        return x, y, t, vel, ang

    def _costruisci_testa(self, s):
        """Il testone di Ale: la sua faccia (dalla foto, scorporata) con la bocca animata, capelli lunghi disegnati a
        mano dietro e cuffia da pilota con occhialoni davanti. Se la foto manca, usa una faccia a fumetto disegnata.
        Ritorna la lista dei fotogrammi della bocca (dalla piu' chiusa alla piu' aperta)."""
        C = self.COL_AE
        K = C["k"]
        caso = random.Random(11)
        p = Pennello(200, 210, s, 100, 105)
        capelli = []                                                       # capelli lunghi dietro la testa
        for i in range(64):
            a = 2 * math.pi * i / 64
            r = 1 + 0.06 * math.sin(7 * a) + 0.04 * math.sin(13 * a + 1)
            capelli.append((math.cos(a) * 84 * r, 8 + math.sin(a) * 66 * r))
        p.poly(capelli, C["capelli"], K, 3)
        for _ in range(26):                                                # ciocche
            x0 = caso.uniform(-70, 70)
            y0 = caso.uniform(-6, 30)
            y1 = min(y0 + caso.uniform(36, 64), 8 + 60 * math.sqrt(max(0.0, 1 - (x0 / 84) ** 2)) - 4)
            p.linea(Pennello.curva((x0, y0), (x0 + caso.uniform(-16, 16), (y0 + y1) / 2), (x0 + caso.uniform(-12, 12), y1)),
                    caso.choice((C["capelli_l"], C["capelli_s"], C["capelli_l"])), 2.4)
        def faccia_vettore(p):
            p.ell(-47, -46, 94, 112, C["pelle_s"], K, 3)                       # faccia
            p.ell(-45, -48, 88, 106, C["pelle"])
            p.ell(-30, -44, 60, 22, C["pelle_l"])

            def barba(x, y):
                return ((x / 46.0) ** 2 + ((y - 10) / 55.0) ** 2 <= 1.0) and y > 16 - 22 * (abs(x) / 46.0) ** 1.5

            lato = [(-47 * math.cos(math.radians(a)), 10 + 56 * math.sin(math.radians(a))) for a in range(0, 181, 6)]
            alto = [(46, -6), (34, 6), (18, 16), (0, 18), (-18, 16), (-34, 6), (-46, -6)]
            p.poly(lato + alto, C["barba"], K, 3)
            for _ in range(420):                                               # sale e pepe
                x, y = caso.uniform(-44, 44), caso.uniform(-6, 64)
                if not barba(x, y):
                    continue
                a = math.radians(caso.uniform(60, 120))
                n = caso.uniform(4, 9)
                x2, y2 = x + math.cos(a) * n, y + math.sin(a) * n
                if barba(x2, y2):
                    p.linea([(x, y), (x2, y2)], C["barba_g"] if caso.random() < 0.55 else C["barba_s"], 1.7)
            for sgn in (-1, 1):                                                # baffi folti
                p.poly([(0, 20), (sgn * 12, 16), (sgn * 28, 19), (sgn * 40, 28), (sgn * 31, 32), (sgn * 15, 29), (0, 29)],
                       C["barba_s"], K, 2.6)
                for i in range(5):
                    p.linea([(sgn * (8 + i * 6), 20 + i), (sgn * (10 + i * 6), 27 + i)], C["barba_g"], 1.5)
            p.ell(-26, 24, 52, 40, (116, 24, 44), K, 3)                        # bocca aperta che ride
            denti = [(24 * math.cos(math.radians(a)), 44 + 19 * math.sin(math.radians(a))) for a in range(190, 351, 8)]
            denti = [q for q in denti if q[1] <= 35.5]
            p.poly(denti + Pennello.curva((denti[-1][0], 35.5), (0, 39), (denti[0][0], 35.5)), C["bianco"], None)
            for dx in (-12, 0, 12):
                p.linea([(dx, 27), (dx, 36)], (214, 214, 228), 1.6)
            p.ell(-14, 50, 28, 13, (240, 116, 132))                            # lingua
            p.ell(-26, 24, 52, 40, None, K, 3)
            for cx in (-40, 24):                                               # guance da risata
                p.ell(cx, 14, 17, 13, (248, 152, 144))
            p.ell(-11, -6, 24, 28, (226, 156, 124))                            # naso grosso
            p.ell(-5, -2, 8, 12, (252, 206, 172))
            p.ell(-9, 16, 6, 4, (150, 90, 80))
            p.ell(5, 16, 6, 4, (150, 90, 80))
            for cx, sgn in ((-23, -1), (23, 1)):                               # occhi spalancati che guardano avanti
                cy = -6
                p.ell(cx - 14, cy - 12, 28, 24, C["bianco"], K, 3)
                p.circ(cx + 5, cy, 8.5, (98, 62, 44))
                p.circ(cx + 6, cy, 4, K)
                p.circ(cx + 3, cy - 3.5, 2.4, C["bianco"])
                p.linea(Pennello.curva((cx - 14, cy - 2), (cx, cy - 18), (cx + 14, cy - 2)), K, 3.6)
                p.linea(Pennello.curva((cx - 11, cy + 10), (cx, cy + 17), (cx + 11, cy + 10)), C["pelle_s"], 2.2)
                p.linea([(cx + sgn * 15, cy + 1), (cx + sgn * 25, cy - 3)], C["pelle_s"], 2)
                p.linea([(cx + sgn * 15, cy + 6), (cx + sgn * 25, cy + 8)], C["pelle_s"], 2)
            p.poly([(-42, -22), (-35, -35), (-13, -37), (-5, -30), (-12, -26), (-33, -24)], C["capelli_s"])   # sopracciglia
            p.poly([(42, -26), (35, -39), (13, -41), (5, -34), (12, -30), (33, -28)], C["capelli_s"])

        def cuffia(p):
            for sgn in (-1, 1):                                                # paraorecchie della cuffia
                p.poly([(sgn * 70, -30), (sgn * 52, -24), (sgn * 48, 22), (sgn * 56, 40), (sgn * 72, 32), (sgn * 79, -8)],
                       C["rosso_s"], K, 3)
                p.poly([(sgn * 66, -24), (sgn * 54, -20), (sgn * 52, 18), (sgn * 58, 32), (sgn * 70, 26), (sgn * 74, -6)],
                       C["rosso"])
                for i in range(4):
                    p.linea([(sgn * 60, -8 + i * 11), (sgn * 70, -4 + i * 11)], C["giallo_l"], 1.8)
            cupola = [(68 * math.cos(math.radians(a)), -30 + 72 * math.sin(math.radians(a))) for a in range(180, 361, 6)]
            p.poly(cupola, C["rosso"], K, 3)                                   # cuffia di cuoio rossa
            p.poly([(-56, -66), (-44, -82), (-20, -92), (-8, -88), (-30, -78), (-46, -62)], C["rosso_l"])
            for sgn in (-1, 1):
                p.linea(Pennello.curva((0, -100), (sgn * 24, -72), (sgn * 52, -38)), C["rosso_s"], 2.2)
            p.poly([(-69, -38), (0, -34), (69, -38), (69, -24), (0, -20), (-69, -24)], C["rosso_s"], K, 3)
            for x in range(-60, 61, 12):
                p.linea([(x, -30), (x + 5, -29)], C["giallo_l"], 1.6)
            p.linea(Pennello.curva((-68, -50), (0, -40), (68, -50)), (92, 60, 44), 7)      # cinghia
            for sgn in (-1, 1):                                                # occhialoni sollevati sulla cuffia
                gx = sgn * 27
                p.circ(gx, -64, 23, C["grigio"], K, 3)
                p.circ(gx, -64, 17, C["vetro"], C["grigio_s"], 2.2)
                p.ell(gx - 11, -76, 14, 8, C["bianco"])
                p.ell(gx + 2, -58, 11, 5, C["vetro_s"])
            p.linea([(-6, -64), (6, -64)], C["grigio_s"], 5)

        foto = carica_immagine(FILE_FACCIA_PILOTA)
        if foto is None:
            faccia_vettore(p)
            cuffia(p)
            return [p.fine()]
        sopra = Pennello(200, 210, s, 100, 105)
        cuffia(sopra)
        return self._teste_con_foto(p.fine(), sopra.fine(), foto, s)

    def _teste_con_foto(self, dietro, davanti, foto, s, n=5):
        """Mette la faccia della foto tra i capelli (dietro) e la cuffia (davanti) e anima la bocca: una fascia
        orizzontale della foto, all'altezza della bocca, viene allungata o accorciata solo al centro del viso
        (gaussiana), e tutto cio' che sta sotto (mento, barba) scende o sale di conseguenza."""
        K = self.COL_AE["k"]
        k = FACCIA_UNITA * s                          # pixel dello schermo per pixel del ritaglio
        w, h = max(2, int(foto.get_width() * k)), max(2, int(foto.get_height() * k))
        base = pygame.transform.smoothscale(foto, (w, h))
        ya, yb = int(FACCIA_BOCCA[0] * k), int(FACCIA_BOCCA[1] * k)
        xm, sigma = FACCIA_BOCCA[2] * k, FACCIA_BOCCA[3] * k
        aperture = [FACCIA_APERTURA[0] + (FACCIA_APERTURA[1] - FACCIA_APERTURA[0]) * i / (n - 1) for i in range(n)]
        extra = int(max(aperture) * k) + 2
        ex, ey = FACCIA_OCCHI[0] * k, FACCIA_OCCHI[1] * k
        posizione = (int(100 * s - ex), int((105 - 6) * s - ey))
        cw = max(2, int(3 * s))
        teste = []
        for d_max in aperture:
            fr = pygame.Surface((w, h + extra), pygame.SRCALPHA)
            fr.blit(base, (0, 0), (0, 0, w, ya))
            for x0 in range(0, w, cw):
                lar = min(cw, w - x0)
                d = d_max * k * math.exp(-(((x0 + lar / 2) - xm) / sigma) ** 2)
                banda = base.subsurface((x0, ya, lar, yb - ya))
                alt = max(1, int(round(yb - ya + d)))
                fr.blit(pygame.transform.smoothscale(banda, (lar, alt)) if alt != yb - ya else banda, (x0, ya))
                sotto = base.subsurface((x0, yb, lar, h - yb))
                fr.blit(sotto, (x0, ya + alt))
            sagoma = pygame.mask.from_surface(fr, 90).to_surface(setcolor=K + (255,), unsetcolor=(0, 0, 0, 0))
            r = max(2, int(round(2.6 * s)))                               # contorno scuro uniforme, come il resto del disegno
            testa = dietro.copy()
            for ang in range(0, 360, 30):
                testa.blit(sagoma, (posizione[0] + int(math.cos(math.radians(ang)) * r),
                                    posizione[1] + int(math.sin(math.radians(ang)) * r)))
            testa.blit(fr, posizione)
            testa.blit(davanti, (0, 0))
            teste.append(testa)
        return teste

    def _costruisci_gatto_vettore(self, s):
        """Versione disegnata a mano di Tamiyo (se manca la foto): gatta grigia con casco di cuoio e occhialoni."""
        C = self.COL_AE
        K = C["k"]
        PELO, PELO_S, PELO_L = (160, 164, 178), (112, 116, 134), (214, 216, 228)
        CUOIO, CUOIO_S, CUOIO_L = (154, 100, 62), (104, 66, 42), (204, 150, 104)
        p = Pennello(160, 190, s, 80, 100)
        p.ell(-50, -40, 100, 86, PELO, K, 3)                                       # testa
        for sg in (-1, 1):                                                          # ciuffi di pelo sulle guance
            p.poly([(sg * 44, -2), (sg * 62, 4), (sg * 50, 12), (sg * 65, 22), (sg * 46, 28), (sg * 52, 40), (sg * 32, 36)],
                   PELO, K, 2.6)
        for dx in (-14, 0, 14):                                                     # strisce tigrate
            p.linea([(dx, -34), (dx, -22)], PELO_S, 3)
        p.ell(-24, 8, 48, 36, PELO_L)                                               # musetto
        p.poly([(-7, 12), (7, 12), (0, 21)], (240, 140, 160), K, 2.2)               # naso
        p.linea([(0, 21), (0, 27)], K, 2.4)
        p.linea(Pennello.curva((-13, 29), (-6, 36), (0, 27)), K, 2.4)               # bocca
        p.linea(Pennello.curva((0, 27), (6, 36), (13, 29)), K, 2.4)
        for sg in (-1, 1):                                                          # baffi
            for dy, ay in ((17, -7), (23, 1), (29, 9)):
                p.linea([(sg * 20, dy), (sg * 60, dy + ay)], (246, 246, 252), 1.9)
        for sg in (-1, 1):                                                          # occhiali da aviatore sugli occhi
            p.circ(sg * 22, -8, 19, (196, 124, 60), K, 3)
            p.circ(sg * 22, -8, 14, (186, 226, 248))
            p.circ(sg * 22, -8, 9.5, (238, 248, 232))
            p.circ(sg * 24, -8, 6.5, (150, 196, 70))
            p.ell(sg * 24 - 2, -14, 4, 12, K)
            p.circ(sg * 21, -12, 2.2, C["bianco"])
            p.ell(sg * 22 - 11, -19, 9, 5, C["bianco"])
        p.linea([(-6, -8), (6, -8)], (196, 124, 60), 5)
        calotta = [(56 * math.cos(math.radians(a)), -24 + 40 * math.sin(math.radians(a))) for a in range(180, 361, 8)]
        p.poly(calotta, CUOIO, K, 3)                                                # casco di cuoio
        p.linea(Pennello.curva((-30, -62), (0, -58), (30, -62)), CUOIO_S, 2.4)
        p.poly([(-34, -58), (-12, -62), (-22, -50)], CUOIO_L)
        p.poly([(-57, -26), (57, -26), (57, -20), (-57, -20)], CUOIO_S, K, 2.6)    # bordo del casco
        for sg in (-1, 1):
            p.poly([(sg * 52, -22), (sg * 62, 4), (sg * 52, 18), (sg * 44, -6)], CUOIO_S, K, 2.6)
            p.poly([(sg * 20, -42), (sg * 38, -78), (sg * 48, -36)], PELO, K, 3)    # orecchie che sbucano dal casco
            p.poly([(sg * 26, -44), (sg * 38, -68), (sg * 43, -40)], (246, 176, 188))
        for sg in (-1, 1):                                                          # zampine sul bordo dell'abitacolo
            p.ell(sg * 30 - 14, 48, 28, 22, C["bianco"], K, 3)
            for dx in (-6, 0, 6):
                p.linea([(sg * 30 + dx, 56), (sg * 30 + dx, 66)], PELO_S, 1.8)
        return p.fine()

    def _costruisci_gatto(self, s):
        """Tamiyo passeggera (norvegese delle foreste): la sua testa dalla foto, con criniera, berrettino di cuoio,
        occhialoni da aviatore sugli occhi e le zampine sul bordo dell'abitacolo. Senza foto usa una gatta disegnata."""
        foto = carica_immagine(FILE_FACCIA_TAMIYO)
        if foto is None:
            return self._costruisci_gatto_vettore(s)
        C = self.COL_AE
        K = C["k"]
        PELO_L, PELO_S = (216, 218, 230), (112, 116, 134)
        CUOIO, CUOIO_S, CUOIO_L = (154, 100, 62), (104, 66, 42), (204, 150, 104)
        caso = random.Random(31)
        dietro = Pennello(160, 190, s, 80, 100)                                    # criniera folta attorno alla testa
        criniera = []
        for i in range(36):
            a = math.pi * (0.04 + 0.92 * i / 35)
            r = 1.0 + (0.09 if i % 2 else -0.02) + caso.uniform(-0.02, 0.03)
            criniera.append((math.cos(a) * 58 * r, 6 + math.sin(a) * 46 * r))
        dietro.poly(criniera + [(-50, 4), (50, 4)], PELO_L, K, 2.6)
        for _ in range(16):
            x0, y0 = caso.uniform(-48, 48), caso.uniform(18, 40)
            dietro.linea([(x0, y0), (x0 + caso.uniform(-5, 5), y0 + caso.uniform(8, 14))], PELO_S, 1.6)
        sup = dietro.fine()
        k = TAMIYO_UNITA * s
        img = pygame.transform.smoothscale(foto, (max(2, int(foto.get_width() * k)), max(2, int(foto.get_height() * k))))
        pos = (int(80 * s - TAMIYO_OCCHI[0] * k), int((100 - 8) * s - TAMIYO_OCCHI[1] * k))
        sagoma = pygame.mask.from_surface(img, 90).to_surface(setcolor=K + (255,), unsetcolor=(0, 0, 0, 0))
        r = max(2, int(round(2.4 * s)))                                            # contorno scuro come il resto del disegno
        for ang in range(0, 360, 30):
            sup.blit(sagoma, (pos[0] + int(math.cos(math.radians(ang)) * r), pos[1] + int(math.sin(math.radians(ang)) * r)))
        sup.blit(img, pos)
        p = Pennello(160, 190, s, 80, 100)
        p.poly([(-34, -28), (34, -28), (34, -40), (20, -54), (0, -58), (-20, -54), (-34, -40)], CUOIO, K, 2.8)   # berrettino
        p.linea(Pennello.curva((-22, -52), (0, -48), (22, -52)), CUOIO_S, 2.2)
        p.poly([(-20, -50), (-8, -56), (-14, -44)], CUOIO_L)
        p.poly([(-40, -34), (40, -34), (40, -27), (-40, -27)], CUOIO_S, K, 2.4)                                # fascia
        for sg in (-1, 1):
            p.linea([(sg * 36, -28), (sg * 33, 6), (sg * 18, 30)], CUOIO_S, 3.2)                              # sottogola
        for sg in (-1, 1):                                                         # occhialoni da aviatore sugli occhi
            p.linea([(sg * 30, -8), (sg * 46, -13)], CUOIO_S, 4)
            p.circ(sg * 16.6, -8, 15.5, (198, 126, 60), K, 2.8)
            p.circ(sg * 16.6, -8, 11.5, (190, 228, 250, 110))
            p.ell(sg * 16.6 - 9, -17, 8, 4, C["bianco"])
        p.linea([(-3, -8), (3, -8)], (198, 126, 60), 4)
        for sg in (-1, 1):                                                         # zampine sul bordo dell'abitacolo
            p.ell(sg * 30 - 14, 48, 28, 22, C["bianco"], K, 3)
            for dx in (-6, 0, 6):
                p.linea([(sg * 30 + dx, 56), (sg * 30 + dx, 66)], PELO_S, 1.8)
        sup.blit(p.fine(), (0, 0))
        return sup

    def _costruisci_aereo(self, s):
        """Tutti i pezzi fissi dell'ultraleggero, gia' alla scala giusta; quelli che si muovono sono disegnati a ogni fotogramma."""
        C = self.COL_AE
        K = C["k"]
        cache = {"s": s}
        d = Pennello(500, 470, s, 250, 270)
        d.poly([(-150, -8), (-212, -98), (-170, -104), (-104, -20)], C["rosso"], K, 3)               # coda
        d.poly([(-146, -22), (-190, -84), (-176, -86), (-130, -22)], C["bianco"])
        d.poly([(-126, -12), (-226, -24), (-232, -6), (-126, 10)], C["rosso"], K, 3)                   # piano di coda
        d.linea([(-134, -2), (-218, -14)], C["bianco"], 2)
        d.linea([(-122, 26), (-142, 62)], K, 4)
        d.circ(-144, 68, 8, K)
        d.circ(-144, 68, 3.5, C["grigio"])
        for x1, x2 in ((-6, -14), (100, 108)):                                                       # carrello sotto la pancia
            d.linea([(x1, 40), (x2, 98)], (214, 220, 238), 11)
            d.linea([(x1, 40), (x2, 98)], K, 8)
            d.circ(x2, 114, 25, (214, 220, 238))
            d.circ(x2, 114, 22, K)
            d.circ(x2, 114, 12, C["grigio"])
            d.circ(x2 - 3, 111, 4, C["bianco"])
        d.poly([(76, -36), (-24, -36), (-50, -70), (-4, -78), (50, -72)], (214, 222, 240), K, 3)      # ala lontana
        d.ell(-170, -46, 340, 96, C["giallo_s"], K, 3.2)                                              # fusoliera
        d.ell(-168, -48, 336, 84, C["giallo"])
        d.ell(-120, -40, 200, 16, C["giallo_l"])
        d.ell(-140, 2, 290, 20, C["rosso"])
        d.linea([(-130, 4), (150, 4)], C["bianco"], 2)
        for x in range(-122, 140, 22):
            d.circ(x, 14, 2.4, C["bianco"])
        d.linea(Pennello.curva((-78, -40), (-92, 2), (-76, 44)), C["giallo_s"], 2.2)
        d.linea(Pennello.curva((120, -36), (134, 2), (118, 40)), C["giallo_s"], 2.2)
        ala = [(84, 16), (-26, 16), (-50, 38), (-70, 62), (-66, 76), (-30, 84), (10, 80), (26, 62), (52, 38)]   # ala vicina
        d.ell(-30, 12, 118, 16, (200, 156, 36))                                                       # ombra dell'ala sulla fusoliera
        d.poly([(x, y + 5) for x, y in ala], (200, 208, 228))
        d.poly(ala, C["bianco"], K, 3.4)
        d.poly([(-70, 62), (-66, 76), (-30, 84), (10, 80), (26, 62), (-20, 68)], C["rosso"])          # estremita' rossa
        d.linea([(-70, 62), (-20, 68), (26, 62)], K, 2.4)
        d.linea([(-20, 24), (-52, 58)], (206, 214, 234), 3)                                           # bordo d'uscita
        d.linea([(22, 26), (-4, 60)], (206, 214, 234), 2.4)                                           # alettone
        d.ell(140, -38, 60, 84, C["rosso"], K, 3.2)                                                   # cofano
        d.ell(152, -28, 12, 50, C["rosso_l"])
        d.ell(190, -16, 36, 44, C["grigio"], K, 3)                                                    # ogiva
        d.ell(197, -10, 10, 14, C["bianco"])
        d.ell(-86, -58, 116, 32, (80, 52, 46), K, 3)                                                  # abitacolo
        d.ell(-166, -60, 104, 30, (80, 52, 46), K, 3)                                                 # abitacolo posteriore (passeggero)
        d.ell(-170, -64, 112, 38, None, C["giallo"], 5)
        d.ell(-72, -88, 88, 64, C["bianco"], K, 3)                                                    # spalle del pilota
        d.ell(-62, -56, 68, 18, (214, 220, 238))
        cache["dietro"] = d.fine()
        f = Pennello(500, 470, s, 250, 270)
        f.poly([(-94, -48), (36, -48), (44, -28), (-100, -28)], C["giallo"], K, 3)                    # bordo abitacolo
        f.linea([(-86, -42), (28, -42)], C["giallo_l"], 3)
        f.poly([(52, -48), (114, -48), (86, -114), (60, -114)], C["vetro"], K, 3)                     # parabrezza
        f.linea([(66, -56), (78, -100)], C["bianco"], 5)
        f.linea([(82, -56), (90, -76)], C["bianco"], 3)
        cache["davanti"] = f.fine()
        pr = Pennello(60, 220, s, 30, 110)                                                            # elica sfocata
        pr.ell(-11, -100, 22, 200, (255, 255, 255, 150), K, 1.6)
        cache["elica"] = pr.fine()
        cache["pale"] = []
        for ang in (0, 38, 90):
            pl = Pennello(60, 220, s, 30, 110)
            a = math.radians(ang)
            pl.poly([(math.sin(a) * -92, math.cos(a) * -92), (6, 0), (math.sin(a) * 92, math.cos(a) * 92), (-6, 0)], K)
            cache["pale"].append(pl.fine())
        cache["sciarpa"] = []
        for fr in range(8):
            sc = Pennello(300, 130, s, 290, 65)
            punti = [(-k * 3.6, -k * 0.35 + math.sin(fr * math.pi / 4 + k * 0.17) * (1 + k * 0.2)) for k in range(41)]
            raggi = [11 - 6.0 * k / 40 for k in range(41)]
            for (x, y), r in zip(punti, raggi):
                sc.circ(x, y, r + 2.4, K)
            for (x, y), r in zip(punti, raggi):
                sc.circ(x, y, r, C["giallo"])
            for (x, y), r in zip(punti[::4], raggi[::4]):
                sc.circ(x + 1, y + r * 0.3, r * 0.45, C["giallo_s"])
            cache["sciarpa"].append(sc.fine())
        cache["braccio"] = []
        for fr in range(6):
            w = math.sin(fr * math.pi / 3) * 14
            br = Pennello(160, 180, s, 40, 160)
            percorso = [(0, 0), (40, -26), (88 + w * 0.4, -86 + w * 0.3)]
            br.linea(percorso, K, 30)
            br.linea(percorso, C["rosso"], 22)
            br.linea([percorso[1], percorso[2]], C["rosso_l"], 6)
            br.linea([(percorso[2][0] - 4, percorso[2][1] + 2), (percorso[2][0] + 4, percorso[2][1] - 4)], C["bianco"], 24)
            br.ell(percorso[-1][0] - 12, percorso[-1][1] - 30, 26, 30, (110, 70, 48), K, 3)
            for dx in (-7, 0, 7):
                br.linea([(percorso[-1][0] + dx, percorso[-1][1] - 24), (percorso[-1][0] + dx, percorso[-1][1] - 30)], K, 2)
            cache["braccio"].append(br.fine())
        go = Pennello(24, 30, s, 12, 8)
        go.poly([(0, -6), (-7, 8), (7, 8)], C["vetro_s"])
        go.circ(0, 8, 7, C["vetro_s"])
        go.circ(-2, 6, 2.4, C["bianco"])
        cache["goccia"] = go.fine()
        om = Pennello(320, 60, s, 160, 30)
        om.ell(-150, -24, 300, 48, (0, 0, 0, 34))
        om.ell(-122, -19, 244, 38, (0, 0, 0, 40))
        om.ell(-92, -14, 184, 28, (0, 0, 0, 46))
        cache["ombra"] = om.fine()
        cache["teste"] = self._costruisci_testa(s)
        cache["gatto"] = self._costruisci_gatto(s * 1.2)          # un po' piu' grande, per vedere bene la faccia
        cache["bolle"] = {}
        return cache

    def _bolla_aereo(self, cache, testo, fattore=0.78):
        """Un fumetto con una scritta, gia' pronto alla scala giusta (fattore = quanto e' grande)."""
        chiave = (testo, fattore)
        if chiave in cache["bolle"]:
            return cache["bolle"][chiave]
        s, C = cache["s"], self.COL_AE
        K = C["k"]
        larghezza = 300 if len(testo) < 12 else 440
        p = Pennello(larghezza + 60, 150, s * fattore, (larghezza + 60) / 2, 70)
        p.poly([(-70, 20), (-30, 24), (40, 64)], C["bianco"], K, 3.4)
        p.ell(-larghezza / 2, -60, larghezza, 90, C["bianco"], K, 3.4)
        p.poly([(-72, 22), (-28, 25), (-52, 30)], C["bianco"])
        font = self._font(max(8, int(40 * p.k)))
        img = font.render(testo, True, K)
        cx, cy = p.P((0, -15))
        p.sup.blit(img, img.get_rect(center=(int(cx), int(cy))))
        cache["bolle"][chiave] = p.fine()
        return cache["bolle"][chiave]

    def _aereo_hires(self, dest, s, off):
        """Disegna l'aereo con Ale pilota direttamente alla risoluzione dello schermo (s = ingrandimento della tela,
        off = angolo in alto a sinistra della tela). Cosi' resta nitido a qualunque dimensione della finestra.
        Durante la piroetta l'aereo viene composto a parte e ruotato."""
        pos = self._pos_aereo()
        if pos is None:
            return
        px, py, t, vel, ang = pos
        se = s * VOLO_SCALA_AEREO
        cache = self._aereo_cache
        if cache is None or abs(cache["s"] - se) > 0.03 * se:
            cache = self._aereo_cache = self._costruisci_aereo(se)
        cx, cy = off[0] + px * s, off[1] + py * s
        suolo = off[1] + (ALTEZZA_BARRA_ALTA + VOLO_QUOTA_USCITA) * s   # l'ombra resta a terra anche quando l'aereo sale
        ruota = 0.5 < ang < 359.5
        if ruota:
            lato = int(640 * se)
            piano = pygame.Surface((lato, lato), pygame.SRCALPHA)
            tx, ty = lato / 2, lato / 2 + 40 * se                      # il disegno gira attorno al suo centro (0, -40)
            sup = piano
        else:
            tx, ty, sup = cx, cy, dest

        def metti(img, x, y, ox, oy):
            sup.blit(img, (int(tx + x * se - ox * se), int(ty + y * se - oy * se)))

        dest.blit(cache["ombra"], (int(cx - 160 * se), int(suolo + 262 * se - 30 * se)))
        for k in range(7):                                                       # scia di fumo
            eta = (k + (t * 8) % 1.0) * 0.11
            r = max(2, int((5 + eta * 42) * s))
            alfa = max(0, int(170 * (1 - eta / 0.8)))
            fumo = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(fumo, (238, 238, 244, alfa), (r, r), r)
            dest.blit(fumo, (int(cx - (200 * VOLO_SCALA_AEREO + vel * eta) * s - r), int(cy + (34 + eta * 20) * s - r)))
        if not ruota:
            for j in range(3):                                                   # righe di velocita'
                x0 = cx - (300 + ((t * 520 + j * 71) % 160)) * s
                y0 = cy + (-40 + j * 52) * s
                pygame.draw.line(dest, (205, 214, 238), (int(x0), int(y0)), (int(x0 - 46 * s), int(y0)), max(1, int(2 * s)))
        metti(cache["dietro"], 0, 0, 250, 270)
        metti(cache["sciarpa"][int(t * 14) % 8], -50, -70, 290, 65)
        tc = t % VOLO_RISATA                                                     # secondi dall'inizio dell'ultima risata
        ridendo = tc < VOLO_RISATA_DURATA
        apertura = abs(math.sin(math.pi * tc / (VOLO_RISATA_DURATA / 5))) if ridendo else 0.25   # un'apertura per ogni "ha"
        scossa = apertura * 7 if ridendo else 0.0
        teste = cache["teste"]
        testa = pygame.transform.rotozoom(teste[int(apertura * (len(teste) - 1) + 0.5)], math.sin(t * 8) * 5, 1.0)
        sup.blit(testa, testa.get_rect(center=(int(tx - 12 * se), int(ty - 118 * se - scossa * se))))
        for lato_l, fase_l in ((-1, 0.0), (1, 0.5)):                             # lacrime di gioia
            giro = (t * 1.6 + fase_l) % 1.0
            metti(cache["goccia"], -12 + lato_l * (36 + giro * 6), -118 - 6 + giro * 32 - scossa, 12, 8)
        metti(cache["braccio"][int(t * 9) % 6], 30, -66, 40, 160)
        metti(cache["davanti"], 0, 0, 250, 270)
        if self.volo["modo"] == "arriva":                                        # Tamiyo passeggera dietro al pilota
            metti(cache["gatto"], -128, -92 - scossa * 0.5 + math.sin(t * 5) * 2, 96, 120)
        metti(cache["elica"], 210, 6, 30, 110)
        metti(cache["pale"][int(t * 30) % 3], 210, 6, 30, 110)
        if ruota:
            giro_img = pygame.transform.rotozoom(piano, ang, 1.0)               # angolo positivo = antiorario: all'indietro
            dest.blit(giro_img, giro_img.get_rect(center=(int(cx), int(cy - 40 * se))))
            return
        if tc < VOLO_RISATA_DURATA + 0.15:                                       # fumetto: solo la risata
            bolla = self._bolla_aereo(cache, "AHAHAHA!")
            pop = min(1.0, tc / 0.12)
            if pop < 1.0:
                f = 1.0 + 0.25 * math.sin(pop * math.pi)
                bolla = pygame.transform.smoothscale(bolla, (int(bolla.get_width() * f), int(bolla.get_height() * f)))
            dest.blit(bolla, bolla.get_rect(center=(int(cx - 165 * se), int(cy - 262 * se))))

    # ------------------------------------------- scooter: Ale che canta, Tamiyo dietro, Elisa che insegue
    def _pos_scooter(self):
        """Posizione dello scooter (x del centro, y del terreno, tempo) oppure None se non e' in scena."""
        v = self.volo
        if v is None or self.stato not in ("volo", "arrivo") or v.get("veicolo") != "scooter":
            return None
        t = v["t"]
        ingresso = VOLO_INGRESSO if v["modo"] == "esce" else VOLO_ARRIVO_INGRESSO
        if t < ingresso:
            return None
        x = -230 + VOLO_VELOCITA_SCOOTER * (t - ingresso)
        if x - SCOOTER_RITARDO > self.larghezza + 260:
            return None
        return x, ALTEZZA_BARRA_ALTA + SCOOTER_TERRA, t

    def _costruisci_scooter(self, s):
        """Pezzi fissi dello scooter (una Vespa color menta), di Ale in sella e di Elisa che corre, alla scala giusta;
        quello che si muove (ruote, bocca, gambe di Elisa, note, fumo) viene disegnato a ogni fotogramma."""
        C = self.COL_AE
        K = C["k"]
        MENTA, MENTA_S, MENTA_L = (126, 208, 190), (84, 164, 152), (200, 242, 230)
        CROMO, CROMO_S = (228, 234, 244), (150, 158, 176)
        JEANS, GIUBBOTTO, GIUBBOTTO_S, PELLE_M = (66, 96, 160), (124, 78, 52), (86, 54, 36), (244, 188, 146)
        cache = {"s": s}
        d = Pennello(700, 440, s, 360, 410)
        d.ell(-232, -62, 112, 18, CROMO, K, 2.6)                                                       # marmitta
        scocca = [(-205, -62), (-214, -108), (-192, -152), (-130, -166), (-62, -154), (-22, -122), (-12, -72),
                  (-44, -52), (-100, -46), (-166, -50)]
        d.poly(scocca, MENTA, K, 3.2)                                                                  # scocca posteriore
        d.poly([(-205, -62), (-166, -50), (-100, -46), (-44, -52), (-12, -72), (-40, -82), (-110, -72), (-186, -80)], MENTA_S)
        d.ell(-172, -124, 66, 34, MENTA_S, K, 2.4)                                                     # presa d'aria
        for i in range(4):
            d.linea([(-160 + i * 13, -114), (-150 + i * 13, -96)], K, 2.2)
        d.linea(Pennello.curva((-200, -122), (-110, -154), (-30, -110)), MENTA_L, 4)
        d.poly([(-218, -112), (-206, -112), (-206, -90), (-218, -90)], C["rosso"], K, 2)               # fanalino
        d.poly([(-188, -168), (-40, -168), (-26, -152), (-58, -138), (-168, -138), (-198, -152)], (88, 56, 42), K, 3)   # sella
        d.linea([(-176, -160), (-60, -160)], (140, 98, 76), 3)
        d.poly([(-14, -62), (104, -62), (108, -44), (-14, -44)], CROMO_S, K, 3)                       # pedana
        for x in range(0, 100, 16):
            d.linea([(x, -60), (x, -46)], (110, 116, 132), 2)
        d.poly([(68, -54), (118, -54), (130, -124), (126, -196), (104, -206), (86, -134)], MENTA, K, 3.2)   # scudo
        d.linea(Pennello.curva((102, -200), (118, -130), (112, -70)), MENTA_L, 3.6)
        d.linea([(124, -176), (150, -44)], K, 12)                                                      # forcella
        d.linea([(124, -176), (150, -44)], CROMO, 7)
        d.linea([(108, -200), (146, -210)], K, 11)                                                     # manubrio
        d.linea([(108, -200), (146, -210)], CROMO, 7)
        d.circ(156, -190, 22, CROMO, K, 3)                                                             # faro
        d.circ(158, -190, 15, (255, 238, 150))
        d.circ(152, -196, 4, C["bianco"])
        d.linea([(112, -206), (104, -254)], K, 6)                                                      # specchietto
        d.circ(100, -260, 12, CROMO, K, 2.6)
        d.poly([(112, -86), (150, -100), (192, -84), (196, -62), (176, -64), (150, -80), (124, -66)], MENTA, K, 3)   # parafango
        cache["corpo"] = d.fine()
        cache["ruote"] = {}
        for nome, r in (("p", 40), ("a", 36)):                                                        # ruote (ruotano a ogni fotogramma)
            w = Pennello(100, 100, s, 50, 50)
            w.circ(0, 0, r, (34, 30, 44), K, 3)
            w.circ(0, 0, r - 9, CROMO, K, 2.4)
            for i in range(5):
                a = 2 * math.pi * i / 5
                w.linea([(0, 0), (math.cos(a) * (r - 13), math.sin(a) * (r - 13))], CROMO_S, 3)
            w.circ(0, 0, 8, CROMO_S, K, 2.4)
            w.circ(r - 15, 0, 3.2, C["rosso"])
            cache["ruote"][nome] = w.fine()
        p = Pennello(700, 440, s, 360, 410)                                                            # Ale in sella
        for a, b, spessore in (((-76, -148), (16, -126), 32), ((16, -126), (36, -62), 28)):
            p.linea([a, b], K, spessore + 8)
        for a, b, spessore in (((-76, -148), (16, -126), 32), ((16, -126), (36, -62), 28)):
            p.linea([a, b], JEANS, spessore)
        p.ell(12, -72, 58, 26, C["bianco"], K, 3)                                                      # scarpa
        p.linea([(18, -60), (64, -60)], (190, 196, 214), 3)
        p.poly([(-104, -150), (-48, -146), (-8, -226), (-30, -262), (-82, -250), (-110, -200)], GIUBBOTTO, K, 3.4)   # giubbotto
        p.poly([(-60, -252), (-30, -262), (-8, -228), (-30, -214)], GIUBBOTTO_S)
        p.linea([(-78, -244), (-70, -160)], GIUBBOTTO_S, 3)
        percorso = [(-28, -232), (34, -204), (112, -194)]
        p.linea(percorso, K, 32)
        p.linea(percorso, GIUBBOTTO, 24)
        p.circ(116, -192, 13, K)
        p.circ(116, -192, 10, PELLE_M)
        cache["pilota"] = p.fine()
        cache["teste"] = self._costruisci_testa(s)
        cache["gatto"] = self._costruisci_gatto(s * 1.2)
        # Elisa che corre: 8 fotogrammi del passo, con il braccio teso verso lo scooter
        CAMICIA, PANTALONI = (240, 228, 208), (70, 140, 88)
        cache["elisa"], cache["elisa_testa_pos"] = [], []
        for fr in range(8):
            ph = 2 * math.pi * fr / 8
            e = Pennello(340, 380, s, 170, 350)
            hip = (-4.0, -152.0 + 5 * abs(math.sin(ph)))
            gambe = []
            for sfasamento in (0.0, math.pi):
                a = ph + sfasamento
                coscia = 0.95 * math.sin(a)
                ginocchio = (hip[0] + 66 * math.sin(coscia), hip[1] + 66 * math.cos(coscia))
                stinco = coscia - (0.35 + 1.0 * max(0.0, math.sin(a + 1.3)))
                piede = (ginocchio[0] + 66 * math.sin(stinco), ginocchio[1] + 66 * math.cos(stinco))
                gambe.append((ginocchio, piede))
            dy = -max(g[1][1] for g in gambe)                                                          # i piedi toccano terra
            def T(q):
                return (q[0], q[1] + dy)
            anca = T(hip)
            spalla = (anca[0] + 30, anca[1] - 78)
            for ginocchio, piede in gambe:
                e.linea([anca, T(ginocchio), T(piede)], K, 34)
            for ginocchio, piede in gambe:
                e.linea([anca, T(ginocchio), T(piede)], PANTALONI, 26)
                fx, fy = T(piede)
                e.ell(fx - 12, fy - 12, 42, 20, C["bianco"], K, 3)
            gomito_i = (spalla[0] - 26 + 10 * math.sin(ph), spalla[1] + 40)                           # braccio indietro
            mano_i = (gomito_i[0] - 30 + 14 * math.sin(ph + 1), gomito_i[1] + 20 - 12 * math.sin(ph))
            e.linea([spalla, gomito_i, mano_i], K, 24)
            e.linea([spalla, gomito_i, mano_i], CAMICIA, 17)
            e.circ(mano_i[0], mano_i[1], 10, PELLE_M, K, 2.4)
            e.linea([anca, spalla], K, 60)                                                             # busto inclinato in avanti
            e.linea([anca, spalla], CAMICIA, 52)
            e.linea([(anca[0] + 8, anca[1] - 20), (spalla[0] - 6, spalla[1] + 6)], (214, 196, 170), 5)
            gomito_f = (spalla[0] + 52, spalla[1] - 2 + 3 * math.sin(ph))                              # braccio teso verso lo scooter
            mano_f = (spalla[0] + 112, spalla[1] - 8 + 6 * math.sin(ph))
            e.linea([spalla, gomito_f, mano_f], K, 25)
            e.linea([spalla, gomito_f, mano_f], CAMICIA, 18)
            for ang in (-34, -12, 10, 30):                                                             # dita aperte
                a = math.radians(ang)
                e.linea([mano_f, (mano_f[0] + math.cos(a) * 26, mano_f[1] + math.sin(a) * 26)], K, 8)
            for ang in (-34, -12, 10, 30):
                a = math.radians(ang)
                e.linea([mano_f, (mano_f[0] + math.cos(a) * 24, mano_f[1] + math.sin(a) * 24)], PELLE_M, 4.6)
            e.circ(mano_f[0], mano_f[1], 13, PELLE_M, K, 2.4)
            cache["elisa"].append(e.fine())
            cache["elisa_testa_pos"].append((spalla[0] + 8, spalla[1] - 56))
        foto = carica_immagine(FILE_FACCIA_ELISA)
        if foto is not None:
            k = ELISA_UNITA * s
            img = pygame.transform.smoothscale(foto, (max(2, int(foto.get_width() * k)), max(2, int(foto.get_height() * k))))
            sagoma = pygame.mask.from_surface(img, 90).to_surface(setcolor=K + (255,), unsetcolor=(0, 0, 0, 0))
            r = max(2, int(round(2.4 * s)))
            lato = max(img.get_width(), img.get_height()) + 4 * r
            testa = pygame.Surface((lato, lato), pygame.SRCALPHA)
            ex, ey = ELISA_OCCHI[0] * k, ELISA_OCCHI[1] * k
            pos = (int(lato / 2 - ex), int(lato / 2 - ey))
            for ang in range(0, 360, 30):
                testa.blit(sagoma, (pos[0] + int(math.cos(math.radians(ang)) * r), pos[1] + int(math.sin(math.radians(ang)) * r)))
            testa.blit(img, pos)
            cache["elisa_testa"] = testa
        else:
            cache["elisa_testa"] = None
        nota = Pennello(60, 80, s, 20, 60)                                                             # note musicali
        nota.ell(-12, -12, 24, 18, C["giallo"], K, 2.6)
        nota.linea([(10, -6), (10, -52)], K, 6)
        nota.linea([(10, -6), (10, -52)], C["giallo"], 3)
        nota.poly([(10, -52), (30, -40), (30, -28), (10, -38)], C["giallo"], K, 2.4)
        cache["nota"] = nota.fine()
        om = Pennello(560, 60, s, 280, 30)
        om.ell(-260, -22, 520, 44, (0, 0, 0, 34))
        om.ell(-210, -17, 420, 34, (0, 0, 0, 40))
        om.ell(-150, -12, 300, 24, (0, 0, 0, 46))
        cache["ombra"] = om.fine()
        cache["bolle"] = {}
        return cache

    def _prepara_scooter(self):
        se = (self._scala_vista or 1.0) * VOLO_SCALA_SCOOTER
        if self._scooter_cache is None or abs(self._scooter_cache["s"] - se) > 0.03 * se:
            self._scooter_cache = self._costruisci_scooter(se)

    def _scooter_hires(self, dest, s, off):
        """Disegna la scena dello scooter alla risoluzione dello schermo: Elisa corre dietro con la mano tesa, Ale canta
        in sella (bocca animata a tempo, note musicali) con Tamiyo passeggera dietro di lui."""
        pos = self._pos_scooter()
        if pos is None:
            return
        px, terra, t = pos
        se = s * VOLO_SCALA_SCOOTER
        cache = self._scooter_cache
        if cache is None or abs(cache["s"] - se) > 0.03 * se:
            cache = self._scooter_cache = self._costruisci_scooter(se)
        gx = off[0] + px * s
        gy = off[1] + terra * s
        rimbalzo = abs(math.sin(t * 11)) * 3 * se                                    # scossoni della strada

        def metti(img, x, y, ox, oy, base_x=gx, base_y=gy - rimbalzo):
            dest.blit(img, (int(base_x + x * se - ox * se), int(base_y + y * se - oy * se)))

        ex = gx - (SCOOTER_RITARDO + math.sin(t * 2.1) * 26) * s                      # Elisa insegue, un po' piu' lenta
        dest.blit(cache["ombra"], (int(gx - 280 * se), int(gy - 30 * se)))
        dest.blit(cache["ombra"], (int(ex - 280 * se * 0.5 - 20 * se), int(gy - 30 * se)))   # (stessa ombra, un po' piu' stretta)
        for k in range(7):                                                           # fumo della marmitta
            eta = (k + (t * 8) % 1.0) * 0.11
            r = max(2, int((4 + eta * 30) * s))
            alfa = max(0, int(150 * (1 - eta / 0.8)))
            fumo = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(fumo, (238, 238, 244, alfa), (r, r), r)
            dest.blit(fumo, (int(gx - (250 * VOLO_SCALA_SCOOTER + VOLO_VELOCITA_SCOOTER * eta) * s - r),
                             int(gy - (40 * VOLO_SCALA_SCOOTER + eta * 14) * s - r)))
        # Elisa: corre, braccio teso verso Ale
        fr = int(t / 0.07) % 8
        ey = gy - abs(math.sin(t * 9)) * 4 * se
        dest.blit(cache["elisa"][fr], (int(ex - 170 * se), int(ey - 350 * se)))
        testa_e = cache["elisa_testa"]
        if testa_e is not None:
            hx, hy = cache["elisa_testa_pos"][fr]
            dest.blit(testa_e, testa_e.get_rect(center=(int(ex + hx * se), int(ey + hy * se))))
        # scooter: ruote che girano, carrozzeria, Ale e Tamiyo
        ang_ruota = -(t * 540) % 360
        for nome, cx_r, cy_r in (("p", -120, -40), ("a", 150, -36)):
            ruota = pygame.transform.rotozoom(cache["ruote"][nome], ang_ruota, 1.0)
            dest.blit(ruota, ruota.get_rect(center=(int(gx + cx_r * se), int(gy - rimbalzo + cy_r * se))))
        metti(cache["corpo"], 0, 0, 360, 410)
        metti(cache["pilota"], 0, 0, 360, 410)
        metti(cache["gatto"], -150, -228 + math.sin(t * 6) * 2, 96, 120)
        cadenza = t * 2.4                                                            # una nota cantata ogni ~0.4 s
        apertura = abs(math.sin(math.pi * cadenza)) ** 0.7
        teste = cache["teste"]
        testa = pygame.transform.rotozoom(teste[int(apertura * (len(teste) - 1) + 0.5)], math.sin(t * 5) * 4, 1.0)
        dest.blit(testa, testa.get_rect(center=(int(gx - 26 * se), int(gy - rimbalzo - 300 * se - apertura * 3 * se))))
        for k in range(3):                                                           # note musicali che escono dalla bocca
            eta = (t * 0.9 + k / 3.0) % 1.0
            nota = cache["nota"]
            nota.set_alpha(int(255 * min(1.0, (1 - eta) * 2.2)))
            dest.blit(nota, (int(gx + (10 + 80 * eta + 12 * math.sin(eta * 9 + k)) * se - 20 * se),
                             int(gy - (255 + 150 * eta) * se - 60 * se)))
        # fumetti: Ale canta il titolo, Elisa lo chiama
        pop = 1.0 + 0.05 * math.sin(t * 8)
        bolla = self._bolla_aereo(cache, "BORN TO BE WILD!")
        bolla = pygame.transform.smoothscale(bolla, (int(bolla.get_width() * pop), int(bolla.get_height() * pop)))
        dest.blit(bolla, bolla.get_rect(center=(int(gx - 70 * se), int(gy - 430 * se))))
        if (t % 2.4) < 1.5:
            piccola = self._bolla_aereo(cache, "ALE!!!", 0.55)
            dest.blit(piccola, piccola.get_rect(center=(int(ex - 10 * se), int(ey - 400 * se))))

    def _volo_hires(self, dest, s, off):
        """Disegna la scena del volo (aereo o scooter) alla risoluzione dello schermo."""
        if self.volo is None:
            return
        if self.volo.get("veicolo") == "scooter":
            self._scooter_hires(dest, s, off)
        else:
            self._aereo_hires(dest, s, off)

    def _disegna_volo(self):
        v = self.volo
        if v is None or self.stato not in ("volo", "arrivo"):
            return
        c = self.canvas
        t = v["t"]
        if v["modo"] == "esce":
            # luccichii prima del puf, poi esplosione fumettistica sopra il letto
            if t >= VOLO_SPARIZIONE:
                self._esplosione(c, t - VOLO_SPARIZIONE, "POOF!", GIALLO, -8)
        else:
            if v["poof"]:
                self._esplosione(c, t - v["t_poof"], "PLOP!", (150, 230, 255), 7)
            self._disegna_cartello_livello(c, t)
        # l'aereo non e' qui: si disegna in presenta(), alla risoluzione vera dello schermo

    def _esplosione(self, c, tt, scritta, colore, angolo):
        """Stella gialla, anello bianco e scritta da fumetto sopra Ale (tt = secondi dallo scoppio)."""
        if tt >= 0.9:
            return
        px, py = self.ale.x, ALTEZZA_BARRA_ALTA + self.ale.y - 22
        fase = min(1.0, tt / 0.35)
        raggio = 14 + 78 * (1 - (1 - fase) ** 3)
        if tt < 0.55:
            self._stella_fumetto(c, px, py, raggio, (255, 232, 90), (20, 16, 30), 12, tt * 2.0)
            self._stella_fumetto(c, px, py, raggio * 0.55, (255, 255, 255), (255, 150, 60), 12, -tt * 2.0)
        anello = pygame.Surface((260, 260), pygame.SRCALPHA)
        pygame.draw.circle(anello, (255, 255, 255, int(220 * (1 - tt / 0.9))), (130, 130),
                           int(10 + 118 * min(1.0, tt / 0.7)), 4)
        c.blit(anello, (int(px) - 130, int(py) - 130))
        self._scritta_fumetto(c, scritta, px, py - 54 - tt * 30, colore, angolo, min(1.0, 0.3 + tt * 5))

    def _disegna_cartello_livello(self, c, t):
        """All'arrivo: il nome del livello entra da sinistra, come in un cartone animato."""
        if t < 0.5:
            return
        e = min(1.0, (t - 0.5) / 0.45)
        e = 1 - (1 - e) ** 3
        W = self.larghezza
        y = ALTEZZA_BARRA_ALTA + self.altezza_mondo - 150
        x = W // 2 - (1 - e) * W
        fascia = pygame.Surface((W, 92), pygame.SRCALPHA)
        fascia.fill((0, 0, 14, 190))
        c.blit(fascia, (int(x - W // 2), y - 46))
        testo = f"LIVELLO {self.indice_livello + 1}"
        titolo = self.f_titolo.render(testo, True, GIALLO)
        c.blit(self.f_titolo.render(testo, True, (0, 0, 0)), titolo.get_rect(center=(int(x) + 3, y - 9)))
        c.blit(titolo, titolo.get_rect(center=(int(x), y - 12)))
        nome = self.f_grande.render(self.liv["nome"], True, ROSA)
        c.blit(nome, nome.get_rect(center=(int(x), y + 24)))

    def _disegna_nuvole(self, c=None, scala=1.0, off=(0, 0)):
        """Transizione: un banco di nuvole attraversa lo schermo (copre da sinistra, poi scopre verso destra).
        Si disegna per ultimo, davanti anche all'aereo: per questo puo' lavorare su qualunque superficie e scala."""
        n = self.nuvole
        W, H = self.dimensione
        c = self.canvas if c is None else c
        p = min(1.0, n["t"] / NUVOLE_SECONDI)
        p = p * p * (3 - 2 * p)
        bordo = -150 + p * (W + 300)
        corpo, ombra, luce = (206, 220, 247), (146, 166, 212), (238, 245, 255)
        ox, oy = off
        cerchi = []
        for i, y in enumerate(range(-30, H + 70, 46)):
            r = 48 + int(14 * math.sin(i * 1.7))
            cerchi.append((bordo + 18 * math.sin(i * 2.3 + n["t"] * 4), y, r))
        area = pygame.Rect(int(ox), int(oy), int(W * scala), int(H * scala))
        vecchia = c.get_clip()
        c.set_clip(area)
        for x, y, r in cerchi:
            pygame.draw.circle(c, ombra, (int(ox + x * scala), int(oy + (y + 5) * scala)), int((r + 3) * scala))
        if n["modo"] == "copri":
            pygame.draw.rect(c, corpo, (int(ox), int(oy), max(0, int(bordo * scala)), int(H * scala)))
        elif bordo < W:
            pygame.draw.rect(c, corpo, (int(ox + bordo * scala), int(oy), int((W - bordo) * scala) + 2, int(H * scala)))
        for x, y, r in cerchi:
            pygame.draw.circle(c, corpo, (int(ox + x * scala), int(oy + y * scala)), int(r * scala))
            pygame.draw.circle(c, luce, (int(ox + (x - r * 0.3) * scala), int(oy + (y - r * 0.36) * scala)),
                               max(4, int(r * 0.32 * scala)))
        c.set_clip(vecchia)

    def _disegna_letto_attivo(self, s):
        if not self.letto_attivo:
            return
        x, y = self.mondo.start["L"]
        pulsa = 0.5 + 0.5 * math.sin(self.tempo_totale * 6)
        alone = pygame.Surface((T + 8, T + 8), pygame.SRCALPHA)
        pygame.draw.rect(alone, (255, 230, 100, int(70 + 120 * pulsa)), alone.get_rect(), border_radius=8)
        s.blit(alone, (x * T - 4, y * T - 4))
        salto = int(abs(math.sin(self.tempo_totale * 5)) * 5)
        cx, cy = x * T + 16, y * T - 10 - salto
        pygame.draw.polygon(s, (255, 230, 100), [(cx - 8, cy - 8), (cx + 8, cy - 8), (cx, cy + 4)])
        pygame.draw.polygon(s, (120, 80, 20), [(cx - 8, cy - 8), (cx + 8, cy - 8), (cx, cy + 4)], 2)

    def _ritocchi_luce(self, s):
        """Rifiniture di atmosfera: le crocchette brillano un po' (si vedono da lontano) e gli angoli della stanza si
        scuriscono piano, come in un vero film notturno."""
        if not hasattr(self, "_aloni"):
            self._aloni = []
            for livello in range(4):
                lato = 30
                alone = pygame.Surface((lato, lato))
                for r in range(lato // 2, 0, -1):
                    forza = (1 - r / (lato / 2)) ** 1.6 * (26 + 12 * livello)
                    pygame.draw.circle(alone, (int(forza), int(forza * 0.86), int(forza * 0.5)), (lato // 2, lato // 2), r)
                self._aloni.append(alone)
            piccola = pygame.Surface((48, 34), pygame.SRCALPHA)
            for yy in range(34):
                for xx in range(48):
                    d = math.hypot((xx - 23.5) / 24.0, (yy - 16.5) / 17.0)
                    piccola.set_at((xx, yy), (4, 6, 20, int(max(0.0, min(1.0, (d - 0.62) / 0.55)) ** 1.5 * 120)))
            self._vignetta = pygame.transform.smoothscale(piccola, s.get_size())
        for cella in self.crocchette:
            x, y = self._centro_oggetto(cella)
            livello = int(2 + 1.5 * math.sin(self.tempo_totale * 3 + cella[0] * 1.3 + cella[1]))
            alone = self._aloni[max(0, min(3, livello))]
            s.blit(alone, (int(x) - 15, int(y) - 15), special_flags=pygame.BLEND_RGB_ADD)
        s.blit(self._vignetta, (0, 0))

    def _disegna_buio(self, s):
        if OSCURITA <= 0:
            return
        if self._buio is None or self._buio.get_size() != s.get_size():
            self._buio = pygame.Surface(s.get_size(), pygame.SRCALPHA)
        buio = self._buio
        buio.fill((6, 8, 28, int(min(255, OSCURITA))))
        r = int(RAGGIO_LUCE)
        buio.blit(self._luce(r), (int(self.ale.x - r), int(self.ale.y - 22 - r)), special_flags=pygame.BLEND_RGBA_MIN)
        for (x, y, raggio) in self.luci:
            buio.blit(self._luce(raggio), (x - raggio, y - raggio), special_flags=pygame.BLEND_RGBA_MIN)
        for (x, y) in self._cose_da_illuminare():                 # cio' che ti serve per una richiesta non resta mai al buio
            raggio = 78 + int(6 * math.sin(self.tempo_totale * 4))
            buio.blit(self._luce(raggio), (int(x) - raggio, int(y) - raggio), special_flags=pygame.BLEND_RGBA_MIN)
        s.blit(buio, (0, 0))

    def _cose_da_illuminare(self):
        """Punti (in pixel della mappa) da tenere illuminati: l'oggetto che Eli ti ha chiesto e, se Tamiyo vuole una
        scatoletta, le scatolette."""
        punti = []
        re = self._richiesta_di("eli")
        if re is not None and re.tipo == "eli_aiuto" and re.attiva and re.cella is not None:
            punti.append(self._centro_oggetto(re.cella))
        rg = self._richiesta_di("gatto")
        if rg is not None and rg.tipo == "gatto_scatoletta" and self.mano != "scatoletta":
            punti += [self._centro_oggetto(c) for c in self.scatolette]
        return punti

    def _bolla(self, s, testo, x, y, colore):
        img = self._testo_img(testo, colore, self.f_hud)
        r = img.get_rect(midbottom=(int(x), int(y)))
        sfondo = pygame.Surface((r.width + 8, r.height + 2), pygame.SRCALPHA)
        pygame.draw.rect(sfondo, (0, 0, 0, 150), sfondo.get_rect(), border_radius=6)
        s.blit(sfondo, (r.x - 4, r.y - 1))
        s.blit(img, r)

    def _corpi_personaggi(self):
        """Gli ingombri (in pixel della mappa) di Ale, Eli e Tamiyo, con lo spazio dei loro piccoli fumetti sopra la testa."""
        ex, ey = self.elisa.piedi()
        gx, gy = self.gatto.piedi()
        return {"ale": pygame.Rect(int(self.ale.x) - 15, int(self.ale.y) - 50, 30, 56),
                "eli": pygame.Rect(int(ex) - 15, int(ey) - self.foglio_eli.piede - 30, 30, self.foglio_eli.piede + 36),
                "gatto": pygame.Rect(int(gx) - 18, int(gy) - 34, 36, 40)}

    def _posto_fumetto(self, bw, bh, parlante, corpi, visibile):
        """Sceglie dove mettere il fumetto: vicino a chi parla ma SENZA coprire Ale, Eli e Tamiyo. Prova sopra, sotto e
        ai lati; se nessun posto e' libero prende quello che copre meno."""
        area = visibile.inflate(-8, -8)
        altri = list(corpi.values())
        candidati = []
        for dist in (14, 40, 70):
            candidati += [pygame.Rect((parlante.centerx - bw // 2, parlante.top - dist - bh), (bw, bh)),
                          pygame.Rect((parlante.centerx - bw // 2, parlante.bottom + dist), (bw, bh)),
                          pygame.Rect((parlante.right + dist, parlante.centery - bh // 2), (bw, bh)),
                          pygame.Rect((parlante.left - dist - bw, parlante.centery - bh // 2), (bw, bh))]
        migliore, peggio = None, None
        for cand in candidati:
            spostato = cand.clamp(area)
            copre = sum(spostato.clip(c).width * spostato.clip(c).height for c in altri)
            lontano = abs(spostato.centerx - parlante.centerx) + abs(spostato.centery - parlante.centery)
            voto = copre * 1000 + lontano
            if peggio is None or voto < peggio:
                peggio, migliore = voto, spostato
            if copre == 0:
                return spostato
        # nessuno dei posti vicini e' libero: si cerca il posto libero piu' vicino in tutta la parte visibile
        for passo in (16, 8):
            miglior_libero, distanza_min = None, None
            for y in range(area.top, area.bottom - bh + 1, passo):
                for x in range(area.left, area.right - bw + 1, passo):
                    cand = pygame.Rect(x, y, bw, bh)
                    if any(cand.colliderect(c) for c in altri):
                        continue
                    d = abs(cand.centerx - parlante.centerx) + abs(cand.centery - parlante.centery)
                    if distanza_min is None or d < distanza_min:
                        miglior_libero, distanza_min = cand, d
            if miglior_libero is not None:
                return miglior_libero
        return migliore

    def _corsia_fumetto(self, bw, bh, parlante, corpi, visibile):
        """Quando un personaggio resta sul fumetto lo si sposta in alto o in basso nella vista (dove di solito non c'e'
        nessuno): una sola mossa, poi sta di nuovo fermo."""
        area = visibile.inflate(-8, -8)
        x = max(area.left, min(area.right - bw, parlante.centerx - bw // 2))
        alto = pygame.Rect(x, area.top + 4, bw, bh)
        basso = pygame.Rect(x, area.bottom - bh - 4, bw, bh)
        liberi = [r for r in (alto, basso) if not any(r.colliderect(c) for c in corpi.values())]
        if liberi:
            return min(liberi, key=lambda r: abs(r.centery - parlante.centery) * -1)    # la corsia piu' lontana da chi parla
        return self._posto_fumetto(bw, bh, parlante, corpi, visibile)

    COLORI_PARLANTE = {"ale": (255, 221, 0), "eli": (255, 120, 170), "gatto": (255, 170, 60)}

    def _righe_dialogo(self, righe, larghezza_max):
        """Il testo del dialogo andato a capo in modo da stare in un fumetto stretto."""
        chiave = (tuple(righe), larghezza_max)
        if chiave not in self._dialogo_cache:
            if len(self._dialogo_cache) > 60:
                self._dialogo_cache.clear()
            risultato, riga = [], ""
            for parola in " ".join(righe).split():
                prova = (riga + " " + parola).strip()
                if riga and self.f_msg.size(prova)[0] > larghezza_max:
                    risultato.append(riga)
                    riga = parola
                else:
                    riga = prova
            if riga:
                risultato.append(riga)
            self._dialogo_cache[chiave] = risultato
        return self._dialogo_cache[chiave]

    def _disegna_dialogo(self, s):
        """Quello che dicono Ale, Eli e Tamiyo esce in un fumetto vicino a chi parla (non piu' in basso a sinistra,
        dove distraeva dal gioco). Se chi parla e' lontano o fuori schermo, il fumetto sta sopra Ale col suo ritratto."""
        righe, resta, chi = self.messaggio
        if resta <= 0 or not righe or self.stato not in ("gioco", "pronti", "pausa"):
            return
        visibile = self.vista_visibile or s.get_rect()
        corpi = self._corpi_personaggi()
        linee = self._righe_dialogo(righe, 200 if self.vista_visibile is not None else 250)
        altezza_riga = self.f_msg.get_linesize()
        larghezza = max(self.f_msg.size(x)[0] for x in linee)
        ritratto = self.ritratti.get(chi) if chi else None
        mini = None
        if ritratto is not None:
            mini = self._facce_cache.get(("mini-dialogo", chi))
            if mini is None:
                mini = self._facce_cache[("mini-dialogo", chi)] = pygame.transform.smoothscale(ritratto, (34, 34))
        pad = 8
        bw = larghezza + 2 * pad + (40 if mini else 0)
        bh = max(len(linee) * altezza_riga, 34 if mini else 0) + 2 * pad
        parlante = corpi.get(chi) or corpi["ale"]
        if not visibile.inflate(-60, -50).collidepoint(parlante.center):
            parlante = corpi["ale"]                                       # chi parla e' lontano: il fumetto sta vicino ad Ale
        chiave = (chi, tuple(righe))
        corrente = pygame.Rect(self._dialogo_pos, (bw, bh)) if self._dialogo_pos is not None else None
        area = visibile.inflate(-8, -8)
        adesso = self.tempo_totale
        if corrente is None or chiave != self._dialogo_chi:
            # messaggio nuovo: si parte vicino a chi parla, in un posto libero
            rett = self._corsia_fumetto(bw, bh, parlante, corpi, visibile)
            self._dialogo_chi, self._dialogo_mosso, self._dialogo_da = chiave, adesso, None
        else:
            rett = corrente.clamp(area)                               # fermo: segue solo i bordi della vista
            if any(rett.colliderect(c.inflate(10, 10)) for c in corpi.values()):
                if self._dialogo_da is None:
                    self._dialogo_da = adesso
                # solo se un personaggio ci resta sopra per un po' (non appena ci passa) e non piu' di una volta ogni 1,2 s
                if adesso - self._dialogo_da > 0.3 and adesso - self._dialogo_mosso > 1.2:
                    rett = self._corsia_fumetto(bw, bh, parlante, corpi, visibile)
                    self._dialogo_mosso, self._dialogo_da = adesso, None
            else:
                self._dialogo_da = None
        self._dialogo_pos = rett.topleft
        self.rett_dialogo = rett.copy()
        # se un personaggio ci passa sotto il fumetto diventa trasparente: si legge e il personaggio si vede
        sotto = any(rett.colliderect(c) for c in corpi.values())
        meta = self._dialogo_alfa + ((90 if sotto else 255) - self._dialogo_alfa) * 0.35
        self._dialogo_alfa = meta
        self.alfa_dialogo = meta
        colore = self.COLORI_PARLANTE.get(chi, BIANCO)
        ox, oy = rett.left - 16, rett.top - 16
        foglio = pygame.Surface((rett.width + 32, rett.height + 36), pygame.SRCALPHA)
        r = rett.move(-ox, -oy)
        pygame.draw.rect(foglio, (0, 0, 0), r.move(2, 3), border_radius=9)
        pygame.draw.rect(foglio, (14, 16, 40), r, border_radius=9)
        pygame.draw.rect(foglio, colore, r, width=2, border_radius=9)
        vicino = abs(rett.centerx - parlante.centerx) < rett.width // 2 + 150 and abs(rett.centery - parlante.centery) < rett.height // 2 + 130
        if vicino:
            p = parlante.move(-ox, -oy)
            tx = max(r.left + 14, min(r.right - 14, int(p.centerx)))
            if r.bottom <= p.top + 4:                                      # fumetto sopra: coda verso il basso
                coda = [(tx - 7, r.bottom - 2), (tx + 7, r.bottom - 2), (tx, r.bottom + 9)]
            elif r.top >= p.bottom - 4:                                    # fumetto sotto: coda verso l'alto
                coda = [(tx - 7, r.top + 2), (tx + 7, r.top + 2), (tx, r.top - 9)]
            else:                                                          # di lato: coda verso chi parla
                ty = max(r.top + 12, min(r.bottom - 12, p.centery))
                lato = r.left if p.centerx < r.centerx else r.right
                verso = -9 if p.centerx < r.centerx else 9
                coda = [(lato, ty - 7), (lato, ty + 7), (lato + verso, ty)]
            pygame.draw.polygon(foglio, (14, 16, 40), coda)
            pygame.draw.lines(foglio, colore, False, coda, 2)
        x = r.left + pad
        if mini is not None:
            foglio.blit(mini, (x, r.centery - 17))
            x += 40
        y = r.top + (r.height - len(linee) * altezza_riga) // 2
        for linea in linee:
            foglio.blit(self._testo_img(linea, BIANCO, self.f_msg), (x, y))
            y += altezza_riga
        foglio.set_alpha(int(meta))
        s.blit(foglio, (ox, oy))

    def _disegna_fumetti(self, s):
        ex, ey = self.elisa.piedi()
        testa = ey - self.foglio_eli.piede + 6
        re = self._richiesta_di("eli")
        if re is not None and re.attiva:
            self._bolla(s, re.bolla, ex, testa - 2 - abs(math.sin(self.tempo_totale * 6)) * 2, re.colore)
        elif self.elisa_modo == "sveglia":
            self._bolla(s, "!", ex, testa - 2 - abs(math.sin(self.tempo_totale * 12)) * 3, ROSSO)
        elif self.elisa_modo == "sospetta":
            self._bolla(s, "?", ex, testa - 2, GIALLO)
        elif self.elisa_modo == "cerca" and self.chiamata_visibile > 0:
            self._bolla(s, self.chiamata_bolla, ex, testa - 2, (170, 230, 255))
        elif self.elisa.sosta > 0:
            self._bolla(s, "...", ex, testa, BIANCO)
        gx, gy = self.gatto.piedi()
        rg = self._richiesta_di("gatto")
        if self.gatto_sazio > 0:
            self._bolla(s, "zZ", gx, gy - 34, AZZURRO)
        elif self.gatto_caccia > 0:
            self._bolla(s, "caccia!", gx, gy - 34 - abs(math.sin(self.tempo_totale * 9)) * 3, (150, 230, 150))
        elif rg is not None:
            self._bolla(s, rg.bolla, gx, gy - 34 - abs(math.sin(self.tempo_totale * 7)) * 2, rg.colore)
        for r in self.richieste:
            if r.progresso > 0.01 and r.attiva:
                bx, by = (gx, gy - 58) if r.chi == "gatto" else (ex, testa - 26)
                self._anello(s, bx, by, r.progresso)
        if self.mano is not None and self.seduta is None:
            self._bolla(s, self.mano_nome, self.ale.x, self.ale.y - 78, (200, 230, 255))
        if self.stress > 0.8 and int(self.tempo_totale) % 4 == 0 and not self.bloccato and self.crampo_blocco <= 0:
            self._bolla(s, "!?", self.ale.x, self.ale.y - 56, ROSSO)
        if self.bloccato:
            self._bolla(s, "SPAZIO!" if self.tasca > 0 else "?", self.ale.x, self.ale.y - 54, GIALLO)
        if self.seduta is not None:
            t = self.seduta["t"]
            testo = "..." if t < 1.0 else ("ngh..." if t < SEDUTA_SECONDI - 0.7 else "ahhh")
            self._bolla(s, testo, self.ale.x, self.ale.y - 56, (255, 220, 160))
        elif self.crampo_blocco > 0:
            self._bolla(s, "ngh!", self.ale.x, self.ale.y - 54, ROSSO)

    def _disegna_barre_touch(self):
        """Barra alta per telefono: la tela si vede a meta' grandezza, quindi meno cose e scritte molto piu' grandi
        (punti, ora e obiettivo in alto; vite, affanno, pancia e richieste sotto, solo con icone)."""
        c, w = self.canvas, self.larghezza
        pygame.draw.rect(c, (16, 18, 38), (0, 0, w, ALTEZZA_BARRA_ALTA))
        pygame.draw.line(c, (70, 80, 150), (0, ALTEZZA_BARRA_ALTA - 1), (w, ALTEZZA_BARRA_ALTA - 1), 2)
        c.blit(self._testo_img(f"PUNTI {self.punti:06d}", GIALLO, self.f_grande), (8, 4))
        urgente = self.tempo_notte < 30 and int(self.tempo_totale * 3) % 2 == 0
        ore = self._testo_img(f"ORE {self.orologio()}", ROSSO if urgente else AZZURRO, self.f_grande)
        c.blit(ore, (w - ore.get_width() - 8, 4))
        totale = len(self.mondo.crocchette)
        presi = totale - len(self.crocchette)
        colore = VERDE if not self.crocchette else GIALLO
        capsula = pygame.Rect(0, 0, 290, 32)
        capsula.midtop = (w // 2, 2)
        if self.stato in ("volo", "arrivo", "fine"):
            colore = VERDE if self.stato != "fine" or self.esito in ("livello", "vittoria") else ROSSO
        pygame.draw.rect(c, (28, 32, 70), capsula, border_radius=10)
        pygame.draw.rect(c, colore, capsula, width=2, border_radius=10)
        if self.stato in ("volo", "arrivo", "fine"):
            testo = "RIPROVA!" if self.stato == "fine" and self.esito not in ("livello", "vittoria") else "COMPLETATO!"
            conta = self._testo_img(testo, colore, self.f_grande)
            c.blit(conta, conta.get_rect(center=capsula.center))
        elif self.crocchette:
            conta = self._testo_img(f"{presi}/{totale}", colore, self.f_grande)
            gruppo = self.img_croc_hud.get_width() + 10 + conta.get_width()
            x0 = capsula.centerx - gruppo // 2
            c.blit(self.img_croc_hud, (x0, capsula.centery - self.img_croc_hud.get_height() // 2))
            c.blit(conta, conta.get_rect(midleft=(x0 + self.img_croc_hud.get_width() + 10, capsula.centery)))
        elif int(self.tempo_totale * 3) % 2 == 0:
            conta = self._testo_img("AL LETTO!", colore, self.f_grande)
            c.blit(conta, conta.get_rect(center=capsula.center))
        y = 44
        for i in range(self.vite):                                                          # vite (lune)
            c.blit(self.img_luna, (8 + i * 28, y))
        x = 100
        x = self._barra_touch(c, x, y, self.stress, self._icona_affanno)
        if self._bagno_attivo():
            x = self._barra_touch(c, x, y, self.pancia, self._icona_pancia)
        x = max(x + 4, 330)
        for r in self.richieste:
            larghezza = 132
            pygame.draw.rect(c, (28, 32, 74), (x, y - 2, larghezza, 30), border_radius=8)
            pygame.draw.rect(c, r.colore, (x, y - 2, larghezza, 30), width=2, border_radius=8)
            ritratto = self._mini_ritratto(r.chi, 22)
            if ritratto is not None:
                c.blit(ritratto, (x + 4, y + 2))
            self._icona_richiesta(c, r.tipo, x + 42, y + 13)
            frazione = max(0.0, r.pazienza / r.totale)
            col = (90, 200, 120) if frazione > 0.5 else ((240, 200, 60) if frazione > 0.25 else ROSSO)
            pygame.draw.rect(c, (40, 44, 80), (x + 58, y + 8, 68, 10), border_radius=5)
            pygame.draw.rect(c, col, (x + 58, y + 8, int(68 * frazione), 10), border_radius=5)
            if frazione <= 0.25:
                c.blit(self._testo_img("!", ROSSO, self.f_hud), (x + larghezza - 14, y - 1))
            x += larghezza + 6
        tasca = self._testo_img(f"x{self.tasca}", MARRONE, self.f_grande)
        c.blit(tasca, (w - tasca.get_width() - 8, y))
        c.blit(self.img_croc_hud, (w - tasca.get_width() - 36, y + 4))

    def _barra_touch(self, c, x, y, valore, icona):
        """Barra con solo il pittogramma (niente scritta), segni a meta' e al limite."""
        icona(c, x + 10, y + 13)
        bx, by, bw = x + 26, y + 8, 80
        pygame.draw.rect(c, (40, 44, 80), (bx, by, bw, 14), border_radius=7)
        riempi = int(bw * max(0.0, min(1.0, valore)))
        critico = valore >= 0.85
        if riempi > 0:
            col = (90, 200, 120) if valore < 0.5 else ((240, 200, 60) if valore < 0.85 else ROSSO)
            if critico and int(self.tempo_totale * 6) % 2 == 0:
                col = (255, 150, 150)
            pygame.draw.rect(c, col, (bx, by, riempi, 14), border_radius=7)
        for frazione in (0.5, 0.85):
            tx = bx + int(bw * frazione)
            pygame.draw.line(c, (200, 206, 236), (tx, by - 1), (tx, by + 14), 1)
        pygame.draw.rect(c, (120, 128, 190), (bx, by, bw, 14), width=1, border_radius=7)
        if critico:
            c.blit(self._testo_img("!", ROSSO, self.f_hud), (bx + bw + 3, y))
        return bx + bw + (16 if critico else 8)

    def _mini_ritratto(self, chi, lato=20):
        """Il ritratto di un personaggio in piccolo (per le richieste nell'HUD)."""
        chiave = ("mini", chi, lato)
        if chiave not in self._facce_cache:
            img = self.ritratti.get(chi)
            self._facce_cache[chiave] = pygame.transform.smoothscale(img, (lato, lato)) if img is not None else None
        return self._facce_cache[chiave]

    def _icona_richiesta(self, c, tipo, x, y):
        """Pittogramma di una richiesta, centrato in (x, y): cuore (attenzioni, coccole), regalo (aiuto), crocchetta, scatoletta."""
        if tipo in ("eli_attenzioni", "gatto_coccole"):
            cuore = self._facce_cache.get(("cuore",))
            if cuore is None:
                cuore = self._facce_cache[("cuore",)] = pygame.transform.smoothscale(self.effetti.cuore_rosa, (20, 18))
            c.blit(cuore, cuore.get_rect(center=(x, y)))
        elif tipo == "eli_aiuto":
            pygame.draw.rect(c, (120, 210, 240), (x - 8, y - 5, 16, 12), border_radius=2)
            pygame.draw.rect(c, BIANCO, (x - 8, y - 5, 16, 12), width=1, border_radius=2)
            pygame.draw.line(c, (255, 120, 170), (x, y - 8), (x, y + 7), 3)
            pygame.draw.line(c, (255, 120, 170), (x - 8, y), (x + 8, y), 3)
        elif tipo == "gatto_crocchini":
            c.blit(self.img_croc_hud, self.img_croc_hud.get_rect(center=(x, y)))
        else:
            scat = self._facce_cache.get(("scat",))
            if scat is None:
                scat = self._facce_cache[("scat",)] = pygame.transform.smoothscale(self.img_scat, (20, 16))
            c.blit(scat, scat.get_rect(center=(x, y)))

    def _disegna_barre(self):
        if self.mostra_controlli:
            self._disegna_barre_touch()
            self._disegna_messaggio()
            return
        self._disegna_barre_normale()

    def _disegna_barre_normale(self):
        """Barra alta: in alto punti e ora (grandi), al centro l'OBIETTIVO in evidenza, sotto affanno, pancia e richieste."""
        c, w = self.canvas, self.larghezza
        pygame.draw.rect(c, (16, 18, 38), (0, 0, w, ALTEZZA_BARRA_ALTA))
        pygame.draw.line(c, (70, 80, 150), (0, ALTEZZA_BARRA_ALTA - 1), (w, ALTEZZA_BARRA_ALTA - 1), 2)
        c.blit(self._testo_img(f"PUNTI {self.punti:06d}", GIALLO), (10, 5))
        livello = f"LIVELLO {self.indice_livello + 1}/{len(LIVELLI)}: {self.liv['nome'].upper()}"
        img = self._testo_img(livello, (206, 220, 244), self.f_msg)                       # secondario: piu' sobrio dell'obiettivo
        c.blit(img, img.get_rect(midtop=(w // 2, 7)))
        urgente = self.tempo_notte < 30 and int(self.tempo_totale * 3) % 2 == 0
        ore = self._testo_img(f"ORE {self.orologio()}", ROSSO if urgente else AZZURRO)
        c.blit(ore, (w - ore.get_width() - 12, 5))
        c.blit(self._testo_img("SONNO", BIANCO), (10, 27))
        for i in range(self.vite):
            c.blit(self.img_luna, (84 + i * 26, 27))
        totale = len(self.mondo.crocchette)
        presi = totale - len(self.crocchette)
        colore = VERDE if not self.crocchette else GIALLO
        if self.stato in ("volo", "arrivo", "fine"):
            colore = VERDE if self.stato != "fine" or self.esito in ("livello", "vittoria") else ROSSO
        capsula = pygame.Rect(0, 0, 330, 25)                                              # l'obiettivo e' la cosa piu' importante
        capsula.midtop = (w // 2, 27)
        pygame.draw.rect(c, (28, 32, 70), capsula, border_radius=8)
        pygame.draw.rect(c, colore, capsula, width=2, border_radius=8)
        if self.stato in ("volo", "arrivo", "fine"):
            testo = "RIPROVA!" if self.stato == "fine" and self.esito not in ("livello", "vittoria") else "LIVELLO COMPLETATO"
            conta = self._testo_img(testo, colore, self.f_hud)
            c.blit(conta, conta.get_rect(center=capsula.center))
        elif self.crocchette:
            conta = self._testo_img(f"crocchette {presi}/{totale}", colore, self.f_hud)
            gruppo = self.img_croc_hud.get_width() + 8 + conta.get_width()
            x0 = capsula.centerx - gruppo // 2
            c.blit(self.img_croc_hud, (x0, capsula.centery - self.img_croc_hud.get_height() // 2))
            c.blit(conta, conta.get_rect(midleft=(x0 + self.img_croc_hud.get_width() + 8, capsula.centery)))
        elif int(self.tempo_totale * 3) % 2 == 0:
            conta = self._testo_img("CORRI AL LETTO!", colore, self.f_hud)
            c.blit(conta, conta.get_rect(center=capsula.center))
        tasca = self._testo_img(f"TASCA x{self.tasca}", MARRONE)
        c.blit(tasca, (w - tasca.get_width() - 12, 27))
        c.blit(self.img_croc_hud, (w - tasca.get_width() - 38, 28))
        self._disegna_riga_richieste(w)
        self._disegna_messaggio()

    def _barra(self, c, x, y, etichetta, valore, icona):
        """Barra con pittogramma, scritta e segni a meta' e al limite: non si legge solo dal colore."""
        icona(c, x + 8, y + 9)
        c.blit(self._testo_img(etichetta, BIANCO, self.f_msg), (x + 22, y))
        larghezza_etichetta = self.f_msg.size(etichetta)[0]
        bx, by, bw = x + 22 + larghezza_etichetta + 6, y + 5, 60
        pygame.draw.rect(c, (40, 44, 80), (bx, by, bw, 10), border_radius=5)
        riempi = int(bw * max(0.0, min(1.0, valore)))
        critico = valore >= 0.85
        if riempi > 0:
            col = (90, 200, 120) if valore < 0.5 else ((240, 200, 60) if valore < 0.85 else ROSSO)
            if critico and int(self.tempo_totale * 6) % 2 == 0:
                col = (255, 150, 150)
            pygame.draw.rect(c, col, (bx, by, riempi, 10), border_radius=5)
        for frazione in (0.5, 0.85):
            tx = bx + int(bw * frazione)
            pygame.draw.line(c, (200, 206, 236), (tx, by - 1), (tx, by + 10), 1)
        pygame.draw.rect(c, (120, 128, 190), (bx, by, bw, 10), width=1, border_radius=5)
        if critico:
            c.blit(self._testo_img("!", ROSSO, self.f_msg), (bx + bw + 4, y))
        return bx + bw + (16 if critico else 8)

    def _icona_affanno(self, c, x, y):
        disegna_goccia(c, x, y - 7, 1.7)

    def _icona_pancia(self, c, x, y):
        pygame.draw.ellipse(c, (206, 140, 64), (x - 8, y - 7, 16, 15))
        pygame.draw.ellipse(c, (120, 76, 30), (x - 8, y - 7, 16, 15), 1)
        pygame.draw.circle(c, (120, 76, 30), (x, y + 1), 2)
        pygame.draw.line(c, (255, 230, 150), (x - 11, y - 6), (x - 8, y - 3), 2)
        pygame.draw.line(c, (255, 230, 150), (x + 11, y - 6), (x + 8, y - 3), 2)

    def _disegna_riga_richieste(self, w):
        """Terza riga: AFFANNO, PANCIA e le richieste in corso (ritratto, pittogramma e pazienza)."""
        c = self.canvas
        pygame.draw.line(c, (40, 46, 100), (0, 52), (w, 52), 1)
        x = 10
        x = self._barra(c, x, 56, "AFFANNO", self.stress, self._icona_affanno) + 6
        if self._bagno_attivo():
            x = self._barra(c, x, 56, "PANCIA", self.pancia, self._icona_pancia) + 6
        x = max(x, 350)
        for r in self.richieste:
            larghezza = 150
            pygame.draw.rect(c, (28, 32, 74), (x, 54, larghezza, 22), border_radius=6)
            pygame.draw.rect(c, r.colore, (x, 54, larghezza, 22), width=2, border_radius=6)
            ritratto = self._mini_ritratto(r.chi, 18)
            if ritratto is not None:
                c.blit(ritratto, (x + 4, 56))
            self._icona_richiesta(c, r.tipo, x + 38, 65)
            frazione = max(0.0, r.pazienza / r.totale)
            col = (90, 200, 120) if frazione > 0.5 else ((240, 200, 60) if frazione > 0.25 else ROSSO)
            pygame.draw.rect(c, (40, 44, 80), (x + 56, 61, 88, 8), border_radius=4)
            pygame.draw.rect(c, col, (x + 56, 61, int(88 * frazione), 8), border_radius=4)
            if frazione <= 0.25:
                c.blit(self._testo_img("!", ROSSO, self.f_msg), (x + larghezza - 14, 56))
            x += larghezza + 8

    def _disegna_messaggio(self):
        c = self.canvas
        y0 = ALTEZZA_BARRA_ALTA + self.altezza_mondo
        pygame.draw.rect(c, (16, 18, 38), (0, y0, self.larghezza, ALTEZZA_BARRA_BASSA))
        pygame.draw.line(c, (70, 80, 150), (0, y0), (self.larghezza, y0), 2)
        # i dialoghi non stanno piu' qui: escono in un fumetto vicino a chi parla (vedi _disegna_dialogo)

    def _cuori_finale(self, c, cx):
        """Cuori che salgono piano e una luna: il finale e' fatto per sorridere."""
        for i in range(9):
            fase = (self.tempo_totale * 0.12 + i / 9.0) % 1.0
            x = 60 + (i * 83) % (self.larghezza - 120) + math.sin(self.tempo_totale + i) * 12
            y = ALTEZZA_BARRA_ALTA + self.altezza_mondo - fase * (self.altezza_mondo - 20)
            cuore = self._facce_cache.get(("cuore-grande",))
            if cuore is None:
                cuore = self._facce_cache[("cuore-grande",)] = pygame.transform.smoothscale(self.effetti.cuore_rosa, (28, 25))
            cuore.set_alpha(int(200 * min(1.0, fase * 4) * (1 - fase * 0.7)))
            c.blit(cuore, (int(x), int(y)))
        luna = self._facce_cache.get(("luna-grande",))
        if luna is None:
            luna = self._facce_cache[("luna-grande",)] = pygame.transform.scale(
                self.img_luna, (self.img_luna.get_width() * 2, self.img_luna.get_height() * 2))
        c.blit(luna, (self.larghezza - luna.get_width() - 24, ALTEZZA_BARRA_ALTA + 20))

    def _faccia_cartone(self, file, altezza):
        """La faccia ritagliata dalla foto, a una certa altezza, con il contorno scuro uniforme dei personaggi a fumetto."""
        chiave = ("faccia", file, altezza)
        if chiave in self._facce_cache:
            return self._facce_cache[chiave]
        img = carica_immagine(file)
        risultato = None
        if img is not None:
            k = altezza / img.get_height()
            img = pygame.transform.smoothscale(img, (max(2, int(img.get_width() * k)), altezza))
            sagoma = pygame.mask.from_surface(img, 90).to_surface(setcolor=(38, 28, 56, 255), unsetcolor=(0, 0, 0, 0))
            r = 3
            risultato = pygame.Surface((img.get_width() + 2 * r, altezza + 2 * r), pygame.SRCALPHA)
            for ang in range(0, 360, 30):
                risultato.blit(sagoma, (r + int(math.cos(math.radians(ang)) * r), r + int(math.sin(math.radians(ang)) * r)))
            risultato.blit(img, (r, r))
        self._facce_cache[chiave] = risultato
        return risultato

    def _velo_esito(self, decoro):
        """Il fondo del pannello cambia con l'esito: notte tersa (vittoria), verde (livello finito), alba arancio, buio."""
        if decoro in self._veli:
            return self._veli[decoro]
        w, h = self.larghezza, self.altezza_mondo
        velo = pygame.Surface((w, h), pygame.SRCALPHA)
        tinte = {"stelle": (6, 10, 44, 208), "verde": (0, 26, 18, 208), "buio": (30, 4, 10, 218),
                 "alba": (52, 24, 10, 208)}
        velo.fill(tinte.get(decoro, (0, 0, 10, 195)))
        caso = random.Random(7)
        if decoro in ("stelle", "verde"):
            for _ in range(70 if decoro == "stelle" else 26):
                x, y = caso.randrange(10, w - 10), caso.randrange(8, h - 8)
                col = (255, 244, 190, caso.randrange(120, 255)) if caso.random() < 0.5 else (200, 220, 255, caso.randrange(120, 255))
                pygame.draw.line(velo, col, (x - 2, y), (x + 2, y))
                pygame.draw.line(velo, col, (x, y - 2), (x, y + 2))
        elif decoro == "alba":
            pygame.draw.circle(velo, (255, 150, 40, 120), (w // 2, h + 20), 150)
            pygame.draw.circle(velo, (255, 200, 90, 130), (w // 2, h + 20), 96)
        self._veli[decoro] = velo
        return velo

    def _pannello(self, titolo, colore, righe, invito, facce=(), decoro=None, punteggio=None, grande=False):
        """Schermata a tutta scena: titolo, (facce), righe, invito lampeggiante e una riga piccola di punteggio."""
        c = self.canvas
        c.blit(self._velo_esito(decoro), (0, ALTEZZA_BARRA_ALTA))
        cx = self.larghezza // 2
        cy = ALTEZZA_BARRA_ALTA + self.altezza_mondo // 2
        y_titolo = cy - (150 if facce else 80)
        if grande:                                                                 # il finale vero: tutto piu' grande
            y_titolo = cy - 196
            self._cuori_finale(c, cx)
        t = (self.f_finale if grande else self.f_titolo).render(titolo, True, colore)
        c.blit((self.f_finale if grande else self.f_titolo).render(titolo, True, (0, 0, 0)), t.get_rect(center=(cx + 3, y_titolo + 3)))
        c.blit(t, t.get_rect(center=(cx, y_titolo)))
        y = cy - 20
        if facce:
            immagini = [self._faccia_cartone(f, 150 if grande else 98) for f in facce]
            immagini = [i for i in immagini if i is not None]
            totale = sum(i.get_width() for i in immagini) + 18 * max(0, len(immagini) - 1)
            x = cx - totale // 2
            for i, img in enumerate(immagini):
                dy = int(math.sin(self.tempo_totale * 3 + i * 1.7) * 3)                # respirano piano
                y_faccia = cy - (150 if grande else 128) + dy
                if grande and i == len(immagini) - 1 and facce[i] == FILE_FACCIA_TAMIYO:
                    img, x_faccia, y_faccia = self._tamiyo_miagola(c, img, x, y_faccia)  # nel finale Tamiyo fa "Miao!"
                else:
                    x_faccia = x
                c.blit(img, (x_faccia, y_faccia))
                x += img.get_width() + 18
            y = cy + (40 if grande else 8)
        font = self.f_grande if grande else (self.f_hud if facce else self.f_msg)
        passo = 34 if grande else (30 if facce else 28)
        for i, riga in enumerate(righe):
            img = self._testo_img(riga, BIANCO, font)
            c.blit(img, img.get_rect(center=(cx, y + i * passo)))
        y_invito = max(cy + 110, y + len(righe) * passo + 12)
        if int(self.tempo_totale * 2) % 2 == 0:
            img = self._testo_img(self._tocca(invito), GIALLO, self.f_grande)
            c.blit(img, img.get_rect(center=(cx, y_invito)))
        if punteggio:
            img = self._testo_img(punteggio, (176, 182, 220), self.f_msg)
            c.blit(img, img.get_rect(center=(cx, y_invito + 34)))

    MIAO_OGNI = 3.2          # secondi tra un "Miao!" e l'altro nel finale
    MIAO_DURA = 0.9          # quanto dura ogni miagolio

    def _tamiyo_miagola(self, c, img, x, y):
        """Il muso di Tamiyo nel finale: ogni tanto salta, si allunga come per miagolare e dice "Miao!" in un fumetto
        (con il suo vero miagolio). Ritorna (immagine da disegnare, y)."""
        ciclo = int(self.tempo_totale // self.MIAO_OGNI)
        fase = (self.tempo_totale % self.MIAO_OGNI) / self.MIAO_DURA                  # 0..1 durante il miagolio
        if ciclo != getattr(self, "_miao_ciclo", None):
            self._miao_ciclo = ciclo
            self.suoni.gioca("miagolio")
        if fase >= 1.0:
            return img, x, y
        apertura = math.sin(math.pi * min(1.0, fase))                                 # 0 -> 1 -> 0
        w, h = img.get_size()
        grande = pygame.transform.smoothscale(img, (int(w * (1 - 0.05 * apertura)), int(h * (1 + 0.12 * apertura))))
        grande = pygame.transform.rotate(grande, math.sin(fase * 18) * 4 * apertura)    # un po' di scossa
        x2 = x - (grande.get_width() - w) // 2
        y2 = y - int(14 * apertura) - (grande.get_height() - h) // 2
        # il fumetto "Miao!" sopra e a destra del muso
        testo = self.f_hud.render("Miao!", True, (30, 20, 40))
        bw, bh = testo.get_width() + 22, testo.get_height() + 12
        bx, by = min(x + w - 6, self.larghezza - bw - 8), y + 6 - int(8 * apertura)
        rett = pygame.Rect(bx, by, bw, bh)
        pygame.draw.rect(c, (0, 0, 0), rett.move(2, 3), border_radius=10)
        pygame.draw.rect(c, (255, 252, 240), rett, border_radius=10)
        pygame.draw.rect(c, (255, 170, 60), rett, width=3, border_radius=10)
        pygame.draw.polygon(c, (255, 252, 240), [(rett.left + 10, rett.bottom - 2), (rett.left + 26, rett.bottom - 2), (rett.left + 6, rett.bottom + 14)])
        pygame.draw.lines(c, (255, 170, 60), False, [(rett.left + 10, rett.bottom - 1), (rett.left + 6, rett.bottom + 14), (rett.left + 26, rett.bottom - 1)], 3)
        c.blit(testo, testo.get_rect(center=rett.center))
        return grande, x2, y2

    def _tasto_guida(self, s, x, y, testo=None, freccia=None, larghezza=34):
        r = pygame.Rect(x, y, larghezza, 34)
        pygame.draw.rect(s, (30, 34, 70), r.move(0, 3), border_radius=6)
        pygame.draw.rect(s, (236, 238, 250), r, border_radius=6)
        pygame.draw.rect(s, (90, 96, 150), r, width=2, border_radius=6)
        cx, cy = r.center
        if freccia is not None:
            dx, dy = freccia
            punta = (cx + dx * 9, cy + dy * 9)
            base = (cx - dx * 6, cy - dy * 6)
            lato = (-dy * 8, dx * 8)
            pygame.draw.polygon(s, (40, 44, 90), [punta, (base[0] + lato[0], base[1] + lato[1]),
                                                  (base[0] - lato[0], base[1] - lato[1])])
        if testo:
            img = self.f_msg.render(testo, True, (40, 44, 90))
            s.blit(img, img.get_rect(center=r.center))

    def _sprite_guida(self, s, foglio, x, piedi, faccia, cammina=True):
        img = foglio.fotogramma(faccia, not cammina, self.tempo_totale * 55)
        s.blit(img, (int(x - foglio.largo / 2), int(piedi - foglio.piede - 1)))

    def _disegna_guida(self):
        c = self.canvas
        W, H = self.dimensione
        c.blit(self.intro._sfondo(W, H), (0, 0))
        titolo = self.f_titolo.render("COME SI GIOCA", True, GIALLO)
        c.blit(self.f_titolo.render("COME SI GIOCA", True, (0, 0, 0)), titolo.get_rect(center=(W // 2 + 3, 28)))
        c.blit(titolo, titolo.get_rect(center=(W // 2, 25)))
        for k, riga in enumerate(("LO SCOPO: raccogli le crocchette, esaudisci le richieste",
                                  "e corri al letto prima dell'alba. Troppe cose da fare!")):
            img = self._testo_img(riga, ROSA, self.f_hud)
            c.blit(img, img.get_rect(center=(W // 2, 58 + k * 21)))
        righe = (
            ("passi", "Cammina con le frecce (o W A S D).", "Raccogli TUTTE le crocchette che trovi!"),
            ("coppia", "Eli e Tamiyo ti chiedono delle cose:", "ti spiegano loro cosa fare, ascoltale!"),
            ("letto", "Alla fine corri al letto prima delle 06:00:", "puf! Ale sparisce e vola via."),
        )
        y0, passo = 104, 156
        for i, (icona, r1, r2) in enumerate(righe):
            y = y0 + i * passo
            pygame.draw.rect(c, (24, 28, 62), (16, y, W - 32, passo - 14), border_radius=12)
            pygame.draw.rect(c, (70, 80, 150), (16, y, W - 32, passo - 14), width=2, border_radius=12)
            c.blit(self._testo_img(r1, BIANCO, self.f_hud), (270, y + 36))
            c.blit(self._testo_img(r2, (200, 210, 246), self.f_hud), (270, y + 74))
            self._icone_guida(c, icona, y + 28)
        if int(self.tempo_totale * 2) % 2 == 0:
            img = self._testo_img(self._tocca("INVIO: INIZIA"), GIALLO, self.f_grande)
            c.blit(img, img.get_rect(center=(W // 2, H - 22)))

    def _icone_guida(self, c, icona, y):
        if icona == "passi":
            self._sprite_guida(c, self.foglio_ale, 54, y + 66, DESTRA if int(self.tempo_totale * 1.2) % 2 == 0 else SINISTRA)
            self._tasto_guida(c, 150, y + 3, freccia=(0, -1))
            for k, d in enumerate(((-1, 0), (0, 1), (1, 0))):
                self._tasto_guida(c, 112 + k * 38, y + 37, freccia=d)
            img = pygame.transform.scale(self.img_croc, (30, 24))
            c.blit(img, (214, y + 28 + int(math.sin(self.tempo_totale * 3) * 3)))
        elif icona == "coppia":
            self._sprite_guida(c, self.foglio_eli, 46, y + 66, GIU, cammina=False)
            self._sprite_guida(c, self.foglio_gatto, 116, y + 64, DESTRA if int(self.tempo_totale) % 2 == 0 else SINISTRA)
            c.blit(self.effetti.cuore_rosa, (86, y + 4 + int(math.sin(self.tempo_totale * 4) * 3)))
            c.blit(pygame.transform.scale(self.img_scat, (30, 30)), (172, y + 16))
            c.blit(pygame.transform.scale(disegna_oggetto_aiuto((120, 200, 230)), (34, 34)), (208, y + 16))
        else:
            letto = self.arte.k(*Arte.LETTO)
            if letto is None:
                letto = pygame.Surface((T, T), pygame.SRCALPHA)
                pygame.draw.rect(letto, (200, 90, 50), (2, 4, 28, 24), border_radius=4)
            c.blit(pygame.transform.scale(letto, (52, 52)), (40, y + 12))
            c.blit(self._testo_img("06:00", AZZURRO, self.f_hud), (118, y + 22))
            pygame.draw.polygon(c, GIALLO, [(34, y + 4), (50, y + 4), (42, y + 15)])

    def _bolla_guida(self, c, testo, x, y, colore):
        img = self._testo_img(testo, colore, self.f_bubble)
        r = img.get_rect(center=(x, y))
        fondo = pygame.Surface((r.width + 14, r.height + 6), pygame.SRCALPHA)
        pygame.draw.rect(fondo, (0, 0, 0, 170), fondo.get_rect(), border_radius=8)
        c.blit(fondo, (r.x - 7, r.y - 3))
        c.blit(img, r)

    def _freccia_bagno(self, s):
        """Quando la pancia chiama: freccia azzurra verso il water piu' vicino."""
        if not self._bagno_attivo() or self.pancia < 0.5 or self.seduta is not None or self.stato != "gioco":
            return
        ale = (self.ale.x, self.ale.y - 10)
        wc = min(self.mondo.gabinetti, key=lambda w: distanza(ale, ((w[0] + 0.5) * T, (w[1] + 0.5) * T)))
        bx, by = (wc[0] + 0.5) * T, (wc[1] + 0.5) * T
        d = distanza(ale, (bx, by))
        if d < 44:
            return
        dx, dy = (bx - ale[0]) / d, (by - ale[1]) / d
        pulsa = 34 + math.sin(self.tempo_totale * 9) * 4
        px, py = ale[0] + dx * pulsa, ale[1] + dy * pulsa
        lato = (-dy * 7, dx * 7)
        punta = (px + dx * 9, py + dy * 9)
        base = (px - dx * 5, py - dy * 5)
        pts = [punta, (base[0] + lato[0], base[1] + lato[1]), (base[0] - lato[0], base[1] - lato[1])]
        pygame.draw.polygon(s, (150, 220, 255), pts)
        pygame.draw.polygon(s, (20, 70, 110), pts, 2)
        s.blit(self._testo_img("WC", (150, 220, 255), self.f_piccolo), (int(px - 9), int(py - 20)))

    def _freccia_oggetto(self, s):
        """Eli ti ha chiesto un oggetto: una freccia gialla ti indica dov'e' (con il suo nome); quando l'hai in mano
        ti indica Eli."""
        r = self._richiesta_di("eli")
        if r is None or r.tipo != "eli_aiuto" or not r.attiva or self.stato != "gioco":
            return
        if self.mano == "aiuto":
            bx, by = self.elisa.piedi()
            nome = "ELI"
        elif r.cella is not None:
            bx, by = self._centro_oggetto(r.cella)
            nome = r.breve
        else:
            return
        ale = (self.ale.x, self.ale.y - 10)
        d = distanza(ale, (bx, by))
        if d < 50:
            return
        dx, dy = (bx - ale[0]) / d, (by - ale[1]) / d
        pulsa = 46 + math.sin(self.tempo_totale * 8) * 4
        px, py = ale[0] + dx * pulsa, ale[1] + dy * pulsa
        lato = (-dy * 8, dx * 8)
        punta = (px + dx * 11, py + dy * 11)
        base = (px - dx * 6, py - dy * 6)
        pts = [punta, (base[0] + lato[0], base[1] + lato[1]), (base[0] - lato[0], base[1] - lato[1])]
        pygame.draw.polygon(s, (255, 236, 120), pts)
        pygame.draw.polygon(s, (90, 60, 10), pts, 2)
        img = self._testo_img(nome, (255, 236, 120), self.f_piccolo)
        fondo = img.get_rect(center=(int(px - dx * 20), int(py - dy * 20 - 6)))
        pygame.draw.rect(s, (0, 0, 0), fondo.inflate(6, 2), border_radius=4)
        s.blit(img, fondo)

    def _freccia_aiuto(self, s):
        """Nei primi secondi del primo livello: freccia verso la crocchetta piu' vicina."""
        if self.indice_livello != 0 or self.senza_raccolta < 6 or not self.crocchette or self.stato != "gioco":
            return
        ale = (self.ale.x, self.ale.y - 10)
        vicina = min(self.crocchette, key=lambda cella: distanza(ale, self._centro_oggetto(cella)))
        bx, by = self._centro_oggetto(vicina)
        d = distanza(ale, (bx, by))
        if d < 40:
            return
        dx, dy = (bx - ale[0]) / d, (by - ale[1]) / d
        pulsa = 30 + math.sin(self.tempo_totale * 8) * 4
        px, py = ale[0] + dx * pulsa, ale[1] + dy * pulsa
        lato = (-dy * 7, dx * 7)
        punta = (px + dx * 9, py + dy * 9)
        base = (px - dx * 5, py - dy * 5)
        pts = [punta, (base[0] + lato[0], base[1] + lato[1]), (base[0] - lato[0], base[1] - lato[1])]
        pygame.draw.polygon(s, GIALLO, pts)
        pygame.draw.polygon(s, (90, 60, 10), pts, 2)

    def _disegna_schermate(self):
        if self.stato == "pronti":
            img = self.f_titolo.render("PRONTI?", True, GIALLO)
            self.canvas.blit(img, img.get_rect(center=(self.larghezza // 2, ALTEZZA_BARRA_ALTA + self.altezza_mondo // 2)))
        elif self.stato == "pausa":
            if self.mostra_controlli:
                comandi = ("Croce: cammina      Pulsante: azione", "M: suoni")
                invito = "tocca per continuare"
            else:
                comandi = ("Frecce / WASD: cammina      SPAZIO: azione",
                           "M: suoni" + ("" if WEB else "      ESC: esci"))
                invito = "premi P per continuare"
            self._pannello("PAUSA", AZZURRO, (comandi[0],
                                              "Raccogli le crocchette e corri al letto prima dell'alba.",
                                              "Eli e Tamiyo ti chiedono cose: esaudiscile!",
                                              "Troppe richieste? L'AFFANNO sale. E il bagno chiama...",
                                              comandi[1]), invito)
        elif self.stato == "fine":
            self._schermata_fine()

    def _schermata_fine(self):
        """Fine livello / vittoria / sconfitte: una frase sola con le facce dei personaggi, il punteggio in piccolo."""
        n = self.indice_livello + 1
        if self.esito == "livello":
            titolo, colore, righe, decoro = f"LIVELLO {n} FINITO!", VERDE, self.liv["fine"], "verde"
            invito, facce = f"INVIO: livello {n + 1}", (FILE_FACCIA_PILOTA, FILE_FACCIA_TAMIYO)
        elif self.esito == "vittoria":
            titolo, colore, righe, decoro = TITOLO_SCHERMATA_VITTORIA, GIALLO, FRASI_VITTORIA, "stelle"
            invito, facce = "INVIO: ricomincia", (FILE_FACCIA_PILOTA, FILE_FACCIA_ELISA, FILE_FACCIA_TAMIYO)
        elif self.esito == "vite":
            titolo, colore, righe, decoro = TITOLO_SCHERMATA_VITE, ROSSO, FRASI_VITE_FINITE, "buio"
            invito, facce = "INVIO: riprova il livello", (FILE_FACCIA_ELISA, FILE_FACCIA_PILOTA)
        else:
            titolo, colore, righe, decoro = TITOLO_SCHERMATA_SOLE, ARANCIO, FRASI_SOLE, "alba"
            invito, facce = "INVIO: riprova il livello", (FILE_FACCIA_TAMIYO, FILE_FACCIA_PILOTA)
        self._pannello(titolo, colore, tuple(righe), invito, facce=facce, decoro=decoro,
                       punteggio=f"Punti {self.punti}  ·  Record {self.record}", grande=self.esito == "vittoria")

    # ------------------------------------------------------- ciclo principale
    def presenta(self):
        W, H = self.dimensione
        fw, fh = self.finestra.get_size()
        scala = min(fw / W, fh / H)
        nuova = (max(1, int(W * scala)), max(1, int(H * scala)))
        if nuova == (W, H):
            immagine = self.canvas
        elif abs(scala - round(scala)) < 0.01:
            immagine = pygame.transform.scale(self.canvas, nuova)
        elif scala > 1.0 and not WEB:
            # "bilineare nitido": prima ingrandisce a numero intero (pixel netti), poi rimpicciolisce senza sbavature
            f = int(math.ceil(scala))
            grande = pygame.transform.scale(self.canvas, (W * f, H * f))
            immagine = pygame.transform.smoothscale(grande, nuova)
        elif WEB and 0.96 <= scala <= 1.08:
            immagine = pygame.transform.scale(self.canvas, nuova)          # quasi 1:1: la copia veloce non si nota, risparmia fotogrammi
        else:
            immagine = pygame.transform.smoothscale(self.canvas, nuova)
        self.finestra.fill((0, 0, 0))
        self._scala_vista = scala
        spazio_lati, spazio_sotto = (fw - nuova[0]) // 2, fh - nuova[1]
        if self.mostra_controlli and spazio_lati >= 150:
            self._layout_comandi = "lati"                      # telefono in orizzontale: comandi nelle bande nere a sinistra e a destra
        elif self.mostra_controlli and spazio_sotto >= 200:
            self._layout_comandi = "sotto"                     # telefono in verticale: comandi sotto la mappa
        else:
            self._layout_comandi = "dentro"                    # finestra stretta: comandi sopra la mappa (come prima)
        self._off_vista = ((fw - nuova[0]) // 2, 0 if self._layout_comandi == "sotto" else (fh - nuova[1]) // 2)
        self.finestra.blit(immagine, self._off_vista)
        if self.volo is not None:
            self._volo_hires(self.finestra, scala, self._off_vista)
        if self.nuvole is not None:
            self._disegna_nuvole(self.finestra, scala, self._off_vista)
        if self._layout_comandi != "dentro":
            self._disegna_controlli_finestra(scala, self._off_vista)
        pygame.display.flip()

    # ----------------------------------------------------- comandi a tocco (telefono)
    def _tocca(self, testo):
        """Sui telefoni 'INVIO' diventa 'TOCCA'."""
        return testo.replace("INVIO", "TOCCA").replace("PREMI TOCCA", "TOCCA PER INIZIARE") if self.mostra_controlli else testo

    def _zone_controlli(self):
        """Dove stanno i comandi a tocco, in coordinate della tela (anche fuori dalla tela, nelle bande nere): croce, azione,
        pausa, ognuno come (x, y, raggio). Sui telefoni sono grandi e non coprono la mappa."""
        W, H = self.dimensione
        fw, fh = self.finestra.get_size() if self.finestra is not None else (W, H)
        sc = self._scala_vista or 1.0
        chiave = (self._layout_comandi, fw, fh, round(sc, 3))
        if self._zone_cache is not None and self._zone_cache[0] == chiave:
            return self._zone_cache[1]
        if self._layout_comandi == "lati":
            lat = (fw - W * sc) / 2 / sc                           # larghezza di ogni banda nera, in unita' della tela
            zone = {"croce": (-lat / 2, H * 0.62, min(lat * 0.45, 170)),
                    "azione": (W + lat / 2, H * 0.62, min(lat * 0.36, 125)),
                    "pausa": (W + lat / 2, ALTEZZA_BARRA_ALTA + 10, min(lat * 0.27, 62))}
        elif self._layout_comandi == "sotto":
            sotto = (fh - H * sc) / sc
            yc = H + sotto * 0.55
            zone = {"croce": (W * 0.27, yc, min(sotto * 0.38, 190)),
                    "azione": (W * 0.77, yc, min(sotto * 0.27, 135)),
                    "pausa": (W - 70, H + 64, 52)}
        else:
            y = ALTEZZA_BARRA_ALTA + self.altezza_mondo - 84
            zone = {"croce": (84, y, 64), "azione": (self.larghezza - 84, y, 44),
                    "pausa": (self.larghezza - 34, ALTEZZA_BARRA_ALTA + 34, 24)}
        self._zone_cache = (chiave, zone)
        self._controlli_img = None
        return zone

    def _punto_gioco(self, x, y):
        sc = self._scala_vista or 1.0
        return ((x - self._off_vista[0]) / sc, (y - self._off_vista[1]) / sc)

    def _tocco(self, evento):
        t = evento.type
        if t in (pygame.FINGERDOWN, pygame.FINGERMOTION, pygame.FINGERUP):
            fw, fh = self.finestra.get_size()
            punto = self._punto_gioco(evento.x * fw, evento.y * fh)
            ident = ("f", getattr(evento, "finger_id", 0))
            giu, nuovo = t != pygame.FINGERUP, t == pygame.FINGERDOWN
            self.mostra_controlli = True
        elif t in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
            if t == pygame.MOUSEMOTION and not evento.buttons[0]:
                return
            punto = self._punto_gioco(*evento.pos)
            ident = ("m", 0)
            giu, nuovo = t != pygame.MOUSEBUTTONUP, t == pygame.MOUSEBUTTONDOWN
            if getattr(evento, "touch", False):
                self.mostra_controlli = True
        else:
            return
        if giu:
            self.tocchi[ident] = punto
        else:
            self.tocchi.pop(ident, None)
        if not giu:
            self.joy.pop(ident, None)
        if not nuovo:
            return
        if self.stato in ("gioco", "pronti") and self.mostra_controlli and self._nel_joystick(punto):
            self.joy[ident] = punto
            return
        if self.stato in ("titolo", "guida", "fine", "volo"):
            self.tocchi.clear()
            self._conferma()
        elif self.stato == "pausa":
            self.tocchi.clear()
            self._pausa()
        elif self.mostra_controlli and self.stato == "gioco":
            zone = self._zone_controlli()
            ax, ay, ar = zone["azione"]
            px, py, pr = zone["pausa"]
            y_mondo = (punto[0], punto[1])
            if distanza(y_mondo, (ax, ay)) < ar + 18:
                self.tasto(pygame.K_SPACE)
            elif distanza(y_mondo, (px, py)) < pr + 12:
                self._pausa()

    def _nel_joystick(self, punto):
        """Il primo dito sulla meta' sinistra dello schermo (fuori da AZIONE e pausa) diventa un joystick."""
        zone = self._zone_controlli()
        for nome in ("azione", "pausa"):
            x, y, r = zone[nome]
            if distanza(punto, (x, y)) < r + 18:
                return False
        return punto[0] < self.dimensione[0] * 0.55

    def _direzione_tocco(self):
        """Il joystick segue il dito: dove si appoggia il pollice e' il centro, si spinge nella direzione voluta."""
        for ident, origine in list(self.joy.items()):
            p = self.tocchi.get(ident)
            if p is None:
                continue
            dx, dy = p[0] - origine[0], p[1] - origine[1]
            d = math.hypot(dx, dy)
            if d > JOY_MAX:                                           # trascinato troppo: la base lo insegue
                origine = (p[0] - dx / d * JOY_MAX, p[1] - dy / d * JOY_MAX)
                self.joy[ident] = origine
                d = JOY_MAX
            if d < JOY_MORTA:
                continue
            vx = (1 if dx > 0 else -1) if abs(dx) / d > 0.4 else 0
            vy = (1 if dy > 0 else -1) if abs(dy) / d > 0.4 else 0
            return vx, vy
        return 0, 0

    def _disegna_joystick(self, dest, P, sc):
        """Base e pallino del joystick sotto il dito (P porta le coordinate della tela alla superficie 'dest')."""
        for ident, origine in self.joy.items():
            p = self.tocchi.get(ident, origine)
            R = max(10, int(JOY_MAX * sc))
            x, y = P(*origine)
            velo = pygame.Surface((2 * R + 8, 2 * R + 8), pygame.SRCALPHA)
            pygame.draw.circle(velo, (255, 255, 255, 40), (R + 4, R + 4), R)
            pygame.draw.circle(velo, (255, 255, 255, 140), (R + 4, R + 4), R, max(2, R // 20))
            dest.blit(velo, (x - R - 4, y - R - 4))
            px, py = P(*p)
            dx, dy = px - x, py - y
            d = math.hypot(dx, dy)
            if d > R:
                px, py = x + dx / d * R, y + dy / d * R
            pygame.draw.circle(dest, (255, 255, 255), (int(px), int(py)), max(6, R // 3))
            pygame.draw.circle(dest, (255, 221, 0), (int(px), int(py)), max(6, R // 3), max(2, R // 24))

    def _disegna_controlli(self):
        """Comandi a tocco disegnati sulla tela (solo quando non c'e' posto fuori dalla mappa)."""
        if not self.mostra_controlli or self.stato not in ("gioco", "pronti", "pausa") or self._layout_comandi != "dentro":
            return
        zone = self._zone_controlli()
        if self._controlli_img is None:
            img = pygame.Surface(self.dimensione, pygame.SRCALPHA)
            cx, cy, r = zone["croce"]
            pygame.draw.circle(img, (255, 255, 255, 40), (cx, cy), r)
            pygame.draw.circle(img, (255, 255, 255, 110), (cx, cy), r, 3)
            for (dx, dy) in DIREZIONI:
                punta = (cx + dx * (r - 14), cy + dy * (r - 14))
                base = (cx + dx * (r - 34), cy + dy * (r - 34))
                lato = (-dy * 10, dx * 10)
                pygame.draw.polygon(img, (255, 255, 255, 150), [punta, (base[0] + lato[0], base[1] + lato[1]),
                                                                (base[0] - lato[0], base[1] - lato[1])])
            ax, ay, ar = zone["azione"]
            pygame.draw.circle(img, (255, 221, 0, 60), (ax, ay), ar)
            pygame.draw.circle(img, (255, 221, 0, 150), (ax, ay), ar, 3)
            testo = self.f_piccolo.render("AZIONE", True, (255, 240, 160))
            img.blit(testo, testo.get_rect(center=(ax, ay)))
            px, py, pr = zone["pausa"]
            pygame.draw.circle(img, (255, 255, 255, 50), (px, py), pr)
            pygame.draw.rect(img, (255, 255, 255, 170), (px - 7, py - 8, 5, 16))
            pygame.draw.rect(img, (255, 255, 255, 170), (px + 2, py - 8, 5, 16))
            self._controlli_img = img
        self.canvas.blit(self._controlli_img, (0, 0))
        self._disegna_joystick(self.canvas, lambda x, y: (int(x), int(y)), 1.0)

    def _disegna_controlli_finestra(self, sc, off):
        """Comandi a tocco grandi, fuori dalla mappa: si disegnano una volta sola su un foglio trasparente e a ogni
        fotogramma si copiano solo i tre cerchi (sul telefono ogni millisecondo conta: la musica non deve saltare)."""
        if not self.mostra_controlli or self.stato not in ("gioco", "pronti", "pausa"):
            return
        zone = self._zone_controlli()
        chiave = (self.finestra.get_size(), self._layout_comandi, bool(self.joy), round(sc, 3), tuple(off))
        if getattr(self, "_ctrl_cache", None) is None or self._ctrl_cache[0] != chiave:
            foglio = pygame.Surface(self.finestra.get_size(), pygame.SRCALPHA)
            self._costruisci_controlli(foglio, sc, off, zone)
            rettangoli = []
            for nome in ("croce", "azione", "pausa"):
                x, y, r = zone[nome]
                px, py = int(off[0] + x * sc), int(off[1] + y * sc)
                R = int(r * sc) + 10
                rettangoli.append(pygame.Rect(px - R, py - R, 2 * R, 2 * R).clip(foglio.get_rect()))
            self._ctrl_cache = (chiave, foglio, rettangoli)
        _, foglio, rettangoli = self._ctrl_cache
        for rett in rettangoli:
            self.finestra.blit(foglio, rett.topleft, rett)
        self._disegna_joystick(self.finestra, lambda x, y: (int(off[0] + x * sc), int(off[1] + y * sc)), sc)

    def _costruisci_controlli(self, dest, sc, off, zone):

        def P(x, y):
            return int(off[0] + x * sc), int(off[1] + y * sc)

        cx, cy, r = zone["croce"]
        x, y = P(cx, cy)
        R = max(8, int(r * sc))
        if not self.joy:                                          # a riposo: un suggerimento; col dito appoggiato resta solo il joystick
            velo = pygame.Surface((2 * R + 8, 2 * R + 8), pygame.SRCALPHA)
            pygame.draw.circle(velo, (255, 255, 255, 34), (R + 4, R + 4), R)
            pygame.draw.circle(velo, (255, 255, 255, 130), (R + 4, R + 4), R, max(2, R // 24))
            dest.blit(velo, (x - R - 4, y - R - 4))
            for (dx, dy) in DIREZIONI:
                punta = (x + dx * R * 0.82, y + dy * R * 0.82)
                base = (x + dx * R * 0.42, y + dy * R * 0.42)
                lato = (-dy * R * 0.22, dx * R * 0.22)
                pygame.draw.polygon(dest, (255, 255, 255), [punta, (base[0] + lato[0], base[1] + lato[1]),
                                                            (base[0] - lato[0], base[1] - lato[1])])
            scritta = self._font(max(10, int(R * 0.2))).render("trascina qui", True, (200, 210, 246))
            dest.blit(scritta, scritta.get_rect(center=(x, y + R * 0.3)))
        ax, ay, ar = zone["azione"]
        x, y = P(ax, ay)
        R = max(8, int(ar * sc))
        velo = pygame.Surface((2 * R + 8, 2 * R + 8), pygame.SRCALPHA)
        pygame.draw.circle(velo, (255, 221, 0, 60), (R + 4, R + 4), R)
        pygame.draw.circle(velo, (255, 221, 0, 190), (R + 4, R + 4), R, max(2, R // 18))
        dest.blit(velo, (x - R - 4, y - R - 4))
        etichetta = self._font(max(10, int(R * 0.42))).render("AZIONE", True, (255, 240, 160))
        dest.blit(etichetta, etichetta.get_rect(center=(x, y)))
        px, py, pr = zone["pausa"]
        x, y = P(px, py)
        R = max(8, int(pr * sc))
        velo = pygame.Surface((2 * R + 8, 2 * R + 8), pygame.SRCALPHA)
        pygame.draw.circle(velo, (255, 255, 255, 60), (R + 4, R + 4), R)
        pygame.draw.circle(velo, (255, 221, 0, 190), (R + 4, R + 4), R, max(2, R // 14))
        dest.blit(velo, (x - R - 4, y - R - 4))
        larg, alt = max(3, R // 5), int(R * 0.7)
        pygame.draw.rect(dest, (255, 255, 255), (x - larg - larg // 2, y - alt // 2, larg, alt), border_radius=2)
        pygame.draw.rect(dest, (255, 255, 255), (x + larg // 2, y - alt // 2, larg, alt), border_radius=2)

    # ------------------------------------------------------- ciclo principale
    def _fotogramma(self):
        """Un fotogramma di gioco. Ritorna False quando si deve uscire."""
        dt = min(self.clock.tick(FPS) / 1000.0, 0.05)
        if WEB:
            self._adatta_finestra_browser()
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return False
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_ESCAPE and not WEB:
                    return False
                self.tasto(evento.key)
            else:
                self._tocco(evento)
        self.aggiorna(dt)
        self.disegna()
        self.presenta()
        return True

    def _adatta_finestra_browser(self):
        """Se il telefono viene girato (o la finestra cambia), rifa' la tela alla nuova misura."""
        self._conta_web = getattr(self, "_conta_web", 0) + 1
        if self._conta_web % 20:
            return
        misura = _dimensione_browser()
        attuale = self.finestra.get_size()
        if misura is None or (abs(misura[0] - attuale[0]) < attuale[0] * 0.06 and abs(misura[1] - attuale[1]) < attuale[1] * 0.06):
            return
        self.finestra = pygame.display.set_mode(misura)
        _avvisa_browser_della_misura()
        self._zone_cache = None
        self._controlli_img = None
        self.tocchi.clear()
        self.joy.clear()

    def esegui(self):
        while self._fotogramma():
            pass

    async def esegui_async(self):
        """Stesso ciclo, ma cede il controllo al browser a ogni fotogramma."""
        while self._fotogramma():
            await asyncio.sleep(0)


CAMPI_LIVELLO = ("nome", "intro", "fine", "mappa", "tappe", "crocchette", "scatolette", "muri",
                 "elisa_giro", "elisa_sveglia", "sveglia_secondi", "errore", "curiosita", "notte_secondi")


def _numero(valore, nome, minimo=None, massimo=None, intero=False, dove=""):
    """Controlla che 'valore' sia un numero (intero se serve) nell'intervallo, con un errore in italiano."""
    tipi = (int,) if intero else (int, float)
    if isinstance(valore, bool) or not isinstance(valore, tipi):
        raise ValueError(f"{dove}'{nome}' deve essere un numero{' intero' if intero else ''} (senza virgolette"
                         f"{', senza virgola' if intero else ''}).")
    if (minimo is not None and valore < minimo) or (massimo is not None and valore > massimo):
        raise ValueError(f"{dove}'{nome}' deve essere tra {minimo} e {massimo}.")
    return valore


def _celle(valore, nome, dove):
    try:
        return tuple((int(c), int(r)) for c, r in valore)
    except (TypeError, ValueError):
        raise ValueError(f"{dove}'{nome}' deve essere un elenco di coppie (colonna, riga), "
                         f"per esempio ((2, 2), (5, 7)).")


def crea_mondi():
    """Controlla ogni livello e ne costruisce la casa, dicendo quale livello ha un problema."""
    if not LIVELLI:
        raise ValueError("LIVELLI e' vuoto: serve almeno un livello.")
    mondi = []
    for n, livello in enumerate(LIVELLI, start=1):
        dove = f"Livello {n} ({livello.get('nome', '?')}): "
        mancanti = [campo for campo in CAMPI_LIVELLO if campo not in livello]
        if mancanti:
            raise ValueError(f"Nel livello {n} mancano questi campi: {', '.join(mancanti)}.")
        _numero(livello["notte_secondi"], "notte_secondi", 1, 3600, dove=dove)
        _numero(livello["sveglia_secondi"], "sveglia_secondi", 0.5, 600, dove=dove)
        _numero(livello["elisa_giro"], "elisa_giro", 0.2, 3, dove=dove)
        _numero(livello["elisa_sveglia"], "elisa_sveglia", 0.2, 3, dove=dove)
        _numero(livello["errore"], "errore", 0, 1, dove=dove)
        _numero(livello["curiosita"], "curiosita", 0, 1, dove=dove)
        _numero(livello["crocchette"], "crocchette", 1, 2000, intero=True, dove=dove)
        livello["tappe"] = _celle(livello["tappe"], "tappe", dove)
        livello["scatolette"] = _celle(livello["scatolette"], "scatolette", dove)
        try:
            mondo = Mondo(livello)
        except ValueError as errore:
            raise ValueError(f"{dove}{errore}")
        if not any(t in mondo.raggiungibili for t in livello["tappe"]):
            raise ValueError(f"{dove}nessuna delle 'tappe' di Eli e' una casella di pavimento raggiungibile.")
        mondi.append(mondo)
    return mondi


def controlla_configurazione(mondi):
    """Ferma il gioco con un messaggio chiaro se una costante in cima al file non ha senso."""
    _numero(ZOOM, "ZOOM", 0.3, 4)
    _numero(OSCURITA, "OSCURITA", 0, 255)
    _numero(RAGGIO_LUCE, "RAGGIO_LUCE", 0, 600)
    _numero(ELISA_VISTA_CELLE, "ELISA_VISTA_CELLE", 0, 40)
    _numero(ELISA_SOSPETTO_SECONDI, "ELISA_SOSPETTO_SECONDI", 0, 20)
    _numero(ELISA_RICERCA_SECONDI, "ELISA_RICERCA_SECONDI", 0, 60)
    for nome, valore in (("VELOCITA_IO", VELOCITA_IO), ("VELOCITA_ELISA_GIRO", VELOCITA_ELISA_GIRO),
                         ("VELOCITA_ELISA_SVEGLIA", VELOCITA_ELISA_SVEGLIA), ("VELOCITA_GATTO", VELOCITA_GATTO)):
        _numero(valore, nome, 10, 600)
    _numero(VITE_INIZIALI, "VITE_INIZIALI", 1, 20, intero=True)
    _numero(SEDUTA_SECONDI, "SEDUTA_SECONDI", 1.5, 30)
    _numero(RICHIESTA_PRIMA_SECONDI, "RICHIESTA_PRIMA_SECONDI", 0, 600)
    _numero(PAZIENZA_SECONDI, "PAZIENZA_SECONDI", 3, 600)
    _numero(TENUTA_SECONDI, "TENUTA_SECONDI", 0.3, 20)
    for nome, valore in (("GATTO_CACCIA_CROCCHINO", GATTO_CACCIA_CROCCHINO),
                         ("GATTO_CACCIA_COCCOLE", GATTO_CACCIA_COCCOLE),
                         ("GATTO_CACCIA_SCATOLETTA", GATTO_CACCIA_SCATOLETTA)):
        _numero(valore, nome, 0, 600)
    _numero(PUNTI_RICHIESTA, "PUNTI_RICHIESTA", 0, 100000, intero=True)
    _numero(PUNTI_SOLLIEVO, "PUNTI_SOLLIEVO", 0, 100000, intero=True)
    _numero(TASCA_INIZIALE, "TASCA_INIZIALE", 0, 99, intero=True)
    _numero(TASCA_MASSIMA, "TASCA_MASSIMA", 1, 99, intero=True)
    for nome, valore in (("PUNTI_CROCCHETTA", PUNTI_CROCCHETTA), ("PUNTI_SCATOLETTA", PUNTI_SCATOLETTA),
                         ("PUNTI_CROCCHETTA_AL_GATTO", PUNTI_CROCCHETTA_AL_GATTO),
                         ("PUNTI_PER_VITA_RIMASTA", PUNTI_PER_VITA_RIMASTA),
                         ("PUNTI_PER_SECONDO_RIMASTO", PUNTI_PER_SECONDO_RIMASTO)):
        _numero(valore, nome, 0, 100000, intero=True)
    for nome, valore in (("ELISA_GIRO_SECONDI", ELISA_GIRO_SECONDI), ("ELISA_SOSTA_SECONDI", ELISA_SOSTA_SECONDI),
                         ("BISOGNO_SECONDI", BISOGNO_SECONDI), ("RICHIESTA_OGNI_SECONDI", RICHIESTA_OGNI_SECONDI)):
        try:
            minimo, massimo = valore
        except (TypeError, ValueError):
            raise ValueError(f"'{nome}' deve essere una coppia di numeri, per esempio (8, 14).")
        _numero(minimo, nome, 0, 600)
        _numero(massimo, nome, 0, 600)
        if minimo > massimo:
            raise ValueError(f"'{nome}' deve essere una coppia (minimo, massimo) con minimo <= massimo.")
    for nome in (FILE_ALE_CAMMINATA, FILE_ELISA_CAMMINATA, FILE_GATTO_CAMMINATA, FILE_RITRATTO_ALE, FILE_FACCIA_PILOTA,
                 FILE_RITRATTO_ELISA, FILE_RITRATTO_GATTO, FILE_ARREDI, FILE_ALE_SEDUTO_VESTITO, FILE_ALE_SEDUTO_NUDO):
        if not isinstance(nome, str) or not nome:
            raise ValueError("I nomi dei file immagine (FILE_...) devono essere testo, per esempio \"io.png\".")
        if "\\" in nome or "\x07" in nome:
            raise ValueError(f"Nel nome del file '{nome}' usa la barra normale '/' e non quella rovesciata.")
    for brano in MUSICHE.values():
        for nota in list(brano["melodia"]) + list(brano["basso"]):
            frequenza_nota(nota)
    prima = mondi[0]
    for n, mondo in enumerate(mondi, start=1):
        if (mondo.colonne, mondo.righe_n) != (prima.colonne, prima.righe_n):
            raise ValueError(f"La mappa del livello {n} ha una grandezza diversa dalla prima "
                             f"({mondo.colonne} x {mondo.righe_n} invece di {prima.colonne} x {prima.righe_n}).")
    if prima.colonne * T < 640 or prima.righe_n * T < 380:
        raise ValueError("La mappa e' troppo piccola per le schermate del gioco: servono almeno 20 colonne e 12 righe.")


PIXEL_MASSIMI_WEB = 1_250_000      # nel browser la tela ha al massimo questi pixel (oltre, i telefoni non reggono)


def _dimensione_browser():
    """Nel browser: la finestra e' grande quanto lo schermo in pixel VERI (non in pixel CSS), cosi' sul telefono
    le scritte sono nitide invece di essere ingrandite e sfocate. None se non si riesce a leggere."""
    try:
        import platform
        w = platform.window
        larg, alt, dpr = float(w.innerWidth), float(w.innerHeight), float(w.devicePixelRatio)
    except Exception:                                                  # fuori dal browser o pagina non pronta
        return None
    if larg < 200 or alt < 200:
        return None
    k = max(1.0, min(3.0, dpr))
    while k > 1.0 and larg * alt * k * k > PIXEL_MASSIMI_WEB:
        k = max(1.0, k - 0.1)
    return int(larg * k) // 2 * 2, int(alt * k) // 2 * 2


def _avvisa_browser_della_misura():
    """Dice alla pagina che la tela e' cambiata, cosi' la fa stare nello schermo senza deformarla."""
    try:
        import platform
        platform.window.dispatchEvent(platform.window.Event.new("resize"))
    except Exception:
        pass


def crea_finestra(dimensione):
    if WEB:
        misura = _dimensione_browser()
        if misura is not None:
            finestra = pygame.display.set_mode(misura)
            _avvisa_browser_della_misura()
            return finestra
    grandezza = (int(dimensione[0] * ZOOM), int(dimensione[1] * ZOOM))
    try:
        return pygame.display.set_mode(grandezza, pygame.RESIZABLE)
    except pygame.error:
        return pygame.display.set_mode(grandezza)


def _icona_finestra():
    """L'icona della finestra e' il muso di Tamiyo."""
    percorso = trova_file(FILE_RITRATTO_GATTO)
    if percorso is not None:
        try:
            pygame.display.set_icon(pygame.transform.smoothscale(pygame.image.load(str(percorso)), (32, 32)))
        except (pygame.error, OSError, ValueError):
            pass


def _mostra_caricamento(finestra):
    finestra.fill((10, 12, 26))
    try:
        font = pygame.font.Font(None, 44)
        img = font.render("CARICAMENTO...", True, (255, 221, 0))
        finestra.blit(img, img.get_rect(center=(finestra.get_width() // 2, finestra.get_height() // 2)))
    except (pygame.error, OSError):
        pass
    pygame.display.flip()


def _prepara():
    """Controlla la configurazione e apre la finestra. Ritorna (finestra, mondi) o None se c'e' un errore."""
    pygame.init()
    try:
        mondi = crea_mondi()
        controlla_configurazione(mondi)
    except (ValueError, TypeError, KeyError) as errore:
        print(f"Errore nella configurazione: {errore}")
        pygame.quit()
        try:
            input("Premi INVIO per chiudere...")
        except (EOFError, OSError, RuntimeError):
            pass
        return None
    prima = mondi[0]
    dimensione = (prima.colonne * T, prima.righe_n * T + ALTEZZA_BARRA_ALTA + ALTEZZA_BARRA_BASSA)
    _icona_finestra()
    finestra = crea_finestra(dimensione)
    pygame.display.set_caption(TITOLO_FINESTRA)
    _mostra_caricamento(finestra)
    return finestra, mondi


def main():
    preparato = _prepara()
    if preparato is None:
        sys.exit(1)
    gioco = Gioco(*preparato)
    prova = os.environ.get("CROCCHETTE_PROVA")
    if prova:                       # solo per i controlli automatici: gira per N fotogrammi ed esce
        for _ in range(int(prova)):
            if not gioco._fotogramma():
                break
        print("PROVA OK", gioco.stato, "| font incluso:", (CARTELLA_FONT / "Cousine-Bold.ttf").is_file(),
              "| suoni veri:", len(getattr(gioco.suoni, "campioni", {})), "| immagini:", gioco.foglio_ale.n)
        pygame.quit()
        return
    gioco.esegui()
    pygame.quit()


async def main_async():
    """Avvio per il browser (pygbag)."""
    preparato = _prepara()
    if preparato is None:
        return
    await asyncio.sleep(0.05)
    await Gioco(*preparato).esegui_async()


if __name__ == "__main__":
    main()
