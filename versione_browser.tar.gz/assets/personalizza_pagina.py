"""Dopo 'pygbag --build': rende italiana e in tema la pagina di caricamento (build/web/index.html)."""
import pathlib, sys

PAGINA = pathlib.Path(__file__).parent / "build" / "web" / "index.html"
SEGNO = "/* crocchette: pagina di caricamento */"

STILE = SEGNO + """
        body { background-color: #0b0d24 !important; color: #f5f5f5; font-family: "Courier New", monospace; }
        #transfer { position: fixed; top: 58%; left: 0; right: 0; z-index: 999998; }
        #status { color: #9fd3ff !important; margin: 0 0 8px 0 !important; font-size: 16px; }
        #progress { width: min(300px, 70vw) !important; accent-color: #ff66b3; }
        #infobox { background: #151a44 !important; color: #ffd400 !important; border: 3px solid #ff66b3;
                   border-radius: 10px; text-align: center; line-height: 1.5; max-width: 82vw;
                   box-shadow: 0 0 0 4px #0b0d24, 0 0 24px #ff66b355; }
        #infobox .t1 { font-size: 22px; color: #ffd400; }
        #infobox .t2 { font-size: 22px; color: #ff66b3; margin-bottom: 8px; }
        #infobox .t3 { font-size: 16px; color: #ffffff; font-weight: normal; }
        .pulsa { animation: pulsa 1.4s ease-in-out infinite; }
        @keyframes pulsa { 50% { opacity: .7; } }
        @media (prefers-reduced-motion: reduce) { .pulsa { animation: none; } }
        /* telefono: la pagina sta ferma (niente scorrimento, zoom, aggiorna-trascinando, selezione di testo) */
        html, body { position: fixed; inset: 0; width: 100%; height: 100%; overflow: hidden; overscroll-behavior: none;
                     touch-action: none; -webkit-user-select: none; user-select: none; -webkit-touch-callout: none;
                     -webkit-tap-highlight-color: transparent; }
        canvas { touch-action: none; outline: none; }
"""

BLOCCO_TELEFONO = """<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#0b0d24">
    <script>
    /* telefono: blocca lo zoom a pizzico, il doppio tocco e il trascinamento della pagina */
    (function () {
        var ferma = function (e) { e.preventDefault(); };
        ["gesturestart", "gesturechange", "gestureend", "contextmenu", "dblclick"].forEach(function (n) {
            document.addEventListener(n, ferma, { passive: false });
        });
        document.addEventListener("touchmove", ferma, { passive: false });
        var ultimo = 0;
        document.addEventListener("touchend", function (e) {
            var ora = Date.now();
            if (ora - ultimo < 350) { e.preventDefault(); }
            ultimo = ora;
        }, { passive: false });
        window.addEventListener("scroll", function () { window.scrollTo(0, 0); });
    })();
    </script>
"""

CARICAMENTO = ('<div id="infobox" role="status" aria-live="polite"><div class="t1">Non ero calcolato!..</div><div class="t2">Bei tempi!</div>'
               '<div class="t3 pulsa">Sto preparando la notte...<br>'
               'Il primo avvio richiede circa mezzo minuto.</div></div>')

SOSTITUZIONI = (
    ('<div id="infobox">Loading, please wait ...</div>', CARICAMENTO),
    ('msg  = "Ready to start ! Please click/touch page"',
     'msg  = "Tutto pronto!  Tocca o clicca la pagina per iniziare"'),
    ('f"installing {pkg}"', 'f"preparo {pkg}"'),
    ('Downloading...', 'Scarico il gioco...'),
    ('<title>versione_browser</title>', '<title>Non ero calcolato!.. Bei tempi!</title>'),
    ('<html lang="en-us">', '<html lang="it">'),
    ('platform.window.infobox.innerText = msg',
     "platform.window.infobox.innerHTML = '<div class=\"t3\">' + msg + '</div>'"),
    ('platform.window.infobox.innerText = f"preparo {pkg}"',
     "platform.window.infobox.innerHTML = f'<div class=\"t3\">preparo {pkg}</div>'"),
    ('    <meta name="viewport" content="height=device-height, initial-scale=1.0">\n', '    ' + BLOCCO_TELEFONO),
    ('</style>', STILE + '    </style>'),
)

testo = PAGINA.read_text(encoding="utf-8")
if SEGNO in testo:
    sys.exit("gia' personalizzata")
for vecchio, nuovo in SOSTITUZIONI:
    if testo.count(vecchio) < 1:
        sys.exit(f"ATTENZIONE: non trovo {vecchio[:50]!r} (versione di pygbag cambiata?)")
    testo = testo.replace(vecchio, nuovo, 1)
PAGINA.write_text(testo, encoding="utf-8")
print("pagina di caricamento personalizzata")
