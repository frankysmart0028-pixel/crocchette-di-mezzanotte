import asyncio

import pygame  # serve a pygbag per sapere che il gioco usa pygame

import crocchette_di_mezzanotte as gioco

asyncio.run(gioco.main_async())
